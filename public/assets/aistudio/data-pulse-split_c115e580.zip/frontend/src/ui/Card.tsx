import React from 'react';
import { cx } from './cx';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  interactive?: boolean;
  padded?: boolean;
}

/** White surface used by every list item and panel on the light workspace. */
export const Card: React.FC<CardProps> = ({ interactive, padded = true, className, children, ...rest }) => (
  <div
    className={cx(
      'bg-white rounded-2xl border border-slate-200/80 shadow-lift',
      padded && 'p-5',
      interactive && 'transition-all duration-150 hover:-translate-y-0.5 hover:border-pulse-300 hover:shadow-[0_10px_30px_-12px_rgb(11_165_236/0.35)]',
      className
    )}
    {...rest}
  >
    {children}
  </div>
);

type Tone = 'sky' | 'violet' | 'emerald' | 'amber' | 'rose' | 'slate';
const TONE: Record<Tone, { tile: string; text: string }> = {
  sky: { tile: 'bg-pulse-50 text-pulse-600', text: 'text-pulse-600' },
  violet: { tile: 'bg-violet-50 text-violet-600', text: 'text-violet-600' },
  emerald: { tile: 'bg-emerald-50 text-emerald-600', text: 'text-emerald-600' },
  amber: { tile: 'bg-amber-50 text-amber-600', text: 'text-amber-600' },
  rose: { tile: 'bg-rose-50 text-rose-600', text: 'text-rose-600' },
  slate: { tile: 'bg-slate-100 text-slate-600', text: 'text-slate-600' },
};

export const StatCard: React.FC<{ icon: React.ReactNode; value: React.ReactNode; label: string; hint?: string; tone?: Tone }> = ({
  icon, value, label, hint, tone = 'sky',
}) => (
  <Card className="flex items-center gap-4">
    <span className={cx('w-12 h-12 rounded-xl grid place-items-center shrink-0', TONE[tone].tile)}>{icon}</span>
    <div className="min-w-0">
      <p className="text-[26px] leading-none font-extrabold tracking-tight text-slate-900 tabular">{value}</p>
      <p className="mt-1.5 text-xs font-semibold text-slate-500">{label}</p>
      {hint && <p className="text-[11px] text-slate-400 mt-0.5">{hint}</p>}
    </div>
  </Card>
);

export const Badge: React.FC<{ tone?: Tone; children: React.ReactNode; className?: string }> = ({ tone = 'slate', children, className }) => (
  <span className={cx('inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide', TONE[tone].tile, className)}>
    {children}
  </span>
);

export const EmptyState: React.FC<{ icon: React.ReactNode; title: string; description: string; action?: React.ReactNode }> = ({ icon, title, description, action }) => (
  <Card className="py-14 flex flex-col items-center text-center border-dashed">
    <span className="w-14 h-14 rounded-2xl grid place-items-center bg-slate-100 text-slate-400 mb-4">{icon}</span>
    <h3 className="text-base font-bold text-slate-800">{title}</h3>
    <p className="text-sm text-slate-500 max-w-sm mt-1.5 mb-5 leading-relaxed">{description}</p>
    {action}
  </Card>
);

export const PageHeader: React.FC<{ eyebrow?: string; title: React.ReactNode; description?: React.ReactNode; actions?: React.ReactNode }> = ({
  eyebrow, title, description, actions,
}) => (
  <header className="flex flex-col md:flex-row md:items-end justify-between gap-5 pb-1">
    <div className="min-w-0">
      {eyebrow && (
        <p className="inline-flex items-center gap-2 text-[11px] font-bold tracking-[0.16em] uppercase text-pulse-600">
          <span className="w-5 h-px bg-pulse-400" />
          {eyebrow}
        </p>
      )}
      <h1 className="mt-1.5 text-3xl md:text-[34px] leading-tight font-extrabold tracking-tight text-slate-900">{title}</h1>
      {description && <p className="mt-2 text-sm text-slate-500 max-w-2xl leading-relaxed">{description}</p>}
    </div>
    {actions && <div className="flex items-center gap-2 shrink-0">{actions}</div>}
  </header>
);

export const Segmented = <T extends string>({
  value, onChange, options,
}: { value: T; onChange: (v: T) => void; options: { value: T; label: React.ReactNode }[] }) => (
  <div role="tablist" className="inline-flex p-1 rounded-xl bg-slate-200/60 gap-0.5">
    {options.map((o) => (
      <button
        key={o.value}
        type="button"
        role="tab"
        aria-selected={value === o.value}
        onClick={() => onChange(o.value)}
        className={cx(
          'h-8 px-3.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer',
          value === o.value ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
        )}
      >
        {o.label}
      </button>
    ))}
  </div>
);
