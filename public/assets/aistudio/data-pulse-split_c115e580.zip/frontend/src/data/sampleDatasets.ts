import { Dataset } from '../types/dashboard';

// Zero sample datasets: The application is strictly user data-driven.
export const SAMPLE_DATASETS: Dataset[] = [];
