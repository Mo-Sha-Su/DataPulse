import { Dataset } from '../types/dashboard';

// Zero canonical global datasets: The application starts with 0 datasets for any new user.
export const CANONICAL_GLOBAL_DATASETS: Dataset[] = [];
