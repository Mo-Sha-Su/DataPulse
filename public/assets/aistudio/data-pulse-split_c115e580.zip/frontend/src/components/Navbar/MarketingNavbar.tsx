import React, { useState } from 'react';
import { User } from '../../types/auth';
import { BrandLockup } from '../BrandLogo';
import { NeonStatusBadge } from '../NeonStatusBadge';
import { Menu, X, ArrowRight, LayoutGrid, Sparkles } from 'lucide-react';

interface Props {
  currentUser: User | null;
  activeNav?: 'home' | 'features' | 'pricing' | 'about';
  onNavigate: (
    page: 'home' | 'features' | 'pricing' | 'about' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub',
    dashboardId?: string
  ) => void;
}

export const MarketingNavbar: React.FC<Props> = ({
  currentUser,
  activeNav,
  onNavigate,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 h-20 bg-white/85 backdrop-blur-md border-b border-slate-200/80 z-50 transition-all shadow-xs">
      <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 md:px-10 flex items-center justify-between">
        {/* Brand Logo & Name */}
        <button
          type="button"
          onClick={() => {
            onNavigate('home');
            setMobileMenuOpen(false);
          }}
          className="flex items-center text-left focus-visible:outline-2 focus-visible:outline-sky-500 rounded-xl cursor-pointer hover:opacity-90 transition-opacity"
          title="Data Pulse Home"
          aria-label="Data Pulse Home"
        >
          <BrandLockup size={38} textSize="text-xl" />
        </button>

        {/* Center Nav Links: Features, Pricing, About */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-100/70 p-1.5 rounded-2xl border border-slate-200/60 shadow-2xs font-semibold text-xs text-slate-600">
          <button
            type="button"
            onClick={() => onNavigate('features')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeNav === 'features'
                ? 'bg-white text-sky-700 shadow-xs font-bold'
                : 'hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            Features
          </button>

          <button
            type="button"
            onClick={() => onNavigate('pricing')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeNav === 'pricing'
                ? 'bg-white text-sky-700 shadow-xs font-bold'
                : 'hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            Pricing
          </button>

          <button
            type="button"
            onClick={() => onNavigate('about')}
            className={`px-4 py-2 rounded-xl transition-all cursor-pointer ${
              activeNav === 'about'
                ? 'bg-white text-sky-700 shadow-xs font-bold'
                : 'hover:text-slate-900 hover:bg-white/60'
            }`}
          >
            About
          </button>
        </nav>

        {/* Right Action Buttons */}
        <div className="hidden md:flex items-center gap-3">
          <NeonStatusBadge />

          {currentUser ? (
            <button
              type="button"
              onClick={() => onNavigate('dashboard_hub')}
              className="h-10 px-4.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 active:scale-[0.98] text-white font-bold text-xs shadow-sm shadow-sky-600/25 transition-all flex items-center gap-2 cursor-pointer"
              title="Go to Dashboard Hub"
              aria-label="Go to Dashboard Hub"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Go to Dashboard Hub</span>
            </button>
          ) : (
            <>
              <button
                type="button"
                onClick={() => onNavigate('login')}
                className="h-10 px-4 rounded-xl text-slate-700 hover:text-sky-600 hover:bg-slate-100/80 font-bold text-xs transition-all cursor-pointer"
                title="Login to Account"
                aria-label="Login to Account"
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => onNavigate('signup')}
                className="h-10 px-5 rounded-xl bg-slate-900 hover:bg-sky-600 active:scale-[0.98] text-white font-bold text-xs shadow-sm shadow-slate-900/20 transition-all flex items-center gap-1.5 cursor-pointer"
                title="Get Started Free"
                aria-label="Get Started Free"
              >
                <span>Get Started Free</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </>
          )}
        </div>

        {/* Mobile Hamburger Button */}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-slate-700 hover:text-slate-900 rounded-xl hover:bg-slate-100 cursor-pointer"
          aria-label="Toggle Navigation Menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-xl border-b border-slate-200 px-6 py-6 shadow-xl animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-3 font-semibold text-sm">
            <button
              type="button"
              onClick={() => {
                onNavigate('features');
                setMobileMenuOpen(false);
              }}
              className={`text-left py-2.5 px-3 rounded-xl transition-colors ${
                activeNav === 'features' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              Features
            </button>

            <button
              type="button"
              onClick={() => {
                onNavigate('pricing');
                setMobileMenuOpen(false);
              }}
              className={`text-left py-2.5 px-3 rounded-xl transition-colors ${
                activeNav === 'pricing' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              Pricing
            </button>

            <button
              type="button"
              onClick={() => {
                onNavigate('about');
                setMobileMenuOpen(false);
              }}
              className={`text-left py-2.5 px-3 rounded-xl transition-colors ${
                activeNav === 'about' ? 'bg-sky-50 text-sky-700 font-bold' : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              About
            </button>

            <div className="h-px bg-slate-200 my-2" />

            {currentUser ? (
              <button
                type="button"
                onClick={() => {
                  onNavigate('dashboard_hub');
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white font-bold text-center flex items-center justify-center gap-2"
              >
                <LayoutGrid className="w-4 h-4" />
                <span>Go to Dashboard Hub</span>
              </button>
            ) : (
              <div className="flex flex-col gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    onNavigate('login');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl border border-slate-300 text-slate-800 font-bold text-center"
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onNavigate('signup');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 rounded-xl bg-slate-900 text-white font-bold text-center flex items-center justify-center gap-1.5"
                >
                  <span>Get Started Free</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
