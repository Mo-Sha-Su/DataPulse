import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown, LogOut } from 'lucide-react';
import { BrandLockup } from '../BrandLogo';
import { NeonStatusBadge } from '../NeonStatusBadge';
import { User } from '../../types/auth';
import { cx } from '../../ui';

export type AppSection = 'dashboard_hub' | 'data_hub' | 'sample_graphs';

interface Props {
  active: AppSection;
  currentUser: User | null;
  onNavigate: (page: 'home' | 'dashboard_hub' | 'data_hub' | 'sample_graphs') => void;
  onLogout: () => void;
  /** the page's primary action, shown next to the account menu */
  action?: React.ReactNode;
}

const LINKS: { id: AppSection; label: string }[] = [
  { id: 'dashboard_hub', label: 'Dashboards & Reports' },
  { id: 'data_hub', label: 'Data Hub' },
  { id: 'sample_graphs', label: 'Visual Gallery' },
];

/** The single top bar for every signed-in page (previously copy-pasted into each page). */
export const AppNavbar: React.FC<Props> = ({ active, currentUser, onNavigate, onLogout, action }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const first = currentUser?.first_name || 'User';
  const full = currentUser ? `${currentUser.first_name} ${currentUser.last_name}`.trim() : 'User';

  useEffect(() => {
    if (!menuOpen) return;
    const down = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setMenuOpen(false); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenuOpen(false); };
    document.addEventListener('mousedown', down);
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('mousedown', down); document.removeEventListener('keydown', key); };
  }, [menuOpen]);

  return (
    <nav className="h-16 bg-white/95 border-b border-slate-200/80 px-4 sm:px-6 md:px-10 flex items-center justify-between sticky top-0 z-40">
      <div className="flex items-center gap-8">
        <button type="button" onClick={() => onNavigate('home')} className="flex items-center rounded-lg cursor-pointer focus-visible:outline-2 focus-visible:outline-pulse-500" title="Data Pulse home" aria-label="Data Pulse home">
          <BrandLockup size={32} textSize="text-xl" />
        </button>
        <div className="hidden md:flex items-center gap-1" role="tablist" aria-label="Sections">
          {LINKS.map((l) => (
            <button
              key={l.id}
              type="button"
              role="tab"
              aria-selected={active === l.id}
              onClick={() => onNavigate(l.id)}
              className={cx(
                'relative h-16 px-3.5 text-[13px] font-semibold transition-colors cursor-pointer',
                active === l.id ? 'text-slate-900' : 'text-slate-500 hover:text-slate-800'
              )}
            >
              {l.label}
              {active === l.id && <span className="absolute left-3 right-3 bottom-0 h-0.5 rounded-full bg-gradient-to-r from-pulse-500 to-volt-500" />}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3">
        <NeonStatusBadge />
        {action}
        <div className="relative" ref={ref}>
          <button
            type="button"
            onClick={() => setMenuOpen((v) => !v)}
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            aria-label="Account menu"
            className="h-10 flex items-center gap-2 p-1 pr-2 rounded-full border border-transparent hover:border-slate-200 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <span className="w-8 h-8 rounded-full bg-gradient-to-br from-pulse-500 to-volt-600 text-white font-extrabold text-xs grid place-items-center uppercase">
              {first.charAt(0)}
            </span>
            <span className="text-[13px] font-semibold text-slate-800 hidden sm:inline">{full}</span>
            <ChevronDown className={cx('w-3.5 h-3.5 text-slate-400 transition-transform', menuOpen && 'rotate-180')} />
          </button>
          {menuOpen && (
            <div role="menu" className="lab-pop absolute right-0 mt-2 w-60 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 text-xs">
              <div className="px-4 py-2.5 border-b border-slate-100">
                <p className="font-bold text-slate-900 text-[13px]">{full}</p>
                <p className="text-[11px] text-slate-500 truncate">{currentUser?.email}</p>
                {currentUser?.role && <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-pulse-600">{currentUser.role}</p>}
              </div>
              <button
                type="button"
                role="menuitem"
                onClick={() => { setMenuOpen(false); onLogout(); }}
                className="w-full px-4 py-2.5 text-left font-semibold text-rose-600 hover:bg-rose-50 flex items-center gap-2 cursor-pointer"
              >
                <LogOut className="w-4 h-4" /> Log out
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};
