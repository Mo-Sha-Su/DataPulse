import React, { useState, useEffect, useRef } from 'react';
import { CanvasSettings, ReportPage, ProjectType, ReportPageSizePreset, WidgetType } from '../../types/dashboard';
import { REPORT_PAGE_PRESETS } from '../../utils/reportPageDimensions';
import { BrandLogo } from '../BrandLogo';
import { NeonStatusBadge } from '../NeonStatusBadge';
import {
  Pencil,
  ZoomIn,
  ZoomOut,
  Eye,
  Save,
  FolderOpen,
  Grid,
  Filter,
  ArrowLeft,
  FileText,
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
  ChevronDown,
  Printer,
  RotateCcw,
  RotateCw,
  BarChart3,
  TrendingUp,
  Table,
  Type,
  Box,
  Command,
  Info,
  Check,
  X,
  FilePlus,
  Sparkles,
  Layout,
  Network,
  Database,
  Lock,
  Unlock,
  Maximize2,
} from 'lucide-react';

interface Props {
  dashboardTitle: string;
  projectType?: ProjectType;
  pages?: ReportPage[];
  activePageId?: string;
  widgetCount: number;
  autoSaveStatus: 'saved' | 'saving' | 'unsaved';
  canvas: CanvasSettings;
  canUndo: boolean;
  canRedo: boolean;
  activeFilterCount?: number;
  activeWorkspaceView?: 'canvas' | 'data_model';
  onChangeWorkspaceView?: (view: 'canvas' | 'data_model') => void;
  onOpenSelectDatasets?: () => void;
  onBackToHub?: () => void;
  onOpenFilters?: () => void;
  onExportPdf?: () => void;
  onUndo: () => void;
  onRedo: () => void;
  onTitleChange: (newTitle: string) => void;
  onUpdateCanvas: (updatedCanvas: Partial<CanvasSettings>) => void;
  onTogglePreviewMode: () => void;
  onSaveDashboard: () => void;
  onOpenDashboardManager: () => void;
  onNewDashboard?: () => void;
  onNewReport?: () => void;
  onAddPage?: () => void;
  onSelectPage?: (pageId: string) => void;
  onRenamePage?: (pageId: string, newName: string) => void;
  onDeletePage?: (pageId: string) => void;
  onAddWidget?: (widgetType: WidgetType) => void;
  onOpenDataCleaning?: () => void;
}

const DASHBOARD_PRESETS: { name: string; width: number; height: number }[] = [
  { name: '1920×1080 Full HD', width: 1920, height: 1080 },
  { name: '1366×768 Laptop', width: 1366, height: 768 },
  { name: '1280×720 HD', width: 1280, height: 720 },
  { name: '1024×768 Tablet', width: 1024, height: 768 },
];

type MenuName = 'file' | 'edit' | 'view' | 'insert' | 'format' | 'help' | null;

export const TopToolbar: React.FC<Props> = ({
  dashboardTitle,
  projectType = 'dashboard',
  pages = [],
  activePageId,
  widgetCount,
  autoSaveStatus,
  canvas,
  canUndo,
  canRedo,
  activeFilterCount = 0,
  onBackToHub,
  onOpenFilters,
  onExportPdf,
  onUndo,
  onRedo,
  onTitleChange,
  onUpdateCanvas,
  onTogglePreviewMode,
  onSaveDashboard,
  onOpenDashboardManager,
  onNewDashboard,
  onNewReport,
  onAddPage,
  onSelectPage,
  onRenamePage,
  onDeletePage,
  onAddWidget,
  onOpenDataCleaning,
  activeWorkspaceView = 'canvas',
  onChangeWorkspaceView,
  onOpenSelectDatasets,
}) => {
  const [activeMenu, setActiveMenu] = useState<MenuName>(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [titleInput, setTitleInput] = useState(dashboardTitle);
  const [showCanvasPopover, setShowCanvasPopover] = useState(false);
  const [editingPageId, setEditingPageId] = useState<string | null>(null);
  const [pageNameInput, setPageNameInput] = useState('');
  const [showShortcutsModal, setShowShortcutsModal] = useState(false);
  const [showAboutModal, setShowAboutModal] = useState(false);
  const [lockAspectRatio, setLockAspectRatio] = useState(false);

  const menuContainerRef = useRef<HTMLDivElement>(null);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuContainerRef.current && !menuContainerRef.current.contains(event.target as Node)) {
        setActiveMenu(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTitleSubmit = () => {
    if (titleInput.trim()) {
      onTitleChange(titleInput.trim());
    }
    setIsEditingTitle(false);
  };

  const activePageIndex = pages.findIndex((p) => p.id === activePageId);

  const handlePageRenameSubmit = (pageId: string) => {
    if (pageNameInput.trim() && onRenamePage) {
      onRenamePage(pageId, pageNameInput.trim());
    }
    setEditingPageId(null);
  };

  const toggleMenu = (menu: MenuName) => {
    setActiveMenu((prev) => (prev === menu ? null : menu));
  };

  const handleMouseEnterMenu = (menu: MenuName) => {
    if (activeMenu !== null) {
      setActiveMenu(menu);
    }
  };

  return (
    <header className="relative z-30 bg-white border-b border-slate-200 select-none shadow-xs text-slate-800">
      {/* ROW 1: DESKTOP APPLICATION MENU BAR & REPORT METADATA */}
      <div className="h-10 px-3 sm:px-4 flex items-center justify-between border-b border-slate-100 text-xs gap-2">
        {/* Left: Brand + Command Menu Bar */}
        <div className="flex items-center gap-3 shrink-0" ref={menuContainerRef}>
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-2 pr-2 border-r border-slate-200 shrink-0">
            <BrandLogo size={22} />
            <span className="font-black text-xs tracking-tight text-[#2563EB] uppercase hidden md:inline">
              DATA PULSE
            </span>
          </div>

          {/* Traditional Command Menu Bar (File | Edit | View | Insert | Format | Help) */}
          <nav aria-label="Application Command Bar" className="flex items-center gap-0.5 relative">
            {/* FILE MENU */}
            <div className="relative">
              <button
                type="button"
                onClick={() => toggleMenu('file')}
                onMouseEnter={() => handleMouseEnterMenu('file')}
                aria-expanded={activeMenu === 'file'}
                aria-haspopup="true"
                className={`px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-500 ${
                  activeMenu === 'file'
                    ? 'bg-slate-200 text-slate-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                File
              </button>
              {activeMenu === 'file' && (
                <div className="absolute top-full left-0 mt-1 w-56 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in duration-100">
                  {onNewDashboard && (
                    <button
                      type="button"
                      onClick={() => {
                        onNewDashboard();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Layout className="w-4 h-4 text-slate-500" /> New Dashboard
                      </span>
                    </button>
                  )}

                  {onNewReport && (
                    <button
                      type="button"
                      onClick={() => {
                        onNewReport();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <FilePlus className="w-4 h-4 text-slate-500" /> New Report
                      </span>
                    </button>
                  )}

                  {projectType === 'report' && onAddPage && (
                    <button
                      type="button"
                      onClick={() => {
                        onAddPage();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Plus className="w-4 h-4 text-slate-500" /> New Report Page
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">Ctrl+N</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      onOpenDashboardManager();
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <FolderOpen className="w-4 h-4 text-slate-500" /> Open Saved Projects
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Ctrl+O</span>
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={() => {
                      onSaveDashboard();
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer font-bold text-indigo-600"
                  >
                    <span className="flex items-center gap-2">
                      <Save className="w-4 h-4 text-indigo-600" /> Save Report
                    </span>
                    <span className="text-[10px] text-indigo-400 font-mono">Ctrl+S</span>
                  </button>

                  {onExportPdf && (
                    <button
                      type="button"
                      onClick={() => {
                        onExportPdf();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Printer className="w-4 h-4 text-emerald-600" /> Export PDF
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">Ctrl+P</span>
                    </button>
                  )}

                  {onOpenDataCleaning && (
                    <button
                      type="button"
                      onClick={() => {
                        onOpenDataCleaning();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-sky-50 text-sky-800 transition-colors cursor-pointer font-medium"
                    >
                      <span className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-sky-600" /> Explore the data...
                      </span>
                    </button>
                  )}

                  <div className="my-1 border-t border-slate-100" />

                  {onBackToHub && (
                    <button
                      type="button"
                      onClick={() => {
                        onBackToHub();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-rose-50 text-rose-700 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <ArrowLeft className="w-4 h-4 text-rose-500" /> Back to Hub
                      </span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* EDIT MENU */}
            <div className="relative">
              <button
                type="button"
                onClick={() => toggleMenu('edit')}
                onMouseEnter={() => handleMouseEnterMenu('edit')}
                aria-expanded={activeMenu === 'edit'}
                aria-haspopup="true"
                className={`px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-500 ${
                  activeMenu === 'edit'
                    ? 'bg-slate-200 text-slate-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                Edit
              </button>
              {activeMenu === 'edit' && (
                <div className="absolute top-full left-0 mt-1 w-56 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in duration-100">
                  <button
                    type="button"
                    disabled={!canUndo}
                    onClick={() => {
                      onUndo();
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 disabled:opacity-40 disabled:hover:bg-transparent transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <RotateCcw className="w-4 h-4 text-slate-500" /> Undo
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Ctrl+Z</span>
                  </button>

                  <button
                    type="button"
                    disabled={!canRedo}
                    onClick={() => {
                      onRedo();
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 disabled:opacity-40 disabled:hover:bg-transparent transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <RotateCw className="w-4 h-4 text-slate-500" /> Redo
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">Ctrl+Y</span>
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={() => {
                      setTitleInput(dashboardTitle);
                      setIsEditingTitle(true);
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <Pencil className="w-4 h-4 text-slate-500" /> Rename Report Title
                  </button>

                  {onOpenFilters && (
                    <button
                      type="button"
                      onClick={() => {
                        onOpenFilters();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Filter className="w-4 h-4 text-sky-600" /> Global Data Filters
                      </span>
                      {activeFilterCount > 0 && (
                        <span className="px-1.5 py-0.2 bg-sky-100 text-sky-800 rounded-full text-[10px] font-bold">
                          {activeFilterCount}
                        </span>
                      )}
                    </button>
                  )}

                  {onOpenDataCleaning && (
                    <button
                      type="button"
                      onClick={() => {
                        onOpenDataCleaning();
                        setActiveMenu(null);
                      }}
                      className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-sky-50 text-sky-800 transition-colors cursor-pointer font-medium"
                    >
                      <span className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-sky-600" /> Explore the data...
                      </span>
                    </button>
                  )}

                  {pages.length > 1 && onDeletePage && activePageId && (
                    <>
                      <div className="my-1 border-t border-slate-100" />
                      <button
                        type="button"
                        onClick={() => {
                          onDeletePage(activePageId);
                          setActiveMenu(null);
                        }}
                        className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-rose-50 text-rose-600 transition-colors cursor-pointer font-semibold"
                      >
                        <Trash2 className="w-4 h-4 text-rose-500" /> Delete Active Page
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* VIEW MENU */}
            <div className="relative">
              <button
                type="button"
                onClick={() => toggleMenu('view')}
                onMouseEnter={() => handleMouseEnterMenu('view')}
                aria-expanded={activeMenu === 'view'}
                aria-haspopup="true"
                className={`px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-500 ${
                  activeMenu === 'view'
                    ? 'bg-slate-200 text-slate-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                View
              </button>
              {activeMenu === 'view' && (
                <div className="absolute top-full left-0 mt-1 w-56 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in duration-100">
                  <button
                    type="button"
                    onClick={() => {
                      onTogglePreviewMode();
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer font-medium"
                  >
                    <Eye className="w-4 h-4 text-indigo-600" /> Report Preview Mode
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateCanvas({ zoom: Math.min(2.0, canvas.zoom + 0.1) });
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <ZoomIn className="w-4 h-4 text-slate-500" /> Zoom In (+10%)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateCanvas({ zoom: Math.max(0.3, canvas.zoom - 0.1) });
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <ZoomOut className="w-4 h-4 text-slate-500" /> Zoom Out (-10%)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateCanvas({ zoom: 1.0 });
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <span>Reset Zoom</span>
                    <span className="font-mono text-[10px] font-bold text-indigo-600">100%</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateCanvas({ zoom: 0.70 });
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    Fit Page to Screen
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateCanvas({ zoom: 0.95 });
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    Fit Page Width
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={() => {
                      onUpdateCanvas({ snapToGrid: !canvas.snapToGrid });
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <span className="flex items-center gap-2">
                      <Grid className="w-4 h-4 text-slate-500" /> Grid Snapping
                    </span>
                    {canvas.snapToGrid && <Check className="w-4 h-4 text-indigo-600" />}
                  </button>
                </div>
              )}
            </div>

            {/* INSERT MENU */}
            <div className="relative">
              <button
                type="button"
                onClick={() => toggleMenu('insert')}
                onMouseEnter={() => handleMouseEnterMenu('insert')}
                aria-expanded={activeMenu === 'insert'}
                aria-haspopup="true"
                className={`px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-500 ${
                  activeMenu === 'insert'
                    ? 'bg-slate-200 text-slate-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                Insert
              </button>
              {activeMenu === 'insert' && (
                <div className="absolute top-full left-0 mt-1 w-56 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in duration-100">
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Insert Widgets
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onAddWidget?.('bar');
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <BarChart3 className="w-4 h-4 text-sky-600" /> Standard Chart
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onAddWidget?.('kpi');
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <TrendingUp className="w-4 h-4 text-emerald-600" /> KPI Metric Card
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onAddWidget?.('textbox');
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <Type className="w-4 h-4 text-amber-600" /> Rich Text Block
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      onAddWidget?.('scatter3d');
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <Box className="w-4 h-4 text-cyan-600" /> 3D Scatter Graph
                  </button>

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={() => {
                      onAddPage?.();
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer font-medium"
                  >
                    <Plus className="w-4 h-4 text-slate-500" /> Insert New Page
                  </button>
                </div>
              )}
            </div>

            {/* FORMAT MENU */}
            <div className="relative">
              <button
                type="button"
                onClick={() => toggleMenu('format')}
                onMouseEnter={() => handleMouseEnterMenu('format')}
                aria-expanded={activeMenu === 'format'}
                aria-haspopup="true"
                className={`px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-500 ${
                  activeMenu === 'format'
                    ? 'bg-slate-200 text-slate-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                Format
              </button>
              {activeMenu === 'format' && (
                <div className="absolute top-full left-0 mt-1 w-64 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in duration-100">
                  <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {projectType === 'report' ? 'Report Page Presets' : 'Dashboard Screen Presets'}
                  </div>

                  {projectType === 'report' ? (
                    Object.keys(REPORT_PAGE_PRESETS).map((key) => {
                      const preset = REPORT_PAGE_PRESETS[key as ReportPageSizePreset];
                      const isSelected = canvas.pageSizePreset === key;
                      return (
                        <button
                          key={key}
                          type="button"
                          onClick={() => {
                            onUpdateCanvas({
                              pageSizePreset: key as ReportPageSizePreset,
                              presetName: key,
                              orientation: preset.orientation,
                              widthPhysical: preset.widthPhysical,
                              heightPhysical: preset.heightPhysical,
                              unit: preset.unit,
                            });
                            setActiveMenu(null);
                          }}
                          className={`w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                            isSelected ? 'bg-indigo-50 text-indigo-700 font-bold' : 'hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <span>{key}</span>
                          {isSelected && <Check className="w-4 h-4 text-indigo-600" />}
                        </button>
                      );
                    })
                  ) : (
                    DASHBOARD_PRESETS.map((p) => {
                      const isSelected = !canvas.pageSizePreset && canvas.presetName === p.name;
                      return (
                        <button
                          key={p.name}
                          type="button"
                          onClick={() => {
                            onUpdateCanvas({
                              presetName: p.name,
                              pageSizePreset: undefined,
                              width: p.width,
                              height: p.height,
                            });
                            setActiveMenu(null);
                          }}
                          className={`w-full text-left px-3 py-1.5 rounded-lg flex items-center justify-between transition-colors cursor-pointer ${
                            isSelected ? 'bg-indigo-50 text-indigo-700 font-bold' : 'hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <span>{p.name}</span>
                          {isSelected && <Check className="w-4 h-4 text-indigo-600" />}
                        </button>
                      );
                    })
                  )}

                  <div className="my-1 border-t border-slate-100" />

                  <button
                    type="button"
                    onClick={() => {
                      setShowCanvasPopover(true);
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <SlidersHorizontal className="w-4 h-4 text-slate-500" /> Canvas & Page Dimensions
                  </button>
                </div>
              )}
            </div>

            {/* HELP MENU */}
            <div className="relative">
              <button
                type="button"
                onClick={() => toggleMenu('help')}
                onMouseEnter={() => handleMouseEnterMenu('help')}
                aria-expanded={activeMenu === 'help'}
                aria-haspopup="true"
                className={`px-2.5 py-1 rounded-md font-medium text-xs transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-indigo-500 ${
                  activeMenu === 'help'
                    ? 'bg-slate-200 text-slate-900 font-bold'
                    : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                Help
              </button>
              {activeMenu === 'help' && (
                <div className="absolute top-full left-0 mt-1 w-52 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in duration-100">
                  <button
                    type="button"
                    onClick={() => {
                      setShowShortcutsModal(true);
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <Command className="w-4 h-4 text-indigo-600" /> Keyboard Shortcuts
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setShowAboutModal(true);
                      setActiveMenu(null);
                    }}
                    className="w-full text-left px-3 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <Info className="w-4 h-4 text-sky-600" /> About Data Pulse
                  </button>
                </div>
              )}
            </div>
          </nav>
        </div>

        {/* Right: Title, Type Badge, Auto-Save Status, Back Button */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Report Title */}
          {isEditingTitle ? (
            <input
              type="text"
              value={titleInput}
              onChange={(e) => setTitleInput(e.target.value)}
              onBlur={handleTitleSubmit}
              onKeyDown={(e) => e.key === 'Enter' && handleTitleSubmit()}
              autoFocus
              aria-label="Edit report title"
              className="px-2 py-0.5 bg-slate-50 border border-indigo-500 rounded text-xs font-bold text-slate-900 focus:outline-none"
            />
          ) : (
            <button
              type="button"
              onClick={() => {
                setTitleInput(dashboardTitle);
                setIsEditingTitle(true);
              }}
              className="flex items-center gap-1 text-left p-1 rounded hover:bg-slate-100 transition-colors focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
              title="Click to rename report"
              aria-label={`Rename report: ${dashboardTitle}`}
            >
              <h2 className="font-bold text-xs sm:text-sm text-slate-900 max-w-[120px] sm:max-w-[200px] truncate">
                {dashboardTitle}
              </h2>
              <Pencil className="w-3 h-3 text-slate-400 shrink-0" />
            </button>
          )}

          {/* Type Badge */}
          <span
            className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase border shrink-0 ${
              projectType === 'report'
                ? 'bg-amber-50 text-amber-700 border-amber-200'
                : 'bg-indigo-50 text-indigo-700 border-indigo-200'
            }`}
          >
            {projectType === 'report' ? 'Report' : 'Dashboard'}
          </span>

          {/* Auto-Save Indicator */}
          <div className="hidden lg:flex items-center gap-1 text-[11px] pl-1 shrink-0" title="Auto-save status">
            <div
              className={`w-2 h-2 rounded-full ${
                autoSaveStatus === 'saved'
                  ? 'bg-emerald-500'
                  : autoSaveStatus === 'saving'
                  ? 'bg-amber-500 animate-ping'
                  : 'bg-rose-500'
              }`}
            />
            <span className="text-slate-400 text-[10px] font-medium">
              {autoSaveStatus === 'saved' ? 'Saved' : autoSaveStatus === 'saving' ? 'Saving' : 'Unsaved'}
            </span>
          </div>

          {/* Neon Database Status Indicator */}
          <NeonStatusBadge compact />

          {/* Hub Navigation */}
          {onBackToHub && (
            <button
              type="button"
              onClick={onBackToHub}
              className="h-7 px-2.5 rounded-md bg-slate-100 hover:bg-slate-200 active:bg-slate-300 border border-slate-200/80 text-slate-700 hover:text-slate-900 transition-all text-xs font-semibold flex items-center gap-1 cursor-pointer"
              title="Back to Dashboard Hub"
              aria-label="Back to Dashboard Hub"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-slate-600 shrink-0" />
              <span className="hidden sm:inline">Hub</span>
            </button>
          )}
        </div>
      </div>

      {/* ROW 2: QUICK ACTION TOOLBAR / RIBBON */}
      <div className="h-11 px-3 sm:px-4 flex items-center justify-between bg-slate-50/80 border-b border-slate-200/80 text-xs gap-2">
        {/* Left Toolbar Commands */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Undo & Redo Group */}
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onUndo}
              disabled={!canUndo}
              className="w-8 h-8 flex items-center justify-center rounded-lg bg-white hover:bg-slate-100 active:bg-slate-200 border border-slate-200 text-slate-700 disabled:opacity-35 disabled:hover:bg-white transition-all focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
              title="Undo action (Ctrl+Z)"
              aria-label="Undo action"
            >
              <RotateCcw className="w-4 h-4 text-slate-600" />
            </button>
            <button
              type="button"
              onClick={onRedo}
              disabled={!canRedo}
              className="w-8 h-8 flex items-center justify-center rounded-lg bg-white hover:bg-slate-100 active:bg-slate-200 border border-slate-200 text-slate-700 disabled:opacity-35 disabled:hover:bg-white transition-all focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
              title="Redo action (Ctrl+Y)"
              aria-label="Redo action"
            >
              <RotateCw className="w-4 h-4 text-slate-600" />
            </button>
          </div>

          {/* Page Tabs Bar (Only in Report mode) */}
          {projectType === 'report' && (
            <>
              <div className="h-4 w-px bg-slate-200 mx-0.5" />
              <div className="flex items-center gap-1 bg-slate-200/60 p-0.5 rounded-lg">
                {pages.length > 1 && (
                  <div className="flex items-center pr-1 border-r border-slate-300/60 gap-0.5">
                    <button
                      type="button"
                      onClick={() => activePageIndex > 0 && onSelectPage && onSelectPage(pages[activePageIndex - 1].id)}
                      disabled={activePageIndex <= 0}
                      className="w-6 h-6 flex items-center justify-center rounded text-slate-600 hover:text-slate-900 hover:bg-slate-300/80 disabled:opacity-30 disabled:hover:bg-transparent transition-colors cursor-pointer"
                      title="Previous Page"
                      aria-label="Previous Page"
                    >
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] font-bold text-slate-600 px-1">
                      {activePageIndex + 1}/{pages.length}
                    </span>
                    <button
                      type="button"
                      onClick={() => activePageIndex < pages.length - 1 && onSelectPage && onSelectPage(pages[activePageIndex + 1].id)}
                      disabled={activePageIndex >= pages.length - 1}
                      className="w-6 h-6 flex items-center justify-center rounded text-slate-600 hover:text-slate-900 hover:bg-slate-300/80 disabled:opacity-30 disabled:hover:bg-transparent transition-colors cursor-pointer"
                      title="Next Page"
                      aria-label="Next Page"
                    >
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Page Tabs */}
                <div className="flex items-center gap-1 max-w-[180px] sm:max-w-[340px] overflow-x-auto no-scrollbar">
                  {pages.map((p) => {
                    const isActive = p.id === (activePageId || pages[0]?.id);
                    return (
                      <div
                        key={p.id}
                        onClick={() => onSelectPage && onSelectPage(p.id)}
                        className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-semibold cursor-pointer transition-all ${
                          isActive
                            ? 'bg-white text-indigo-700 shadow-xs font-bold border border-slate-200'
                            : 'text-slate-600 hover:text-slate-900 hover:bg-slate-300/60'
                        }`}
                      >
                        <FileText className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />

                        {editingPageId === p.id ? (
                          <input
                            type="text"
                            value={pageNameInput}
                            onChange={(e) => setPageNameInput(e.target.value)}
                            onBlur={() => handlePageRenameSubmit(p.id)}
                            onKeyDown={(e) => e.key === 'Enter' && handlePageRenameSubmit(p.id)}
                            autoFocus
                            onClick={(e) => e.stopPropagation()}
                            aria-label="Rename page input"
                            className="w-20 px-1 py-0.5 bg-white border border-indigo-500 rounded text-xs font-semibold text-slate-900 focus:outline-none"
                          />
                        ) : (
                          <span
                            onDoubleClick={(e) => {
                              e.stopPropagation();
                              setEditingPageId(p.id);
                              setPageNameInput(p.name);
                            }}
                            className="truncate max-w-[100px]"
                            title="Double click to rename page"
                          >
                            {p.name}
                          </span>
                        )}

                        {isActive && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setEditingPageId(p.id);
                              setPageNameInput(p.name);
                            }}
                            className="p-0.5 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded transition-colors"
                            title="Rename page"
                            aria-label={`Rename page ${p.name}`}
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                        )}

                        {pages.length > 1 && onDeletePage && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDeletePage(p.id);
                            }}
                            className="p-0.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                            title={`Delete page ${p.name}`}
                            aria-label={`Delete page ${p.name}`}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Add Page Button */}
                {onAddPage && (
                  <button
                    type="button"
                    onClick={onAddPage}
                    className="w-6 h-6 flex items-center justify-center hover:bg-slate-300 text-slate-700 hover:text-slate-900 rounded-md transition-colors cursor-pointer"
                    title="Add Report Page"
                    aria-label="Add Report Page"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </>
          )}

          {onOpenFilters && (
            <>
              <div className="h-4 w-px bg-slate-200 mx-0.5 hidden sm:block" />
              <button
                type="button"
                onClick={onOpenFilters}
                title="Configure Global Data Filters"
                aria-label="Configure Global Data Filters"
                className={`h-8 px-2.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer ${
                  activeFilterCount > 0
                    ? 'bg-sky-600 hover:bg-sky-700 text-white border-sky-600 shadow-xs'
                    : 'bg-white hover:bg-slate-100 active:bg-slate-200 border-slate-200 text-slate-700'
                }`}
              >
                <Filter className="w-3.5 h-3.5 shrink-0" />
                <span className="hidden xl:inline">Filters</span>
                {activeFilterCount > 0 && (
                  <span className="bg-white text-sky-700 px-1.5 py-0.2 rounded-full text-[10px] font-black">
                    {activeFilterCount}
                  </span>
                )}
              </button>
            </>
          )}

          {onOpenDataCleaning && (
            <>
              <div className="h-4 w-px bg-slate-200 mx-0.5 hidden sm:block" />
              <button
                type="button"
                onClick={onOpenDataCleaning}
                title="Explore the data (Clean & Transform Editor)"
                aria-label="Explore the data"
                className="h-8 px-2.5 rounded-lg border border-sky-300 bg-sky-50 hover:bg-sky-100 text-sky-800 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                <span className="hidden sm:inline">Explore the data</span>
              </button>
            </>
          )}

          {onOpenSelectDatasets && (
            <button
              type="button"
              onClick={onOpenSelectDatasets}
              title="Select Global Datasets for this Dashboard"
              aria-label="Select Datasets"
              className="h-8 px-2.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
            >
              <Database className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span className="hidden sm:inline">Select Datasets</span>
            </button>
          )}

          {onChangeWorkspaceView && (
            <>
              <div className="h-4 w-px bg-slate-200 mx-0.5 hidden sm:block" />
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 shadow-2xs">
                <button
                  type="button"
                  onClick={() => onChangeWorkspaceView('canvas')}
                  className={`h-7 px-2.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeWorkspaceView !== 'data_model'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Canvas & Dashboard View"
                >
                  <Layout className="w-3.5 h-3.5 text-sky-600" />
                  <span className="hidden md:inline">Canvas</span>
                </button>
                <button
                  type="button"
                  onClick={() => onChangeWorkspaceView('data_model')}
                  className={`h-7 px-2.5 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeWorkspaceView === 'data_model'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="Star Schema Data Model View"
                >
                  <Network className="w-3.5 h-3.5 text-indigo-600" />
                  <span className="hidden md:inline">Data Model</span>
                </button>
              </div>
            </>
          )}
        </div>

        {/* Right Toolbar Actions */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Canvas & Zoom Popover Trigger */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowCanvasPopover(!showCanvasPopover)}
              className="h-8 px-2.5 bg-white hover:bg-slate-100 active:bg-slate-200 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 flex items-center gap-1.5 transition-all focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer shadow-2xs"
              title="Adjust Canvas Size & Dimensions"
              aria-label="Adjust Canvas Size & Dimensions"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-slate-600 shrink-0" />
              <span className="hidden md:inline text-slate-600 font-medium">Canvas:</span>
              <span className="text-slate-900 font-mono font-bold text-xs bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                {canvas.width || 1920} × {canvas.height || 1080}
              </span>
              <span className="text-indigo-600 font-mono font-bold text-[11px] hidden sm:inline">
                {Math.round(canvas.zoom * 100)}%
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
            </button>

            {/* Canvas Popover */}
            {showCanvasPopover && (
              <div className="absolute top-10 right-0 w-84 p-4 bg-white border border-slate-200 rounded-2xl shadow-2xl z-50 text-xs space-y-3.5 text-slate-800 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <div className="flex items-center gap-2">
                    <Maximize2 className="w-4 h-4 text-indigo-600" />
                    <span className="font-bold text-slate-900 text-sm">Canvas Size &amp; Settings</span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
                    {canvas.width || 1920} × {canvas.height || 1080} px
                  </span>
                </div>

                {/* MANUAL CANVAS SIZE INPUTS */}
                <div className="space-y-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 text-[11px] uppercase tracking-wider">
                      Manual Dimensions (px)
                    </span>
                    <button
                      type="button"
                      onClick={() => setLockAspectRatio(!lockAspectRatio)}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                        lockAspectRatio
                          ? 'bg-indigo-600 text-white'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                      title={lockAspectRatio ? 'Aspect ratio locked' : 'Aspect ratio unlocked'}
                    >
                      {lockAspectRatio ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                      <span>{lockAspectRatio ? 'Ratio Locked' : 'Unlock Ratio'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    {/* Width input */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-semibold text-slate-600">Width</label>
                        <div className="flex items-center gap-0.5">
                          <button
                            type="button"
                            onClick={() => {
                              const newW = Math.max(400, (canvas.width || 1920) - 50);
                              let newH = canvas.height || 1080;
                              if (lockAspectRatio && (canvas.width || 1920) > 0) {
                                newH = Math.round(newW * ((canvas.height || 1080) / (canvas.width || 1920)));
                              }
                              onUpdateCanvas({
                                width: newW,
                                height: newH,
                                pageSizePreset: 'Custom Size',
                                presetName: `Custom (${newW}×${newH})`,
                              });
                            }}
                            className="px-1 py-0.5 bg-white border border-slate-200 text-slate-600 rounded text-[9px] font-bold hover:bg-slate-100 cursor-pointer"
                          >
                            -50
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const newW = Math.min(8000, (canvas.width || 1920) + 50);
                              let newH = canvas.height || 1080;
                              if (lockAspectRatio && (canvas.width || 1920) > 0) {
                                newH = Math.round(newW * ((canvas.height || 1080) / (canvas.width || 1920)));
                              }
                              onUpdateCanvas({
                                width: newW,
                                height: newH,
                                pageSizePreset: 'Custom Size',
                                presetName: `Custom (${newW}×${newH})`,
                              });
                            }}
                            className="px-1 py-0.5 bg-white border border-slate-200 text-slate-600 rounded text-[9px] font-bold hover:bg-slate-100 cursor-pointer"
                          >
                            +50
                          </button>
                        </div>
                      </div>
                      <div className="relative">
                        <input
                          type="number"
                          min={400}
                          max={8000}
                          step={10}
                          value={canvas.width || 1920}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 400;
                            const clamped = Math.max(400, Math.min(8000, val));
                            let newH = canvas.height || 1080;
                            if (lockAspectRatio && (canvas.width || 1920) > 0) {
                              newH = Math.round(clamped * ((canvas.height || 1080) / (canvas.width || 1920)));
                            }
                            onUpdateCanvas({
                              width: clamped,
                              height: newH,
                              pageSizePreset: 'Custom Size',
                              presetName: `Custom (${clamped}×${newH})`,
                            });
                          }}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-indigo-500 pr-7"
                        />
                        <span className="absolute right-2 top-2 text-[10px] text-slate-400 font-mono">px</span>
                      </div>
                    </div>

                    {/* Height input */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-semibold text-slate-600">Height</label>
                        <div className="flex items-center gap-0.5">
                          <button
                            type="button"
                            onClick={() => {
                              const newH = Math.max(300, (canvas.height || 1080) - 50);
                              let newW = canvas.width || 1920;
                              if (lockAspectRatio && (canvas.height || 1080) > 0) {
                                newW = Math.round(newH * ((canvas.width || 1920) / (canvas.height || 1080)));
                              }
                              onUpdateCanvas({
                                width: newW,
                                height: newH,
                                pageSizePreset: 'Custom Size',
                                presetName: `Custom (${newW}×${newH})`,
                              });
                            }}
                            className="px-1 py-0.5 bg-white border border-slate-200 text-slate-600 rounded text-[9px] font-bold hover:bg-slate-100 cursor-pointer"
                          >
                            -50
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              const newH = Math.min(8000, (canvas.height || 1080) + 50);
                              let newW = canvas.width || 1920;
                              if (lockAspectRatio && (canvas.height || 1080) > 0) {
                                newW = Math.round(newH * ((canvas.width || 1920) / (canvas.height || 1080)));
                              }
                              onUpdateCanvas({
                                width: newW,
                                height: newH,
                                pageSizePreset: 'Custom Size',
                                presetName: `Custom (${newW}×${newH})`,
                              });
                            }}
                            className="px-1 py-0.5 bg-white border border-slate-200 text-slate-600 rounded text-[9px] font-bold hover:bg-slate-100 cursor-pointer"
                          >
                            +50
                          </button>
                        </div>
                      </div>
                      <div className="relative">
                        <input
                          type="number"
                          min={300}
                          max={8000}
                          step={10}
                          value={canvas.height || 1080}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 300;
                            const clamped = Math.max(300, Math.min(8000, val));
                            let newW = canvas.width || 1920;
                            if (lockAspectRatio && (canvas.height || 1080) > 0) {
                              newW = Math.round(clamped * ((canvas.width || 1920) / (canvas.height || 1080)));
                            }
                            onUpdateCanvas({
                              width: newW,
                              height: clamped,
                              pageSizePreset: 'Custom Size',
                              presetName: `Custom (${newW}×${clamped})`,
                            });
                          }}
                          className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-indigo-500 pr-7"
                        />
                        <span className="absolute right-2 top-2 text-[10px] text-slate-400 font-mono">px</span>
                      </div>
                    </div>
                  </div>

                  {/* Aspect Ratio Chips */}
                  <div className="pt-2 border-t border-slate-200/60">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Quick Aspect Ratios
                    </span>
                    <div className="flex flex-wrap gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateCanvas({
                            width: 1920,
                            height: 1080,
                            pageSizePreset: 'Custom Size',
                            presetName: '1920×1080 (16:9)',
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                          canvas.width === 1920 && canvas.height === 1080
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        16:9 (1920×1080)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateCanvas({
                            width: 1920,
                            height: 1200,
                            pageSizePreset: 'Custom Size',
                            presetName: '1920×1200 (16:10)',
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                          canvas.width === 1920 && canvas.height === 1200
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        16:10 (1920×1200)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateCanvas({
                            width: 1024,
                            height: 768,
                            pageSizePreset: 'Custom Size',
                            presetName: '1024×768 (4:3)',
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                          canvas.width === 1024 && canvas.height === 768
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        4:3 (1024×768)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateCanvas({
                            width: 1080,
                            height: 1080,
                            pageSizePreset: 'Custom Size',
                            presetName: '1080×1080 (1:1)',
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                          canvas.width === 1080 && canvas.height === 1080
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        1:1 (1080×1080)
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateCanvas({
                            width: 2560,
                            height: 1080,
                            pageSizePreset: 'Custom Size',
                            presetName: '21:9 Ultra-wide',
                          })
                        }
                        className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer transition-colors ${
                          canvas.width === 2560 && canvas.height === 1080
                            ? 'bg-indigo-600 text-white'
                            : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        21:9 (2560×1080)
                      </button>
                    </div>
                  </div>
                </div>

                {/* Preset Selector */}
                <div className="space-y-1">
                  <span className="text-slate-500 font-medium text-[11px]">
                    {projectType === 'report' ? 'Paper / Page Size Preset' : 'Screen Size Preset'}
                  </span>
                  <select
                    value={projectType === 'report' ? (canvas.pageSizePreset || 'A4 Portrait') : (canvas.presetName || '1920×1080 Full HD')}
                    onChange={(e) => {
                      const val = e.target.value;
                      if (projectType === 'report') {
                        const presetKey = val as ReportPageSizePreset;
                        const foundPreset = REPORT_PAGE_PRESETS[presetKey];
                        if (foundPreset) {
                          onUpdateCanvas({
                            pageSizePreset: presetKey,
                            presetName: presetKey,
                            orientation: foundPreset.orientation,
                            widthPhysical: foundPreset.widthPhysical,
                            heightPhysical: foundPreset.heightPhysical,
                            unit: foundPreset.unit,
                          });
                        }
                      } else {
                        const found = DASHBOARD_PRESETS.find((p) => p.name === val);
                        if (found) {
                          onUpdateCanvas({
                            presetName: found.name,
                            pageSizePreset: undefined,
                            width: found.width,
                            height: found.height,
                          });
                        }
                      }
                    }}
                    aria-label={projectType === 'report' ? 'Select paper page size preset' : 'Select dashboard screen preset'}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
                  >
                    {projectType === 'report' ? (
                      Object.keys(REPORT_PAGE_PRESETS).map((key) => (
                        <option key={key} value={key}>
                          {key}
                        </option>
                      ))
                    ) : (
                      DASHBOARD_PRESETS.map((p) => (
                        <option key={p.name} value={p.name}>
                          {p.name}
                        </option>
                      ))
                    )}
                  </select>
                </div>

                {/* Zoom Controls */}
                <div className="space-y-1.5">
                  <span className="text-slate-500 font-medium text-[11px]">Zoom &amp; View Scale</span>
                  <div className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-lg p-1">
                    <button
                      type="button"
                      onClick={() => onUpdateCanvas({ zoom: Math.max(0.3, canvas.zoom - 0.1) })}
                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded transition-colors"
                      title="Zoom Out"
                      aria-label="Zoom Out"
                    >
                      <ZoomOut className="w-4 h-4" />
                    </button>
                    <span className="font-mono font-bold text-indigo-600 text-xs">
                      {Math.round(canvas.zoom * 100)}%
                    </span>
                    <button
                      type="button"
                      onClick={() => onUpdateCanvas({ zoom: Math.min(2.0, canvas.zoom + 0.1) })}
                      className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-200 rounded transition-colors"
                      title="Zoom In"
                      aria-label="Zoom In"
                    >
                      <ZoomIn className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateCanvas({ zoom: 1.0 })}
                      className="px-2 py-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded text-[10px] font-bold transition-colors"
                      title="Reset Zoom to 100%"
                    >
                      100%
                    </button>
                  </div>
                  {/* Fit Buttons */}
                  <div className="grid grid-cols-2 gap-1 pt-1">
                    <button
                      type="button"
                      onClick={() => onUpdateCanvas({ zoom: 0.70 })}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[10px] font-bold transition-colors"
                    >
                      Fit Page
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateCanvas({ zoom: 0.95 })}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[10px] font-bold transition-colors"
                    >
                      Fit Width
                    </button>
                  </div>
                </div>

                {/* Grid Snapping */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1.5">
                    <Grid className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-600 font-medium text-[11px]">Grid Snapping</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onUpdateCanvas({ snapToGrid: !canvas.snapToGrid })}
                    className={`px-2.5 py-1 rounded text-[11px] font-bold border transition-colors cursor-pointer ${
                      canvas.snapToGrid
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                        : 'bg-slate-100 text-slate-500 border-slate-200'
                    }`}
                  >
                    {canvas.snapToGrid ? 'ON' : 'OFF'}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setShowCanvasPopover(false)}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl mt-1 transition-colors cursor-pointer shadow-sm"
                >
                  Apply &amp; Close
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={onTogglePreviewMode}
            className="h-8 px-2.5 bg-slate-100 hover:bg-slate-200 active:bg-slate-300 border border-slate-200/70 rounded-lg text-xs font-semibold text-slate-800 flex items-center gap-1.5 transition-all focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
            title="Toggle Preview Mode"
            aria-label="Toggle Preview Mode"
          >
            <Eye className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            <span className="hidden sm:inline">Preview</span>
          </button>

          {onExportPdf && (
            <button
              type="button"
              onClick={onExportPdf}
              className="h-8 px-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all focus-visible:outline-2 focus-visible:outline-emerald-500 cursor-pointer"
              title="Export Report to PDF"
              aria-label="Export Report to PDF"
            >
              <Printer className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">Export PDF</span>
            </button>
          )}

          <button
            type="button"
            onClick={onSaveDashboard}
            className="h-8 px-3 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
            title="Save Report Canvas"
            aria-label="Save Report Canvas"
          >
            <Save className="w-3.5 h-3.5 shrink-0" />
            <span>Save</span>
          </button>
        </div>
      </div>

      {/* KEYBOARD SHORTCUTS MODAL */}
      {showShortcutsModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Command className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">Keyboard Shortcuts</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowShortcutsModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Undo last change</span>
                <kbd className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded font-mono font-bold text-[11px] text-slate-700">
                  Ctrl + Z
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Redo action</span>
                <kbd className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded font-mono font-bold text-[11px] text-slate-700">
                  Ctrl + Y
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Save report state</span>
                <kbd className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded font-mono font-bold text-[11px] text-slate-700">
                  Ctrl + S
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Export PDF</span>
                <kbd className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded font-mono font-bold text-[11px] text-slate-700">
                  Ctrl + P
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-slate-100">
                <span className="text-slate-600 font-medium">Exit Preview / Close Popover</span>
                <kbd className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded font-mono font-bold text-[11px] text-slate-700">
                  Esc
                </kbd>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="text-slate-600 font-medium">Rename Title / Page Tab</span>
                <span className="text-slate-500 font-medium text-[11px]">Double Click</span>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowShortcutsModal(false)}
              className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* ABOUT DATA PULSE MODAL */}
      {showAboutModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-sm w-full p-6 space-y-4 text-center animate-in fade-in zoom-in-95 duration-150">
            <div className="flex justify-center">
              <BrandLogo size={48} />
            </div>

            <div>
              <h3 className="font-black text-lg text-slate-900 tracking-tight">DATA PULSE</h3>
              <p className="text-xs font-bold text-indigo-600">Report & Dashboard Authoring Suite</p>
              <p className="text-xs text-slate-500 mt-2">
                Version 2.0 • Modern SaaS interactive document engine with real-time analytics, PDF export, multi-page layout, and custom widget canvas.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowAboutModal(false)}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
