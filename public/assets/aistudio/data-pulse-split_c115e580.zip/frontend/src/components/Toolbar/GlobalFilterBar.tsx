import React, { useState } from 'react';
import { DataFilter, Dataset } from '../../types/dashboard';
import { FilterListEditor } from '../Filters/FilterListEditor';
import { Filter, Search, Plus, X, SlidersHorizontal, Check, RefreshCw } from 'lucide-react';
import { applyDataFilters } from '../../utils/dataProcessor';

interface Props {
  datasets: Dataset[];
  globalFilters: DataFilter[];
  onUpdateGlobalFilters: (filters: DataFilter[]) => void;
  isModalOpenExternal?: boolean;
  onCloseModalExternal?: () => void;
}

export const GlobalFilterBar: React.FC<Props> = ({
  datasets,
  globalFilters = [],
  onUpdateGlobalFilters,
  isModalOpenExternal,
  onCloseModalExternal,
}) => {
  const [internalModalOpen, setInternalModalOpen] = useState(false);
  const isModalOpen = isModalOpenExternal !== undefined ? isModalOpenExternal : internalModalOpen;

  const setIsModalOpen = (open: boolean) => {
    setInternalModalOpen(open);
    if (!open && onCloseModalExternal) {
      onCloseModalExternal();
    }
  };
  const [searchTerm, setSearchTerm] = useState('');

  const activeFilters = globalFilters.filter((f) => f.enabled !== false && f.column);

  // Compute total filtered rows count vs total rows count across datasets
  const primaryDataset = datasets[0];
  
  let searchFilter: DataFilter[] = [];
  if (searchTerm.trim() && primaryDataset) {
    // Find text/string columns to search across
    const textCols = primaryDataset.columns.filter((c) => c.type === 'string' || c.type === 'date');
    if (textCols.length > 0) {
      searchFilter = [
        {
          id: 'search_filter',
          column: textCols[0].name,
          operator: 'contains',
          value: searchTerm.trim(),
          enabled: true,
        },
      ];
    }
  }

  const allActiveFilters = [...activeFilters, ...searchFilter];
  const primaryData = primaryDataset?.cleanedData || primaryDataset?.data || [];
  const filteredRows = primaryDataset
    ? applyDataFilters(primaryData, allActiveFilters).length
    : 0;
  const totalRows =
    primaryDataset?.rowCount ??
    (primaryDataset as any)?.row_count ??
    primaryData.length ??
    0;

  const handleToggleFilter = (filterId: string) => {
    onUpdateGlobalFilters(
      globalFilters.map((f) =>
        f.id === filterId ? { ...f, enabled: !(f.enabled ?? true) } : f
      )
    );
  };

  const handleRemoveFilter = (filterId: string) => {
    onUpdateGlobalFilters(globalFilters.filter((f) => f.id !== filterId));
  };

  const handleClearAll = () => {
    onUpdateGlobalFilters([]);
    setSearchTerm('');
  };

  return (
    <div className="w-full bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between gap-3 text-xs z-10 shadow-2xs">
      {/* Left: Filter Bar Badge & Active Chips */}
      <div className="flex items-center gap-2 overflow-x-auto shrink flex-1 py-0.5">
        <button
          onClick={() => setIsModalOpen(true)}
          className={`py-1.5 px-3 rounded-lg border font-bold flex items-center gap-2 transition-all shrink-0 ${
            activeFilters.length > 0
              ? 'bg-sky-600 text-white border-sky-600 shadow-xs'
              : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
          }`}
        >
          <Filter className="w-3.5 h-3.5" />
          <span>Data Filters</span>
          {activeFilters.length > 0 && (
            <span className="bg-white text-sky-700 rounded-full px-1.5 py-0.2 text-[10px] font-extrabold">
              {activeFilters.length}
            </span>
          )}
        </button>

        {/* Search Field */}
        <div className="relative min-w-[180px] max-w-[240px] shrink-0">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Quick search data..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-6 py-1 bg-slate-50 border border-slate-200 focus:border-sky-500 rounded-lg text-xs focus:outline-none"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>

        {/* Active Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          {globalFilters.map((f) => {
            const isEnabled = f.enabled !== false;
            return (
              <div
                key={f.id}
                className={`py-1 px-2.5 rounded-full border text-[11px] font-semibold flex items-center gap-1.5 shrink-0 transition-all ${
                  isEnabled
                    ? 'bg-sky-50 border-sky-300 text-sky-900 shadow-2xs'
                    : 'bg-slate-100 border-slate-200 text-slate-400 line-through opacity-70'
                }`}
              >
                <button
                  onClick={() => handleToggleFilter(f.id)}
                  className="hover:underline"
                  title="Toggle filter"
                >
                  <span className="font-extrabold">{f.column}</span> {f.operator}{' '}
                  <span className="font-mono">{f.operator === 'between' ? `${f.value}-${f.value2}` : String(f.value)}</span>
                </button>
                <button
                  onClick={() => handleRemoveFilter(f.id)}
                  className="text-slate-400 hover:text-rose-600 transition-colors"
                  title="Remove filter"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right: Record Counter & Add / Clear controls */}
      <div className="flex items-center gap-2 shrink-0">
        {primaryDataset && (
          <div className="text-[11px] text-slate-500 font-medium hidden md:block">
            Matching <span className="font-bold text-slate-800">{(Number(filteredRows) || 0).toLocaleString()}</span> / {(Number(totalRows) || 0).toLocaleString()} rows
          </div>
        )}

        {(globalFilters.length > 0 || searchTerm) && (
          <button
            onClick={handleClearAll}
            className="py-1 px-2 text-[11px] font-bold text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
          >
            Clear All
          </button>
        )}

        <button
          onClick={() => setIsModalOpen(true)}
          className="py-1 px-2.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-800 font-bold rounded-lg flex items-center gap-1 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Rule</span>
        </button>
      </div>

      {/* Filter Management Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-sky-600" />
                <h3 className="font-extrabold text-sm text-slate-900">Dashboard Data Filter Rules</h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-800 rounded-lg transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 max-h-[80vh] overflow-y-auto">
              <FilterListEditor
                filters={globalFilters}
                datasets={datasets}
                onUpdateFilters={(newFilters) => onUpdateGlobalFilters(newFilters)}
                isGlobal={true}
              />
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setIsModalOpen(false)}
                className="py-1.5 px-4 bg-[#0284C7] hover:bg-sky-700 text-white font-bold rounded-lg shadow-sm"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
