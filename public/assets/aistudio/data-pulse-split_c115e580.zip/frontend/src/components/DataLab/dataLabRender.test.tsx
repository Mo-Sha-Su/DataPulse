import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { describe, expect, it } from 'vitest';
import { StepRail } from './StepRail';
import { ColumnInspector } from './ColumnInspector';
import { CommandBar } from './CommandBar';
import { CommandPalette } from './CommandPalette';
import { buildLabActions } from './labActions';
import { evaluatePipeline, tracePipeline } from '../../utils/transformationEngine';
import { DataCleaningStep } from '../../types/dataCleaning';

const rows = [
  { id: 'a', city: ' Paris ', qty: null },
  { id: 'b', city: 'paris', qty: 4 },
  { id: 'b', city: 'paris', qty: 4 },
];
const mk = (id: string, type: DataCleaningStep['type'], name: string, params: any = {}): DataCleaningStep => ({ id, name, type, description: `${name} desc`, mFormula: '', params });
const steps = [mk('s0', 'source', 'Source'), mk('s1', 'remove_duplicates', 'Removed Duplicates', { columns: ['id', 'city', 'qty'] })];
const noop = () => {};

describe('Data Lab components render real data', () => {
  it('StepRail shows each step with what it did to the data', () => {
    const html = renderToStaticMarkup(
      <StepRail queryName="Orders" sourceType="csv" steps={steps} trace={tracePipeline(rows, steps)} selectedStepId="s1"
        onSelectStep={noop} onDeleteStep={noop} onRenameStep={noop} onEditStepSettings={noop} onMoveStepUp={noop} onMoveStepDown={noop} onQueryNameChange={noop} />
    );
    expect(html).toContain('Orders');
    expect(html).toContain('Removed Duplicates');
    expect(html).toContain('−1 row'); // 3 rows -> 2 rows
    expect(html).toContain('3 rows × 3 cols'); // source size
    expect(html).toContain('2 × 3'); // output
    expect(html).not.toContain('Viewing step'); // latest step selected
  });

  it('StepRail warns when you are looking at an earlier step', () => {
    const html = renderToStaticMarkup(
      <StepRail queryName="Orders" sourceType="csv" steps={steps} trace={tracePipeline(rows, steps)} selectedStepId="s0"
        onSelectStep={noop} onDeleteStep={noop} onRenameStep={noop} onEditStepSettings={noop} onMoveStepUp={noop} onMoveStepDown={noop} onQueryNameChange={noop} />
    );
    expect(html).toContain('Viewing step');
    expect(html).toContain('Latest');
  });

  it('ColumnInspector profiles the selected column and offers fixes from the actual values', () => {
    const ev = evaluatePipeline(rows, [steps[0]]);
    const html = renderToStaticMarkup(<ColumnInspector columns={ev.columns} rows={ev.rows} selectedColumn="city" onApply={noop} onSelectColumn={noop} />);
    expect(html).toContain('city');
    expect(html).toContain('Trim stray spaces');
    expect(html).toContain('Most common');
    expect(html).toContain('Apply');
  });

  it('ColumnInspector with no selection shows table-wide health and duplicate rows', () => {
    const ev = evaluatePipeline(rows, [steps[0]]);
    const html = renderToStaticMarkup(<ColumnInspector columns={ev.columns} rows={ev.rows} selectedColumn={null} onApply={noop} onSelectColumn={noop} />);
    expect(html).toContain('Data health');
    expect(html).toContain('Remove duplicate rows');
  });

  it('CommandBar lists every category and tells you what is targeted', () => {
    const actions = buildLabActions(new Proxy({}, { get: () => () => {} }) as any);
    const html = renderToStaticMarkup(<CommandBar actions={actions} selectedColumn="qty" selectedType="Whole Number" onOpenPalette={noop} />);
    ['Clean', 'Rows', 'Columns', 'Compute'].forEach((g) => expect(html).toContain(g));
    expect(html).toContain('Acting on');
    expect(html).toContain('qty');
  });

  it('CommandPalette renders and disables column actions when nothing is selected', () => {
    const actions = buildLabActions(new Proxy({}, { get: () => () => {} }) as any);
    const html = renderToStaticMarkup(<CommandPalette actions={actions} selectedColumn={null} onClose={noop} />);
    expect(html).toContain('role="dialog"');
    expect(html).toContain('Select a column first');
    expect(html).toContain('Remove duplicates');
  });
});
