import React from 'react';
import { FileSpreadsheet, Plus, Sparkles } from 'lucide-react';
import { QueryModel } from '../../types/dataCleaning';

interface Props {
  queries: QueryModel[];
  activeId?: string;
  onSelect: (id: string) => void;
  onAdd: () => void;
  onSample: () => void;
}

export const QueryTabs: React.FC<Props> = ({ queries, activeId, onSelect, onAdd, onSample }) => (
  <div className="h-10 shrink-0 flex items-end gap-1 px-3 bg-lab-bg border-b border-lab-line overflow-x-auto lab-scroll" role="tablist" aria-label="Queries">
    {queries.map((q) => {
      const on = q.id === activeId;
      return (
        <button
          key={q.id}
          type="button"
          role="tab"
          aria-selected={on}
          onClick={() => onSelect(q.id)}
          className={`h-9 -mb-px px-3.5 rounded-t-xl flex items-center gap-2 text-[12.5px] font-semibold border border-b-0 whitespace-nowrap transition-colors ${
            on ? 'bg-lab-panel text-lab-text border-lab-line-strong' : 'text-lab-dim border-transparent hover:text-lab-text hover:bg-lab-panel/60'
          }`}
        >
          <FileSpreadsheet className={`w-3.5 h-3.5 ${on ? 'text-pulse-400' : 'text-lab-faint'}`} />
          <span className="max-w-44 truncate">{q.name}</span>
          <span className="font-mono text-[9px] px-1 rounded bg-lab-raised text-lab-dim uppercase">{q.sourceType}</span>
        </button>
      );
    })}
    <button type="button" onClick={onAdd} className="h-8 mb-0.5 px-2.5 rounded-lg flex items-center gap-1.5 text-[12px] text-lab-dim hover:text-lab-text hover:bg-lab-panel" title="Add a CSV or Excel file as a new query">
      <Plus className="w-3.5 h-3.5" /> Add file
    </button>
    <button type="button" onClick={onSample} className="h-8 mb-0.5 px-2.5 rounded-lg flex items-center gap-1.5 text-[12px] text-amber-300/90 hover:text-amber-200 hover:bg-amber-400/10" title="Load a deliberately messy sample to try the tools">
      <Sparkles className="w-3.5 h-3.5" /> Messy sample
    </button>
  </div>
);
