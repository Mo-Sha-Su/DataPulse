import type { LucideIcon } from 'lucide-react';
import {
  Database, Hash, Pencil, Trash2, Copy, Columns2, Combine, Replace, CircleSlash, AlertCircle, ArrowDownToLine,
  ArrowUpToLine, ListFilter, ListX, Rows3, ArrowUpAZ, CaseSensitive, Calculator, CalendarDays, FunctionSquare,
  CopyMinus, MoveHorizontal, Heading,
} from 'lucide-react';
import { DataCleaningStepType } from '../../types/dataCleaning';
import { LabGroup } from './labActions';

export interface StepMeta {
  icon: LucideIcon;
  group: LabGroup | 'source';
  color: string;
  label: string;
}

const C = {
  source: 'var(--color-pulse-400)',
  clean: 'var(--color-cat-clean)',
  shape: 'var(--color-cat-shape)',
  columns: 'var(--color-cat-columns)',
  compute: 'var(--color-cat-compute)',
};

export const STEP_META: Record<DataCleaningStepType, StepMeta> = {
  source: { icon: Database, group: 'source', color: C.source, label: 'Source' },
  promoted_headers: { icon: Heading, group: 'shape', color: C.shape, label: 'Headers' },
  changed_type: { icon: Hash, group: 'compute', color: C.compute, label: 'Type' },
  rename_column: { icon: Pencil, group: 'columns', color: C.columns, label: 'Rename' },
  remove_columns: { icon: Trash2, group: 'columns', color: C.columns, label: 'Remove columns' },
  duplicate_column: { icon: Copy, group: 'columns', color: C.columns, label: 'Duplicate' },
  reorder_columns: { icon: MoveHorizontal, group: 'columns', color: C.columns, label: 'Reorder' },
  move_column: { icon: MoveHorizontal, group: 'columns', color: C.columns, label: 'Move' },
  replace_values: { icon: Replace, group: 'clean', color: C.clean, label: 'Replace' },
  replace_errors: { icon: AlertCircle, group: 'clean', color: C.clean, label: 'Fix errors' },
  replace_nulls: { icon: CircleSlash, group: 'clean', color: C.clean, label: 'Fill empty' },
  fill_down: { icon: ArrowDownToLine, group: 'clean', color: C.clean, label: 'Fill down' },
  fill_up: { icon: ArrowUpToLine, group: 'clean', color: C.clean, label: 'Fill up' },
  filter_rows: { icon: ListFilter, group: 'shape', color: C.shape, label: 'Filter' },
  remove_rows: { icon: ListX, group: 'shape', color: C.shape, label: 'Remove rows' },
  keep_rows: { icon: Rows3, group: 'shape', color: C.shape, label: 'Keep rows' },
  sort: { icon: ArrowUpAZ, group: 'shape', color: C.shape, label: 'Sort' },
  text_transform: { icon: CaseSensitive, group: 'clean', color: C.clean, label: 'Text' },
  number_transform: { icon: Calculator, group: 'compute', color: C.compute, label: 'Math' },
  date_transform: { icon: CalendarDays, group: 'compute', color: C.compute, label: 'Date' },
  split_column: { icon: Columns2, group: 'columns', color: C.columns, label: 'Split' },
  merge_columns: { icon: Combine, group: 'columns', color: C.columns, label: 'Merge' },
  remove_duplicates: { icon: CopyMinus, group: 'shape', color: C.shape, label: 'Dedupe' },
  add_custom_column: { icon: FunctionSquare, group: 'compute', color: C.compute, label: 'Custom column' },
};

export const metaFor = (t: DataCleaningStepType): StepMeta =>
  STEP_META[t] || { icon: Database, group: 'shape', color: C.shape, label: String(t) };

/** "−6 rows", "+1 col" style deltas between two consecutive trace points. */
export function impactChips(
  prev: { rows: number; columns: number; errors: number; empty?: number } | null,
  cur: { rows: number; columns: number; errors: number; empty?: number }
): { key: string; text: string; tone: 'up' | 'down' | 'bad' | 'good' }[] {
  if (!prev) return [];
  const chips: { key: string; text: string; tone: 'up' | 'down' | 'bad' | 'good' }[] = [];
  const dr = cur.rows - prev.rows;
  const dc = cur.columns - prev.columns;
  const de = cur.errors - prev.errors;
  if (dr !== 0) chips.push({ key: 'rows', text: `${dr > 0 ? '+' : '−'}${Math.abs(dr).toLocaleString()} row${Math.abs(dr) === 1 ? '' : 's'}`, tone: dr > 0 ? 'up' : 'down' });
  if (dc !== 0) chips.push({ key: 'cols', text: `${dc > 0 ? '+' : '−'}${Math.abs(dc)} col${Math.abs(dc) === 1 ? '' : 's'}`, tone: dc > 0 ? 'up' : 'down' });
  const dm = (cur.empty ?? 0) - (prev.empty ?? 0);
  if (dm < 0 && dr === 0) chips.push({ key: 'empty', text: `${Math.abs(dm).toLocaleString()} empty filled`, tone: 'good' });
  if (de > 0) chips.push({ key: 'err', text: `+${de} error${de === 1 ? '' : 's'}`, tone: 'bad' });
  if (de < 0) chips.push({ key: 'err', text: `${Math.abs(de)} error${de === -1 ? '' : 's'} fixed`, tone: 'good' });
  return chips;
}
