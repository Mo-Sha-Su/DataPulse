import type { LucideIcon } from 'lucide-react';
import {
  Scissors, Eraser, CaseUpper, CaseLower, CaseSensitive, Replace, CircleSlash, AlertCircle, ArrowDownToLine,
  ArrowUpToLine, CopyMinus, Rows3, ArrowUpAZ, ArrowDownZA, Trash2, Copy, Columns2, Combine, Pencil, MoveLeft,
  MoveRight, FunctionSquare, Calculator, CalendarDays, Hash, Sigma, Upload, Sparkles, TextCursorInput, ListX, Percent,
} from 'lucide-react';
import { ColumnDataType } from '../../types/dataCleaning';
import { RowOperationAction } from '../DataCleaning/ManageRowsModal';

export type LabGroup = 'clean' | 'shape' | 'columns' | 'compute';

export const GROUPS: { id: LabGroup; label: string; blurb: string; color: string }[] = [
  { id: 'clean', label: 'Clean', blurb: 'Fix messy values', color: 'var(--color-cat-clean)' },
  { id: 'shape', label: 'Rows', blurb: 'Keep, drop and order rows', color: 'var(--color-cat-shape)' },
  { id: 'columns', label: 'Columns', blurb: 'Split, merge, rename, move', color: 'var(--color-cat-columns)' },
  { id: 'compute', label: 'Compute', blurb: 'Math, dates and new fields', color: 'var(--color-cat-compute)' },
];

export type TypeFamily = 'text' | 'number' | 'date' | 'other';
export const typeFamily = (t?: ColumnDataType): TypeFamily => {
  if (!t) return 'other';
  if (t === 'Text') return 'text';
  if (['Whole Number', 'Decimal Number', 'Currency', 'Percentage'].includes(t)) return 'number';
  if (['Date', 'Date/Time', 'Time'].includes(t)) return 'date';
  return 'other';
};

export interface LabHandlers {
  newSource: () => void;
  loadSample: () => void;
  removeColumn: () => void;
  duplicateColumn: () => void;
  renameColumn: () => void;
  moveColumn: (dir: 'left' | 'right') => void;
  openSplit: () => void;
  openMerge: () => void;
  openReplaceValues: () => void;
  openReplaceErrors: () => void;
  openReplaceNulls: () => void;
  openRemoveDuplicates: () => void;
  openManageRows: (a: RowOperationAction) => void;
  sort: (dir: 'asc' | 'desc') => void;
  fillDown: () => void;
  fillUp: () => void;
  text: (action: string) => void;
  number: (action: string) => void;
  date: (action: string) => void;
  addCustomColumn: () => void;
}

export interface LabAction {
  id: string;
  label: string;
  hint: string;
  group: LabGroup;
  icon: LucideIcon;
  keywords: string;
  /** needs a column to be selected in the grid */
  needsColumn?: boolean;
  /** only meaningful for this kind of column */
  family?: TypeFamily;
  danger?: boolean;
  run: () => void;
}

export function buildLabActions(h: LabHandlers): LabAction[] {
  const A = (a: Omit<LabAction, 'run'> & { run: () => void }): LabAction => a;
  return [
    // ---- Clean
    A({ id: 'trim', label: 'Trim spaces', hint: 'Remove leading and trailing whitespace', group: 'clean', icon: Scissors, keywords: 'whitespace strip', needsColumn: true, run: () => h.text('trim') }),
    A({ id: 'clean', label: 'Strip hidden characters', hint: 'Remove non-printable characters', group: 'clean', icon: Eraser, keywords: 'clean control invisible', needsColumn: true, run: () => h.text('clean') }),
    A({ id: 'upper', label: 'UPPERCASE', hint: 'Convert text to upper case', group: 'clean', icon: CaseUpper, keywords: 'case capital', needsColumn: true, run: () => h.text('uppercase') }),
    A({ id: 'lower', label: 'lowercase', hint: 'Convert text to lower case', group: 'clean', icon: CaseLower, keywords: 'case small', needsColumn: true, run: () => h.text('lowercase') }),
    A({ id: 'title', label: 'Title Case', hint: 'Capitalise each word', group: 'clean', icon: CaseSensitive, keywords: 'case capitalize proper', needsColumn: true, run: () => h.text('capitalize') }),
    A({ id: 'replace', label: 'Replace values…', hint: 'Swap one value for another', group: 'clean', icon: Replace, keywords: 'find substitute', needsColumn: true, run: h.openReplaceValues }),
    A({ id: 'nulls', label: 'Fill empty cells…', hint: 'Replace nulls with a value, 0, mean or median', group: 'clean', icon: CircleSlash, keywords: 'null blank missing impute', needsColumn: true, run: h.openReplaceNulls }),
    A({ id: 'errors', label: 'Replace errors…', hint: 'Handle cells that failed to convert', group: 'clean', icon: AlertCircle, keywords: 'error invalid', needsColumn: true, run: h.openReplaceErrors }),
    A({ id: 'filldown', label: 'Fill down', hint: 'Copy the value above into empty cells', group: 'clean', icon: ArrowDownToLine, keywords: 'propagate', needsColumn: true, run: h.fillDown }),
    A({ id: 'fillup', label: 'Fill up', hint: 'Copy the value below into empty cells', group: 'clean', icon: ArrowUpToLine, keywords: 'propagate', needsColumn: true, run: h.fillUp }),
    A({ id: 'dupes', label: 'Remove duplicates…', hint: 'Keep one row per unique key', group: 'clean', icon: CopyMinus, keywords: 'distinct unique dedupe', run: h.openRemoveDuplicates }),
    A({ id: 'blank', label: 'Remove blank rows', hint: 'Drop rows with no data at all', group: 'clean', icon: ListX, keywords: 'empty', run: () => h.openManageRows('remove_blank') }),
    // ---- Rows
    A({ id: 'keeptop', label: 'Keep top rows…', hint: 'Keep only the first N rows', group: 'shape', icon: Rows3, keywords: 'head limit first', run: () => h.openManageRows('keep_top') }),
    A({ id: 'keepbottom', label: 'Keep bottom rows…', hint: 'Keep only the last N rows', group: 'shape', icon: Rows3, keywords: 'tail last', run: () => h.openManageRows('keep_bottom') }),
    A({ id: 'keeprange', label: 'Keep a range of rows…', hint: 'Keep rows between two positions', group: 'shape', icon: Rows3, keywords: 'between slice', run: () => h.openManageRows('keep_range') }),
    A({ id: 'removetop', label: 'Remove top rows…', hint: 'Skip header junk at the top', group: 'shape', icon: ListX, keywords: 'skip header', run: () => h.openManageRows('remove_top') }),
    A({ id: 'removebottom', label: 'Remove bottom rows…', hint: 'Drop footer rows', group: 'shape', icon: ListX, keywords: 'footer totals', run: () => h.openManageRows('remove_bottom') }),
    A({ id: 'removealt', label: 'Remove alternate rows…', hint: 'Drop every other row', group: 'shape', icon: ListX, keywords: 'every other', run: () => h.openManageRows('remove_alternate') }),
    A({ id: 'sortasc', label: 'Sort ascending', hint: 'A→Z, 0→9, oldest first', group: 'shape', icon: ArrowUpAZ, keywords: 'order', needsColumn: true, run: () => h.sort('asc') }),
    A({ id: 'sortdesc', label: 'Sort descending', hint: 'Z→A, 9→0, newest first', group: 'shape', icon: ArrowDownZA, keywords: 'order', needsColumn: true, run: () => h.sort('desc') }),
    // ---- Columns
    A({ id: 'rename', label: 'Rename column…', hint: 'Give the column a clearer name', group: 'columns', icon: Pencil, keywords: 'name title', needsColumn: true, run: h.renameColumn }),
    A({ id: 'split', label: 'Split column…', hint: 'Break one column into several', group: 'columns', icon: Columns2, keywords: 'delimiter separate', needsColumn: true, run: h.openSplit }),
    A({ id: 'merge', label: 'Merge columns…', hint: 'Join columns into one', group: 'columns', icon: Combine, keywords: 'combine concatenate', run: h.openMerge }),
    A({ id: 'duplicate', label: 'Duplicate column', hint: 'Make a copy to experiment on', group: 'columns', icon: Copy, keywords: 'copy clone', needsColumn: true, run: h.duplicateColumn }),
    A({ id: 'left', label: 'Move left', hint: 'Shift the column one place left', group: 'columns', icon: MoveLeft, keywords: 'reorder', needsColumn: true, run: () => h.moveColumn('left') }),
    A({ id: 'right', label: 'Move right', hint: 'Shift the column one place right', group: 'columns', icon: MoveRight, keywords: 'reorder', needsColumn: true, run: () => h.moveColumn('right') }),
    A({ id: 'removecol', label: 'Remove column', hint: 'Delete the column from the result', group: 'columns', icon: Trash2, keywords: 'drop delete', needsColumn: true, danger: true, run: h.removeColumn }),
    // ---- Compute
    A({ id: 'custom', label: 'Custom column…', hint: 'Build a new field from a formula', group: 'compute', icon: FunctionSquare, keywords: 'formula calculate add', run: h.addCustomColumn }),
    A({ id: 'prefix', label: 'Add prefix…', hint: 'Put text in front of every value', group: 'compute', icon: TextCursorInput, keywords: 'text before', needsColumn: true, family: 'text', run: () => h.text('prefix') }),
    A({ id: 'suffix', label: 'Add suffix…', hint: 'Put text after every value', group: 'compute', icon: TextCursorInput, keywords: 'text after', needsColumn: true, family: 'text', run: () => h.text('suffix') }),
    A({ id: 'math', label: 'Standard math…', hint: 'Add, subtract, multiply or divide', group: 'compute', icon: Calculator, keywords: 'arithmetic plus times', needsColumn: true, family: 'number', run: () => h.number('math') }),
    A({ id: 'round', label: 'Round…', hint: 'Round to N decimals', group: 'compute', icon: Hash, keywords: 'decimals precision', needsColumn: true, family: 'number', run: () => h.number('round') }),
    A({ id: 'roundup', label: 'Round up', hint: 'Ceiling', group: 'compute', icon: Sigma, keywords: 'ceil', needsColumn: true, family: 'number', run: () => h.number('round_up') }),
    A({ id: 'rounddown', label: 'Round down', hint: 'Floor', group: 'compute', icon: Sigma, keywords: 'floor', needsColumn: true, family: 'number', run: () => h.number('round_down') }),
    A({ id: 'abs', label: 'Absolute value', hint: 'Drop the minus sign', group: 'compute', icon: Percent, keywords: 'positive', needsColumn: true, family: 'number', run: () => h.number('abs') }),
    ...(['year', 'quarter', 'month', 'month_name', 'day', 'day_name'] as const).map((p) =>
      A({
        id: `date_${p}`,
        label: `Extract ${p.replace('_', ' ')}`,
        hint: `Pull the ${p.replace('_', ' ')} out of the date`,
        group: 'compute',
        icon: CalendarDays,
        keywords: 'date time part',
        needsColumn: true,
        family: 'date',
        run: () => h.date(p),
      })
    ),
  ];
}

/** Why an action can't run right now (null = enabled). */
export function disabledReason(a: LabAction, selectedColumn: string | null, selectedType?: ColumnDataType): string | null {
  if (a.needsColumn && !selectedColumn) return 'Select a column first';
  if (a.family && a.family !== typeFamily(selectedType)) {
    return a.family === 'number' ? 'Needs a number column' : a.family === 'date' ? 'Needs a date column' : 'Needs a text column';
  }
  return null;
}

/** Palette search: every word must match label/keywords/hint; label-prefix matches rank first. */
export function searchActions(actions: LabAction[], query: string): LabAction[] {
  const q = query.trim().toLowerCase();
  if (!q) return actions;
  const words = q.split(/\s+/);
  const scored: { a: LabAction; s: number }[] = [];
  for (const a of actions) {
    const label = a.label.toLowerCase();
    const hay = `${label} ${a.keywords} ${a.hint.toLowerCase()} ${a.group}`;
    if (!words.every((w) => hay.includes(w))) continue;
    let s = 0;
    if (label.startsWith(q)) s += 4;
    else if (label.includes(q)) s += 2;
    if (words.every((w) => label.includes(w))) s += 1;
    scored.push({ a, s });
  }
  return scored.sort((x, y) => y.s - x.s).map((x) => x.a);
}

export const lucideForTopLevel = { Upload, Sparkles };
