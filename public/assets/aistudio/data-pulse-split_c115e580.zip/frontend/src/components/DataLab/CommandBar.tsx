import React, { useEffect, useRef, useState } from 'react';
import { ChevronDown, Search, MousePointerClick } from 'lucide-react';
import { ColumnDataType } from '../../types/dataCleaning';
import { GROUPS, LabAction, LabGroup, disabledReason } from './labActions';

interface Props {
  actions: LabAction[];
  selectedColumn: string | null;
  selectedType?: ColumnDataType;
  onOpenPalette: () => void;
}

export const CommandBar: React.FC<Props> = ({ actions, selectedColumn, selectedType, onOpenPalette }) => {
  const [open, setOpen] = useState<LabGroup | null>(null);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const down = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(null); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(null); };
    document.addEventListener('mousedown', down);
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('mousedown', down); document.removeEventListener('keydown', key); };
  }, [open]);

  return (
    <div ref={ref} className="h-12 shrink-0 px-4 flex items-center gap-2 bg-lab-panel border-b border-lab-line relative z-30">
      {GROUPS.map((g) => {
        const items = actions.filter((a) => a.group === g.id);
        const usable = items.filter((a) => !disabledReason(a, selectedColumn, selectedType)).length;
        const isOpen = open === g.id;
        return (
          <div key={g.id} className="relative">
            <button
              type="button"
              aria-haspopup="menu"
              aria-expanded={isOpen}
              onClick={() => setOpen(isOpen ? null : g.id)}
              className={`h-8 pl-2.5 pr-2 rounded-lg flex items-center gap-2 text-[13px] font-semibold border transition-colors ${
                isOpen ? 'bg-lab-hover border-lab-line-strong text-lab-text' : 'border-transparent text-lab-dim hover:text-lab-text hover:bg-lab-raised'
              }`}
            >
              <span className="w-2 h-2 rounded-full" style={{ background: g.color, boxShadow: `0 0 10px ${g.color}` }} />
              {g.label}
              <span className="font-mono text-[10px] text-lab-faint">{usable}</span>
              <ChevronDown className={`w-3.5 h-3.5 text-lab-faint transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>

            {isOpen && (
              <div role="menu" className="lab-pop absolute left-0 top-10 w-[460px] rounded-2xl border border-lab-line-strong bg-lab-panel shadow-2xl shadow-black/50 p-2">
                <div className="px-2.5 pt-1.5 pb-2">
                  <p className="text-[11px] font-bold uppercase tracking-wider" style={{ color: g.color }}>{g.label}</p>
                  <p className="text-[11px] text-lab-dim">{g.blurb}</p>
                </div>
                <div className="grid grid-cols-2 gap-1 max-h-[360px] overflow-y-auto lab-scroll pr-1">
                  {items.map((a) => {
                    const why = disabledReason(a, selectedColumn, selectedType);
                    const Icon = a.icon;
                    return (
                      <button
                        key={a.id}
                        type="button"
                        role="menuitem"
                        disabled={!!why}
                        title={why || a.hint}
                        onClick={() => { setOpen(null); a.run(); }}
                        className={`text-left rounded-xl px-2.5 py-2 flex items-start gap-2.5 transition-colors ${
                          why ? 'opacity-35 cursor-not-allowed' : a.danger ? 'hover:bg-rose-400/10' : 'hover:bg-lab-hover'
                        }`}
                      >
                        <span className="mt-0.5 w-6 h-6 rounded-md grid place-items-center shrink-0" style={{ background: `color-mix(in srgb, ${g.color} 14%, transparent)`, color: g.color }}>
                          <Icon className="w-3.5 h-3.5" />
                        </span>
                        <span className="min-w-0">
                          <span className={`block text-[12.5px] font-semibold leading-tight ${a.danger ? 'text-rose-300' : 'text-lab-text'}`}>{a.label}</span>
                          <span className="block text-[11px] text-lab-dim leading-snug mt-0.5">{why || a.hint}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        );
      })}

      <span className="flex-1" />

      <div
        className={`hidden md:flex items-center gap-1.5 h-8 px-2.5 rounded-lg border text-[12px] ${
          selectedColumn ? 'border-pulse-400/40 bg-pulse-400/10 text-pulse-200' : 'border-lab-line text-lab-faint'
        }`}
      >
        <MousePointerClick className="w-3.5 h-3.5" />
        {selectedColumn ? (
          <span>
            Acting on <b className="font-semibold text-lab-text">{selectedColumn}</b>
            {selectedType && <span className="ml-1.5 font-mono text-[10px] text-lab-dim">{selectedType}</span>}
          </span>
        ) : (
          <span>Click a column header to target it</span>
        )}
      </div>

      <button
        type="button"
        onClick={onOpenPalette}
        className="h-8 pl-2.5 pr-1.5 rounded-lg flex items-center gap-2 text-[12px] text-lab-dim border border-lab-line-strong bg-lab-bg hover:text-lab-text hover:border-pulse-400/50 transition-colors"
        aria-label="Search all actions"
      >
        <Search className="w-3.5 h-3.5" />
        <span>Find an action…</span>
        <kbd className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-lab-raised border border-lab-line-strong text-lab-dim">Ctrl K</kbd>
      </button>
    </div>
  );
};
