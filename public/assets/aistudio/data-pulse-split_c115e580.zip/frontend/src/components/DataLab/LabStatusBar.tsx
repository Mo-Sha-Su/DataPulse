import React, { useState } from 'react';
import { AlertTriangle, Check, Code2, Copy, PanelRightClose, PanelRightOpen } from 'lucide-react';

interface Props {
  rows: number;
  columns: number;
  errors: number;
  stepIndex: number;
  stepCount: number;
  stepName: string;
  formula: string;
  score: number;
  inspectorOpen?: boolean;
  onToggleInspector?: () => void;
}

export const LabStatusBar: React.FC<Props> = ({ rows, columns, errors, stepIndex, stepCount, stepName, formula, score, inspectorOpen, onToggleInspector }) => {
  const [showCode, setShowCode] = useState(false);
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(formula);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard unavailable: ignore */
    }
  };
  return (
    <div className="shrink-0 bg-lab-panel border-t border-lab-line">
      {showCode && (
        <div className="lab-pop px-4 py-3 border-b border-lab-line bg-lab-bg flex items-start gap-3">
          <Code2 className="w-4 h-4 text-pulse-400 mt-0.5 shrink-0" />
          <pre className="flex-1 min-w-0 font-mono text-[12px] leading-relaxed text-pulse-200 whitespace-pre-wrap break-all">{formula}</pre>
          <button type="button" onClick={copy} className="shrink-0 h-7 px-2.5 rounded-md flex items-center gap-1.5 text-[11px] font-semibold text-lab-dim hover:text-lab-text bg-lab-raised hover:bg-lab-hover">
            {copied ? <Check className="w-3 h-3 text-emerald-300" /> : <Copy className="w-3 h-3" />} {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
      )}
      <div className="h-8 px-4 flex items-center gap-4 text-[11px] text-lab-dim">
        <span className="font-mono"><b className="text-lab-text">{rows.toLocaleString()}</b> rows</span>
        <span className="font-mono"><b className="text-lab-text">{columns}</b> cols</span>
        {errors > 0 && (
          <span className="flex items-center gap-1 text-rose-300 font-semibold"><AlertTriangle className="w-3 h-3" /> {errors} error{errors === 1 ? '' : 's'}</span>
        )}
        <span className="flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${score >= 95 ? 'bg-emerald-400' : score >= 80 ? 'bg-amber-400' : 'bg-rose-400'}`} />
          health <b className="font-mono text-lab-text">{score}%</b>
        </span>
        <span className="flex-1" />
        <span className="truncate">
          step <b className="font-mono text-lab-text">{stepIndex + 1}/{stepCount}</b> · <span className="text-lab-text">{stepName}</span>
        </span>
        <button
          type="button"
          onClick={() => setShowCode((v) => !v)}
          aria-pressed={showCode}
          className={`h-6 px-2 rounded-md flex items-center gap-1.5 font-semibold transition-colors ${showCode ? 'bg-pulse-400/15 text-pulse-200' : 'hover:bg-lab-raised hover:text-lab-text'}`}
        >
          <Code2 className="w-3 h-3" /> M code
        </button>
        {onToggleInspector && (
          <button
            type="button"
            onClick={onToggleInspector}
            aria-pressed={!!inspectorOpen}
            title={inspectorOpen ? 'Hide inspector' : 'Show inspector: profile and smart fixes'}
            className={`h-6 px-2 rounded-md flex items-center gap-1.5 font-semibold transition-colors ${inspectorOpen ? 'bg-pulse-400/15 text-pulse-200' : 'hover:bg-lab-raised hover:text-lab-text'}`}
          >
            {inspectorOpen ? <PanelRightClose className="w-3 h-3" /> : <PanelRightOpen className="w-3 h-3" />} Inspector
          </button>
        )}
      </div>
    </div>
  );
};
