import React, { useState } from 'react';
import { DashboardState, ReportPageSizePreset, PageOrientation, PageUnit } from '../../types/dashboard';
import { REPORT_PAGE_PRESETS, sanitizeFilename, getJsPdfPageConfig, DEFAULT_PAGE_MARGINS } from '../../utils/reportPageDimensions';
import { exportReportToPdf } from '../../utils/exportToPdf';
import { FileText, Download, X, Printer, Layers, Sliders, Check, Loader2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  dashboard: DashboardState;
  activePageId?: string;
  onClose: () => void;
  onUpdateCanvasSettings: (newSettings: Partial<DashboardState['canvas']>) => void;
}

export const ExportPdfModal: React.FC<Props> = ({
  isOpen,
  dashboard,
  activePageId,
  onClose,
  onUpdateCanvasSettings,
}) => {
  if (!isOpen) return null;

  const initialFilename = dashboard.name ? `${dashboard.name}` : 'Business Report';
  const [filename, setFilename] = useState(initialFilename);
  const [pageSizePreset, setPageSizePreset] = useState<ReportPageSizePreset>(
    dashboard.canvas.pageSizePreset || 'A4 Portrait'
  );
  const [orientation, setOrientation] = useState<PageOrientation>(
    dashboard.canvas.orientation || 'portrait'
  );
  const [pageRange, setPageRange] = useState<'all' | 'current' | 'custom'>('all');
  const [customRangeInput, setCustomRangeInput] = useState('1');
  const [marginTop, setMarginTop] = useState(dashboard.canvas.margins?.top ?? DEFAULT_PAGE_MARGINS.top);
  const [marginRight, setMarginRight] = useState(dashboard.canvas.margins?.right ?? DEFAULT_PAGE_MARGINS.right);
  const [marginBottom, setMarginBottom] = useState(dashboard.canvas.margins?.bottom ?? DEFAULT_PAGE_MARGINS.bottom);
  const [marginLeft, setMarginLeft] = useState(dashboard.canvas.margins?.left ?? DEFAULT_PAGE_MARGINS.left);
  const [marginUnit, setMarginUnit] = useState<PageUnit>(dashboard.canvas.margins?.unit || 'mm');
  const [qualityScale, setQualityScale] = useState<number>(2);

  const [isExporting, setIsExporting] = useState(false);
  const [progressPercent, setProgressPercent] = useState(0);
  const [progressStatus, setProgressStatus] = useState('');

  const pages = dashboard.pages && dashboard.pages.length > 0 ? dashboard.pages : [{ id: 'p_1', name: 'Page 1' }];

  const handlePageSizeChange = (presetKey: ReportPageSizePreset) => {
    setPageSizePreset(presetKey);
    const preset = REPORT_PAGE_PRESETS[presetKey];
    if (preset) {
      setOrientation(preset.orientation);
      onUpdateCanvasSettings({
        pageSizePreset: presetKey,
        orientation: preset.orientation,
        widthPhysical: preset.widthPhysical,
        heightPhysical: preset.heightPhysical,
        unit: preset.unit,
      });
    }
  };

  const handleOrientationToggle = (newOrientation: PageOrientation) => {
    setOrientation(newOrientation);
    // Auto switch to matching preset if available
    let nextPreset = pageSizePreset;
    if (pageSizePreset.startsWith('A4')) {
      nextPreset = newOrientation === 'landscape' ? 'A4 Landscape' : 'A4 Portrait';
    } else if (pageSizePreset.startsWith('A3')) {
      nextPreset = newOrientation === 'landscape' ? 'A3 Landscape' : 'A3 Portrait';
    } else if (pageSizePreset.startsWith('Letter')) {
      nextPreset = newOrientation === 'landscape' ? 'Letter Landscape' : 'Letter Portrait';
    } else if (pageSizePreset.startsWith('Legal')) {
      nextPreset = newOrientation === 'landscape' ? 'Legal Landscape' : 'Legal Portrait';
    }

    setPageSizePreset(nextPreset);
    const preset = REPORT_PAGE_PRESETS[nextPreset];
    if (preset) {
      onUpdateCanvasSettings({
        pageSizePreset: nextPreset,
        orientation: newOrientation,
        widthPhysical: preset.widthPhysical,
        heightPhysical: preset.heightPhysical,
        unit: preset.unit,
      });
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    setProgressPercent(10);
    setProgressStatus('Preparing PDF layout...');

    // Parse custom page numbers
    let customPagesList: number[] = [1];
    if (pageRange === 'custom') {
      customPagesList = customRangeInput
        .split(',')
        .map((s) => parseInt(s.trim(), 10))
        .filter((n) => !isNaN(n) && n >= 1 && n <= pages.length);
    }

    // Apply latest margins to canvas settings
    onUpdateCanvasSettings({
      margins: {
        top: marginTop,
        right: marginRight,
        bottom: marginBottom,
        left: marginLeft,
        unit: marginUnit,
      },
    });

    try {
      await exportReportToPdf(
        dashboard,
        {
          filename: sanitizeFilename(filename),
          pageRange,
          customPages: customPagesList,
          scaleFactor: qualityScale,
        },
        activePageId,
        (progress, message) => {
          setProgressPercent(progress);
          setProgressStatus(message);
        }
      );
      setTimeout(() => {
        setIsExporting(false);
        onClose();
      }, 500);
    } catch (err) {
      console.error('PDF Export Error:', err);
      setIsExporting(false);
      alert('An error occurred during PDF generation. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Export Print Ready PDF</h3>
              <p className="text-xs text-slate-400">Configure page size, orientation, margins & document quality</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isExporting}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-5 text-slate-800 max-h-[75vh] overflow-y-auto">
          {/* Filename Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">PDF Document Filename</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={filename}
                onChange={(e) => setFilename(e.target.value)}
                placeholder="e.g. Annual_Financial_Report"
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm font-semibold text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
              />
              <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2.5 py-2 rounded-lg border border-slate-200">
                .pdf
              </span>
            </div>
          </div>

          {/* Page Size & Preset Selector */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">Paper Page Size</label>
              <select
                value={pageSizePreset}
                onChange={(e) => handlePageSizeChange(e.target.value as ReportPageSizePreset)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-600"
              >
                {Object.keys(REPORT_PAGE_PRESETS).map((key) => (
                  <option key={key} value={key}>
                    {key}
                  </option>
                ))}
                <option value="Custom Size">Custom Physical Size</option>
              </select>
            </div>

            {/* Orientation */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">Orientation</label>
              <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 rounded-lg border border-slate-200">
                <button
                  type="button"
                  onClick={() => handleOrientationToggle('portrait')}
                  className={`py-1.5 px-2 rounded text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                    orientation === 'portrait'
                      ? 'bg-white text-indigo-700 shadow-xs border border-indigo-200 font-extrabold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>Portrait</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleOrientationToggle('landscape')}
                  className={`py-1.5 px-2 rounded text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                    orientation === 'landscape'
                      ? 'bg-white text-indigo-700 shadow-xs border border-indigo-200 font-extrabold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>Landscape</span>
                </button>
              </div>
            </div>
          </div>

          {/* Page Margins Configuration */}
          <div className="space-y-2 border border-slate-200 rounded-xl p-3.5 bg-slate-50/70">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                <span>Page Margins</span>
              </span>
              <select
                value={marginUnit}
                onChange={(e) => setMarginUnit(e.target.value as PageUnit)}
                className="bg-white border border-slate-300 rounded px-2 py-0.5 text-xs font-bold text-slate-700 focus:outline-none"
              >
                <option value="mm">mm</option>
                <option value="cm">cm</option>
                <option value="in">in</option>
                <option value="px">px</option>
              </select>
            </div>

            <div className="grid grid-cols-4 gap-2 text-xs">
              <div>
                <span className="text-[11px] font-medium text-slate-500 block mb-1">Top</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={marginTop}
                  onChange={(e) => setMarginTop(Number(e.target.value))}
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-500 block mb-1">Right</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={marginRight}
                  onChange={(e) => setMarginRight(Number(e.target.value))}
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-500 block mb-1">Bottom</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={marginBottom}
                  onChange={(e) => setMarginBottom(Number(e.target.value))}
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900 focus:outline-none"
                />
              </div>
              <div>
                <span className="text-[11px] font-medium text-slate-500 block mb-1">Left</span>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={marginLeft}
                  onChange={(e) => setMarginLeft(Number(e.target.value))}
                  className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-xs font-bold text-slate-900 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Page Range Selection */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-indigo-600" />
              <span>Page Export Range</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPageRange('all')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold text-left transition-all ${
                  pageRange === 'all'
                    ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>All Pages</div>
                <div className="text-[10px] text-slate-500 font-normal">
                  {pages.length} {pages.length === 1 ? 'Page' : 'Pages'}
                </div>
              </button>

              <button
                type="button"
                onClick={() => setPageRange('current')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold text-left transition-all ${
                  pageRange === 'current'
                    ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>Current Page Only</div>
                <div className="text-[10px] text-slate-500 font-normal truncate">Active View</div>
              </button>

              <button
                type="button"
                onClick={() => setPageRange('custom')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold text-left transition-all ${
                  pageRange === 'custom'
                    ? 'bg-indigo-50 border-indigo-500 text-indigo-700 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div>Custom Selection</div>
                <div className="text-[10px] text-slate-500 font-normal">Select e.g. 1, 2</div>
              </button>
            </div>

            {pageRange === 'custom' && (
              <div className="pt-1">
                <input
                  type="text"
                  value={customRangeInput}
                  onChange={(e) => setCustomRangeInput(e.target.value)}
                  placeholder="e.g. 1, 2"
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>
            )}
          </div>

          {/* Quality Scale Factor */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="font-bold text-slate-800 block">Render Resolution</span>
              <span className="text-[11px] text-slate-500">Sharper text & vectorized canvas charts</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setQualityScale(2)}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                  qualityScale === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                2x High
              </button>
              <button
                type="button"
                onClick={() => setQualityScale(3)}
                className={`px-2.5 py-1 rounded text-xs font-bold transition-all ${
                  qualityScale === 3 ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                3x Ultra HD
              </button>
            </div>
          </div>

          {/* Progress Bar indicator during generation */}
          {isExporting && (
            <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-900">
                <span className="flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                  <span>{progressStatus || 'Generating Vector PDF...'}</span>
                </span>
                <span>{progressPercent}%</span>
              </div>
              <div className="w-full bg-indigo-200 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-indigo-600 h-full transition-all duration-300 ease-out"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            disabled={isExporting}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-md shadow-indigo-600/20 transition-all cursor-pointer"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Exporting PDF...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Generate PDF</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
