import React, { useState } from 'react';
import { DashboardState } from '../../types/dashboard';
import {
  X,
  FolderOpen,
  Download,
  Upload,
  Plus,
  Trash2,
  Check,
  Layout,
  Copy,
} from 'lucide-react';

interface Props {
  currentDashboard: DashboardState;
  savedDashboards: DashboardState[];
  onLoadDashboard: (dashboard: DashboardState) => void;
  onDeleteDashboard: (dashboardId: string) => void;
  onImportDashboardJson: (importedState: DashboardState) => void;
  onClose: () => void;
}

export const ManageDashboardsModal: React.FC<Props> = ({
  currentDashboard,
  savedDashboards,
  onLoadDashboard,
  onDeleteDashboard,
  onImportDashboardJson,
  onClose,
}) => {
  const [importText, setImportText] = useState('');
  const [showImportArea, setShowImportArea] = useState(false);

  // Use user-saved dashboards only
  const allDashboards = savedDashboards;

  const handleExportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(currentDashboard, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `${currentDashboard.name.toLowerCase().replace(/\s+/g, '_')}_dashboard.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportSubmit = () => {
    try {
      const parsed = JSON.parse(importText) as DashboardState;
      if (parsed && parsed.widgets && parsed.canvas) {
        onImportDashboardJson(parsed);
        setShowImportArea(false);
      } else {
        alert('Invalid dashboard JSON schema.');
      }
    } catch (err) {
      alert('Error parsing JSON string. Please verify formatting.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-6 text-slate-800 select-none">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl flex flex-col overflow-hidden max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <FolderOpen className="w-5 h-5 text-sky-600" />
            <h2 className="font-bold text-base text-slate-900">Dashboard Manager & Templates</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-200/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {/* Action Bar */}
          <div className="flex gap-2">
            <button
              onClick={handleExportJson}
              className="flex-1 py-2 px-3 bg-slate-50 hover:bg-slate-100 rounded-xl font-bold text-xs text-slate-700 flex items-center justify-center gap-2 border border-slate-200 transition-colors"
            >
              <Download className="w-4 h-4 text-emerald-600" />
              <span>Export Dashboard JSON</span>
            </button>
            <button
              onClick={() => setShowImportArea(!showImportArea)}
              className="flex-1 py-2 px-3 bg-slate-50 hover:bg-slate-100 rounded-xl font-bold text-xs text-slate-700 flex items-center justify-center gap-2 border border-slate-200 transition-colors"
            >
              <Upload className="w-4 h-4 text-indigo-600" />
              <span>Import JSON</span>
            </button>
          </div>

          {/* Import JSON Area */}
          {showImportArea && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
              <span className="text-xs font-bold text-slate-700 block">Paste Dashboard JSON</span>
              <textarea
                value={importText}
                onChange={(e) => setImportText(e.target.value)}
                placeholder="Paste valid JSON state object here..."
                rows={4}
                className="w-full p-2 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-800 focus:outline-none"
              />
              <button
                onClick={handleImportSubmit}
                className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 rounded-lg font-bold text-xs text-white transition-colors"
              >
                Apply Imported Dashboard
              </button>
            </div>
          )}

          {/* Dashboards List */}
          <div className="space-y-2 pt-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
              Available & Preset Dashboards ({allDashboards.length})
            </span>
            {allDashboards.map((dash) => {
              const isActive = dash.id === currentDashboard.id;
              return (
                <div
                  key={dash.id}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                    isActive
                      ? 'border-sky-500 bg-sky-50/60 ring-1 ring-sky-500'
                      : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">{dash.name}</span>
                      {isActive && (
                        <span className="px-2 py-0.5 rounded bg-sky-600 text-white text-[10px] font-bold uppercase">
                          Active Workspace
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 font-medium">{dash.description}</p>
                    <span className="text-[10px] text-slate-400 font-semibold block">
                      {dash.widgets.length} widgets • {dash.canvas.presetName}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {!isActive && (
                      <button
                        onClick={() => {
                          onLoadDashboard(dash);
                          onClose();
                        }}
                        className="py-1.5 px-3 bg-[#0284C7] hover:bg-sky-700 text-white font-bold text-xs rounded-lg transition-colors"
                      >
                        Load
                      </button>
                    )}
                    {savedDashboards.some((s) => s.id === dash.id) && (
                      <button
                        onClick={() => onDeleteDashboard(dash.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-slate-200/60"
                        title="Delete Dashboard"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
