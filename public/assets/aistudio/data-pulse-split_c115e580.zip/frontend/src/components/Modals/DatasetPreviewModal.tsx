import React, { useState } from 'react';
import { Dataset } from '../../types/dashboard';
import { X, Search, Table, FileSpreadsheet, Hash, Type, Calendar, Sparkles } from 'lucide-react';

interface Props {
  dataset: Dataset | null;
  onClose: () => void;
  onOpenDataCleaning?: (datasetId: string) => void;
}

export const DatasetPreviewModal: React.FC<Props> = ({ dataset, onClose, onOpenDataCleaning }) => {
  if (!dataset) return null;

  const [search, setSearch] = useState('');

  const filteredRows = dataset.data.filter((row) =>
    Object.values(row).some((val) =>
      String(val).toLowerCase().includes(search.toLowerCase())
    )
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-6 text-slate-800 select-none">
      <div className="w-full max-w-4xl bg-white border border-slate-200 rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-100 text-sky-700 rounded-xl border border-sky-200">
              <Table className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900">{dataset.name}</h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5 font-medium">
                <span>{(Number(dataset?.rowCount ?? (dataset as any)?.row_count ?? (dataset?.data?.length || 0)) || 0).toLocaleString()} total rows</span>
                <span>•</span>
                <span>{Number(dataset?.columnCount ?? (dataset as any)?.column_count ?? (dataset?.columns?.length || 0)) || 0} columns</span>
                <span>•</span>
                <span className="text-sky-700 font-mono uppercase font-bold">{dataset.sourceType}</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-200/60"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 ml-2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search records across all columns..."
            className="w-full bg-transparent border-none text-xs text-slate-800 placeholder-slate-400 focus:outline-none font-medium"
          />
        </div>

        {/* Data Table */}
        <div className="flex-1 overflow-auto p-4">
          <table className="w-full text-left text-xs text-slate-700 border-collapse">
            <thead className="sticky top-0 bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
              <tr>
                <th className="p-2.5 w-12 text-center">#</th>
                {dataset.columns.map((col) => (
                  <th key={col.name} className="p-2.5 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span>{col.name}</span>
                      <span className="text-[9px] px-1 py-0.2 rounded bg-slate-200 text-slate-600 font-mono">
                        {col.type}
                      </span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
              {filteredRows.slice(0, 100).map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-50 transition-colors">
                  <td className="p-2.5 text-center text-slate-400 font-sans font-semibold">{idx + 1}</td>
                  {dataset.columns.map((col) => (
                    <td key={col.name} className="p-2.5 whitespace-nowrap max-w-[200px] truncate">
                      {String(row[col.name] ?? '')}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50 text-xs text-slate-500 font-medium flex justify-between items-center">
          <span>Showing {Math.min(100, filteredRows.length)} of {filteredRows.length} matching rows</span>
          <div className="flex items-center gap-2">
            {onOpenDataCleaning && (
              <button
                type="button"
                onClick={() => {
                  const id = dataset.id;
                  onClose();
                  onOpenDataCleaning(id);
                }}
                className="px-3 py-1.5 bg-sky-50 hover:bg-sky-100 border border-sky-300 text-sky-800 font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-sky-600" />
                <span>Explore the data</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-1.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg transition-colors cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
