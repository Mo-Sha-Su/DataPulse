import React, { useState } from 'react';
import { Dataset, DashboardState } from '../../types/dashboard';
import {
  X,
  Database,
  Check,
  Search,
  AlertTriangle,
  FileSpreadsheet,
  Layers,
  Sparkles,
  Tag,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  globalDatasets: Dataset[];
  selectedDatasetIds: string[];
  currentDashboard: DashboardState;
  onClose: () => void;
  onApplySelection: (selectedIds: string[]) => void;
}

export const SelectDatasetsModal: React.FC<Props> = ({
  isOpen,
  globalDatasets,
  selectedDatasetIds,
  currentDashboard,
  onClose,
  onApplySelection,
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>(() => {
    if (selectedDatasetIds && selectedDatasetIds.length > 0) {
      return selectedDatasetIds;
    }
    return globalDatasets.map((d) => d.id);
  });

  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');

  if (!isOpen) return null;

  // Extract all unique tags
  const allTags = Array.from(
    new Set(globalDatasets.flatMap((d) => d.tags || []))
  );

  const filteredDatasets = globalDatasets.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      (d.description && d.description.toLowerCase().includes(search.toLowerCase()));

    const matchesTag =
      selectedTag === 'all' || (d.tags && d.tags.includes(selectedTag));

    return matchesSearch && matchesTag;
  });

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  // Check if any deselected dataset is used by active widgets or model
  const deselectedIds = globalDatasets
    .map((d) => d.id)
    .filter((id) => !selectedIds.includes(id));

  const affectedWidgets = currentDashboard.widgets.filter((w) =>
    deselectedIds.includes(w.config.datasetId)
  );

  const handleApply = () => {
    onApplySelection(selectedIds);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Select Datasets for &quot;{currentDashboard.name}&quot;
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Choose which global datasets are available to widgets, charts, and star schema modeling
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {/* Search & Tag Filter Bar */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search global datasets by name or description..."
                className="w-full h-9 pl-9 pr-3 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-900 placeholder-slate-400 focus:outline-sky-500"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
              <button
                type="button"
                onClick={() => setSelectedTag('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  selectedTag === 'all'
                    ? 'bg-slate-800 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All ({globalDatasets.length})
              </button>
              {allTags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => setSelectedTag(tag)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    selectedTag === tag
                      ? 'bg-sky-600 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Selection Actions */}
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>
              <strong>{selectedIds.length}</strong> of {globalDatasets.length} datasets selected
            </span>
            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setSelectedIds(globalDatasets.map((d) => d.id))}
                className="text-sky-600 hover:underline font-bold cursor-pointer"
              >
                Select All
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => setSelectedIds([])}
                className="text-slate-500 hover:underline font-bold cursor-pointer"
              >
                Clear All
              </button>
            </div>
          </div>

          {/* Dataset Cards List */}
          <div className="space-y-2">
            {filteredDatasets.map((ds) => {
              const isSelected = selectedIds.includes(ds.id);

              return (
                <div
                  key={ds.id}
                  onClick={() => toggleSelect(ds.id)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                    isSelected
                      ? 'bg-sky-50/70 border-sky-300 shadow-2xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-5 h-5 rounded-md border mt-0.5 flex items-center justify-center transition-colors ${
                        isSelected
                          ? 'bg-sky-600 border-sky-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5" />}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 text-sm">{ds.name}</span>
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-slate-200 text-slate-700 uppercase">
                          {ds.sourceType}
                        </span>
                      </div>

                      {ds.description && (
                        <p className="text-slate-500 text-[11px] max-w-lg">{ds.description}</p>
                      )}

                      <div className="flex items-center gap-3 text-[11px] text-slate-400 font-medium">
                        <span>{(Number(ds?.rowCount ?? (ds as any)?.row_count ?? (ds?.data?.length || 0)) || 0).toLocaleString()} rows</span>
                        <span>•</span>
                        <span>{Number(ds?.columnCount ?? (ds as any)?.column_count ?? (ds?.columns?.length || 0)) || 0} columns</span>
                        {ds.tags && ds.tags.length > 0 && (
                          <>
                            <span>•</span>
                            <div className="flex gap-1">
                              {ds.tags.map((t) => (
                                <span
                                  key={t}
                                  className="text-[9px] px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-semibold"
                                >
                                  {t}
                                </span>
                              ))}
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Warning if deselected datasets affect widgets */}
          {affectedWidgets.length > 0 && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-amber-900">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="text-[11px]">
                <strong>Notice:</strong> {affectedWidgets.length} existing widget(s) in this dashboard depend on datasets you have unselected.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            disabled={selectedIds.length === 0}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-xs"
          >
            Apply Dataset Selection ({selectedIds.length})
          </button>
        </div>
      </div>
    </div>
  );
};
