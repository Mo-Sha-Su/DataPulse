import React, { useState } from 'react';
import { Dataset } from '../../types/dashboard';
import { DimensionTable } from '../../types/dataModel';
import { generateDateDimension } from '../../utils/dataModelingEngine';
import { X, Calendar, Check, Clock } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (result: { dataset: Dataset; dimension: DimensionTable }) => void;
}

export const GenerateDateDimensionModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onGenerate,
}) => {
  const [startYear, setStartYear] = useState<number>(2024);
  const [endYear, setEndYear] = useState<number>(2028);

  if (!isOpen) return null;

  const estimatedDays = (endYear - startYear + 1) * 365;

  const handleApply = () => {
    const res = generateDateDimension(startYear, endYear);
    onGenerate(res);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Generate Date Dimension (DIM_DATE)</h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Automatic calendar table with Day, Month, Quarter, Year, and Time Intelligence
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700">
          {/* Year Range Selectors */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">Start Year</label>
              <select
                value={startYear}
                onChange={(e) => setStartYear(Number(e.target.value))}
                className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-sky-500"
              >
                {[2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026].map((y) => (
                  <option key={y} value={y}>
                    {y} (Jan 01)
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">End Year</label>
              <select
                value={endYear}
                onChange={(e) => setEndYear(Number(e.target.value))}
                className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-sky-500"
              >
                {[2026, 2027, 2028, 2029, 2030, 2032, 2035].map((y) => (
                  <option key={y} value={y} disabled={y < startYear}>
                    {y} (Dec 31)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Generated Schema Preview */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <span className="text-[11px] font-bold text-slate-700 block">Generated Columns & Hierarchy</span>
            <div className="flex flex-wrap gap-1.5">
              {[
                'Date_ID (PK)',
                'Date (YYYY-MM-DD)',
                'Day (1-31)',
                'Day_Name',
                'Week (1-53)',
                'Month (1-12)',
                'Month_Name',
                'Quarter (Q1-Q4)',
                'Year',
              ].map((col, i) => (
                <span
                  key={i}
                  className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[10px] font-mono text-slate-700"
                >
                  {col}
                </span>
              ))}
            </div>

            <div className="mt-2 pt-2 border-t border-slate-200/80 text-[11px] text-slate-500 flex items-center justify-between font-medium">
              <span>Estimated rows: ~{estimatedDays} daily records</span>
              <span className="text-emerald-700 font-bold">100% Unique Keys</span>
            </div>
          </div>

          <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-start gap-2.5 text-indigo-900">
            <Clock className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
            <p className="text-[11px]">
              <strong>Standard Star Schema Practice:</strong> Fact tables connect to <code className="font-mono font-bold">DIM_DATE.Date_ID</code> via a 1 : * relationship to enable cross-year cohort comparison, monthly rollups, and drill-down charts.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Generate DIM_DATE Table</span>
          </button>
        </div>
      </div>
    </div>
  );
};
