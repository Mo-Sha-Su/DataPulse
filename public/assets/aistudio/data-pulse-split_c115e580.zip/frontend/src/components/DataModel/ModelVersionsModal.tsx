import React, { useState } from 'react';
import { DataModelState, ModelVersion } from '../../types/dataModel';
import { X, History, Save, RotateCcw, Check, Clock } from 'lucide-react';

interface Props {
  isOpen: boolean;
  currentModel: DataModelState;
  onClose: () => void;
  onSaveNewVersion: (versionName: string, description: string) => void;
  onRevertToVersion: (version: ModelVersion) => void;
}

export const ModelVersionsModal: React.FC<Props> = ({
  isOpen,
  currentModel,
  onClose,
  onSaveNewVersion,
  onRevertToVersion,
}) => {
  const [versionName, setVersionName] = useState(() => `Model v${(currentModel.versions?.length || 0) + 1}`);
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSave = () => {
    if (!versionName.trim()) return;
    onSaveNewVersion(versionName.trim(), description.trim());
    setVersionName(`Model v${(currentModel.versions?.length || 0) + 2}`);
    setDescription('');
  };

  const versions = currentModel.versions || [];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
              <History className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Star Schema Model Versioning</h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Save snapshots, inspect historical iterations, or revert your data model schema
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {/* Create Version Form */}
          <div className="p-3.5 bg-purple-50/50 border border-purple-200 rounded-xl space-y-3">
            <span className="font-bold text-slate-900 block">Snapshot Current Model</span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Version Name</label>
                <input
                  type="text"
                  value={versionName}
                  onChange={(e) => setVersionName(e.target.value)}
                  placeholder="e.g. Model v2 - Added Store & Returns"
                  className="w-full h-8 px-2.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-purple-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">Description / Notes</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Cleaned customer relationships"
                  className="w-full h-8 px-2.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:outline-purple-500"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={handleSave}
              disabled={!versionName.trim()}
              className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 disabled:bg-slate-300 text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs self-start"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Model Version Snapshot</span>
            </button>
          </div>

          {/* Version History List */}
          <div>
            <span className="text-[11px] font-bold text-slate-700 mb-2 block">
              Version History ({versions.length})
            </span>
            {versions.length === 0 ? (
              <div className="p-4 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-400">
                No previous snapshots saved yet. Save a version above to enable 1-click restore.
              </div>
            ) : (
              <div className="space-y-2">
                {versions.map((ver) => (
                  <div
                    key={ver.id}
                    className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between hover:border-purple-300 transition-colors shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">{ver.versionName}</span>
                        <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {ver.createdAt}
                        </span>
                      </div>
                      {ver.description && (
                        <p className="text-[11px] text-slate-500 mt-0.5">{ver.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-600 font-medium">
                        <span>{ver.snapshot.factTables?.length || 0} Facts</span>
                        <span>•</span>
                        <span>{ver.snapshot.dimensionTables?.length || 0} Dims</span>
                        <span>•</span>
                        <span>{ver.snapshot.relationships?.length || 0} Rels</span>
                        <span>•</span>
                        <span>{ver.snapshot.measures?.length || 0} Measures</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Restore data model to '${ver.versionName}'? Current unsaved adjustments will be replaced.`)) {
                          onRevertToVersion(ver);
                          onClose();
                        }
                      }}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-purple-100 hover:text-purple-700 text-slate-700 font-bold rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Revert</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
