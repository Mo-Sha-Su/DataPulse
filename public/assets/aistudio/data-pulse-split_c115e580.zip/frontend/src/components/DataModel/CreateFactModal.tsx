import React, { useState, useMemo } from 'react';
import { Dataset } from '../../types/dashboard';
import { FactTable } from '../../types/dataModel';
import { isKeyColumn, isMeasureColumn, createFactTableFromDataset } from '../../utils/dataModelingEngine';
import { X, Table, Check, Layers } from 'lucide-react';

interface Props {
  isOpen: boolean;
  datasets: Dataset[];
  onClose: () => void;
  onSave: (factTable: FactTable) => void;
}

export const CreateFactModal: React.FC<Props> = ({
  isOpen,
  datasets,
  onClose,
  onSave,
}) => {
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(() => datasets[0]?.id || '');
  const selectedDataset = datasets.find((d) => d.id === selectedDatasetId) || datasets[0];

  const [factName, setFactName] = useState<string>(() => {
    if (!selectedDataset) return 'FACT_TABLE';
    const clean = (selectedDataset.name || 'TABLE').toUpperCase().replace(/\s+/g, '_');
    return clean.startsWith('FACT_') ? clean : `FACT_${clean}`;
  });

  // Suggest keys and measures based on dataset columns
  const [foreignKeys, setForeignKeys] = useState<string[]>([]);
  const [measures, setMeasures] = useState<string[]>([]);
  const [primaryKey, setPrimaryKey] = useState<string>('');

  // Update suggestions when dataset changes
  React.useEffect(() => {
    if (selectedDataset) {
      const clean = (selectedDataset.name || 'TABLE').toUpperCase().replace(/\s+/g, '_');
      setFactName(clean.startsWith('FACT_') ? clean : `FACT_${clean}`);

      const detectedKeys = selectedDataset.columns.filter((c) => isKeyColumn(c.name)).map((c) => c.name);
      const detectedMeasures = selectedDataset.columns.filter((c) => isMeasureColumn(c.name, c.type, c.sampleValue)).map((c) => c.name);

      setPrimaryKey(detectedKeys[0] || '');
      setForeignKeys(detectedKeys.slice(1));
      setMeasures(detectedMeasures.length > 0 ? detectedMeasures : selectedDataset.columns.filter((c) => c.type === 'number').map((c) => c.name));
    }
  }, [selectedDatasetId]);

  if (!isOpen || !selectedDataset) return null;

  const toggleForeignKey = (col: string) => {
    if (foreignKeys.includes(col)) {
      setForeignKeys(foreignKeys.filter((k) => k !== col));
    } else {
      setForeignKeys([...foreignKeys, col]);
      // Cannot be measure and key at same time
      setMeasures(measures.filter((m) => m !== col));
    }
  };

  const toggleMeasure = (col: string) => {
    if (measures.includes(col)) {
      setMeasures(measures.filter((m) => m !== col));
    } else {
      setMeasures([...measures, col]);
      // Cannot be key and measure at same time
      setForeignKeys(foreignKeys.filter((k) => k !== col));
      if (primaryKey === col) setPrimaryKey('');
    }
  };

  const handleApply = () => {
    const fact = createFactTableFromDataset(
      selectedDataset,
      factName,
      foreignKeys,
      measures,
      primaryKey || undefined
    );
    onSave(fact);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Create / Designate Fact Table</h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Designate transaction metrics and foreign keys for your Star Schema
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {/* Dataset Selector */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Source Dataset</label>
            <select
              value={selectedDatasetId}
              onChange={(e) => setSelectedDatasetId(e.target.value)}
              className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-sky-500"
            >
              {datasets.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.rowCount ?? (d as any).row_count ?? (d.data?.length || 0)} rows, {d.columnCount ?? (d as any).column_count ?? (d.columns?.length || 0)} columns)
                </option>
              ))}
            </select>
          </div>

          {/* Fact Table Name */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Fact Table Name</label>
            <input
              type="text"
              value={factName}
              onChange={(e) => setFactName(e.target.value)}
              placeholder="e.g. FACT_SALES"
              className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-sky-500"
            />
          </div>

          {/* Primary Key (Optional) */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Primary Transaction Key (Optional)</label>
            <select
              value={primaryKey}
              onChange={(e) => setPrimaryKey(e.target.value)}
              className="w-full h-8 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
            >
              <option value="">(None - Composite Key)</option>
              {selectedDataset.columns.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name} ({c.type})
                </option>
              ))}
            </select>
          </div>

          {/* Foreign Keys Selection */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-[11px] font-bold text-slate-700">Foreign Keys (Links to Dimensions)</label>
              <span className="text-[10px] text-slate-400 font-semibold">{foreignKeys.length} selected</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl max-h-36 overflow-y-auto">
              {selectedDataset.columns.map((col) => {
                const isSelected = foreignKeys.includes(col.name);
                return (
                  <button
                    key={col.name}
                    type="button"
                    onClick={() => toggleForeignKey(col.name)}
                    className={`px-2.5 py-1.5 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-sky-50 border-sky-300 text-sky-800'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="truncate">🔗 {col.name}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-sky-600 shrink-0 ml-1" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Measures Selection */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-[11px] font-bold text-slate-700">Quantitative Measures (Metrics / Aggregations)</label>
              <span className="text-[10px] text-slate-400 font-semibold">{measures.length} selected</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl max-h-36 overflow-y-auto">
              {selectedDataset.columns.map((col) => {
                const isSelected = measures.includes(col.name);
                return (
                  <button
                    key={col.name}
                    type="button"
                    onClick={() => toggleMeasure(col.name)}
                    className={`px-2.5 py-1.5 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-amber-50 border-amber-300 text-amber-900'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="truncate">📐 {col.name}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-amber-600 shrink-0 ml-1" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            disabled={!factName.trim() || measures.length === 0}
            className="px-5 py-2 bg-amber-600 hover:bg-amber-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-xs"
          >
            Create Fact Table
          </button>
        </div>
      </div>
    </div>
  );
};
