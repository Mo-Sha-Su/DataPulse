import React from 'react';
import { SuggestedStarSchema } from '../../types/dataModel';
import { X, Sparkles, Check, CheckCircle2, ArrowRight, ShieldCheck, Layers, Box } from 'lucide-react';

interface Props {
  isOpen: boolean;
  suggestion: SuggestedStarSchema;
  onClose: () => void;
  onApply: () => void;
}

export const SuggestedStarSchemaModal: React.FC<Props> = ({
  isOpen,
  suggestion,
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-gradient-to-r from-sky-50 to-indigo-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-slate-900">Suggested Star Schema Architecture</h2>
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                    suggestion.confidence === 'High'
                      ? 'bg-emerald-100 text-emerald-800'
                      : suggestion.confidence === 'Medium'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-200 text-slate-700'
                  }`}
                >
                  Confidence: {suggestion.confidence} ({suggestion.confidenceScore}%)
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                Analysis of selected dataset keys, metric distributions, and cardinality
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {/* Summary Banner */}
          <div className="p-3 bg-white border border-slate-200 rounded-xl flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-sky-600 shrink-0" />
            <p className="font-semibold text-slate-800">{suggestion.summary}</p>
          </div>

          {/* Fact & Dimensions Breakdown */}
          <div className="grid grid-cols-2 gap-3">
            {/* Fact Tables */}
            <div className="p-3 bg-amber-50/50 border border-amber-200 rounded-xl space-y-2">
              <div className="flex items-center gap-2 font-bold text-amber-900">
                <Layers className="w-4 h-4 text-amber-600" />
                <span>Fact Tables ({suggestion.factTables.length})</span>
              </div>
              <div className="space-y-1.5">
                {suggestion.factTables.map((f) => (
                  <div key={f.id} className="p-2 bg-white border border-amber-200/80 rounded-lg">
                    <span className="font-bold text-slate-900 block">{f.name}</span>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                      <span>📐 {f.measures.length} Measures</span>
                      <span>•</span>
                      <span>🔗 {f.foreignKeys.length} Foreign Keys</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Dimension Tables */}
            <div className="p-3 bg-emerald-50/50 border border-emerald-200 rounded-xl space-y-2">
              <div className="flex items-center gap-2 font-bold text-emerald-900">
                <Box className="w-4 h-4 text-emerald-600" />
                <span>Dimension Tables ({suggestion.dimensionTables.length})</span>
              </div>
              <div className="space-y-1.5">
                {suggestion.dimensionTables.map((d) => (
                  <div key={d.id} className="p-2 bg-white border border-emerald-200/80 rounded-lg">
                    <span className="font-bold text-slate-900 block">{d.name}</span>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-1">
                      <span className="font-mono text-emerald-700">🔑 {d.primaryKey}</span>
                      <span>•</span>
                      <span>🏷️ {d.attributes.length} Attributes</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Detected Relationships */}
          <div>
            <span className="text-[11px] font-bold text-slate-700 mb-1.5 block">
              Auto-Detected Relationships ({suggestion.relationships.length})
            </span>
            <div className="space-y-1.5">
              {suggestion.relationships.map((r) => (
                <div
                  key={r.id}
                  className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between font-mono text-[11px]"
                >
                  <div className="flex items-center gap-2 text-slate-800">
                    <span className="font-bold text-emerald-700">{r.fromColumn}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-sky-100 text-sky-800 font-bold">
                      {r.cardinality}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                    <span className="font-bold text-amber-700">{r.toColumn}</span>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-sans font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    {r.confidence}% Match
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Rationale Points */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Detection Logic</span>
            {suggestion.reasons.map((r, i) => (
              <p key={i} className="text-[11px] text-slate-600 flex items-start gap-1.5">
                <span className="text-sky-600 font-bold">•</span>
                <span>{r}</span>
              </p>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Reject & Build Manually
          </button>
          <button
            onClick={() => {
              onApply();
              onClose();
            }}
            className="px-5 py-2 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-xs flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Apply Suggested Star Schema</span>
          </button>
        </div>
      </div>
    </div>
  );
};
