import React, { useState } from 'react';
import { Dataset } from '../../types/dashboard';
import { DimensionTable } from '../../types/dataModel';
import { isKeyColumn, createDimensionFromDataset } from '../../utils/dataModelingEngine';
import { X, Check, Box } from 'lucide-react';

interface Props {
  isOpen: boolean;
  datasets: Dataset[];
  onClose: () => void;
  onSave: (result: { dataset: Dataset; dimension: DimensionTable }) => void;
}

export const CreateDimensionModal: React.FC<Props> = ({
  isOpen,
  datasets,
  onClose,
  onSave,
}) => {
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(() => datasets[0]?.id || '');
  const selectedDataset = datasets.find((d) => d.id === selectedDatasetId) || datasets[0];

  const [dimName, setDimName] = useState<string>(() => {
    if (!selectedDataset) return 'DIM_ENTITY';
    const clean = (selectedDataset.name || 'ENTITY').toUpperCase().replace(/\s+/g, '_');
    return clean.startsWith('DIM_') ? clean : `DIM_${clean}`;
  });

  const [primaryKey, setPrimaryKey] = useState<string>('');
  const [selectedColumns, setSelectedColumns] = useState<string[]>([]);

  // Update suggestions when dataset changes
  React.useEffect(() => {
    if (selectedDataset) {
      const clean = (selectedDataset.name || 'ENTITY').toUpperCase().replace(/\s+/g, '_');
      setDimName(clean.startsWith('DIM_') ? clean : `DIM_${clean}`);

      const detectedKeys = selectedDataset.columns.filter((c) => isKeyColumn(c.name)).map((c) => c.name);
      const pk = detectedKeys[0] || selectedDataset.columns[0]?.name || '';
      setPrimaryKey(pk);
      // Select all columns by default
      setSelectedColumns(selectedDataset.columns.map((c) => c.name));
    }
  }, [selectedDatasetId]);

  if (!isOpen || !selectedDataset) return null;

  const toggleColumn = (col: string) => {
    if (col === primaryKey) return; // Cannot deselect primary key
    if (selectedColumns.includes(col)) {
      setSelectedColumns(selectedColumns.filter((c) => c !== col));
    } else {
      setSelectedColumns([...selectedColumns, col]);
    }
  };

  const handleApply = () => {
    if (!primaryKey || selectedColumns.length === 0) return;
    const res = createDimensionFromDataset(
      selectedDataset,
      selectedColumns,
      primaryKey,
      dimName
    );
    onSave(res);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Box className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Create Dimension Table</h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Extract descriptive attributes and a unique primary key for your Star Schema
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {/* Source Dataset */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Source Dataset</label>
            <select
              value={selectedDatasetId}
              onChange={(e) => setSelectedDatasetId(e.target.value)}
              className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-sky-500"
            >
              {datasets.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.rowCount ?? (d as any).row_count ?? (d.data?.length || 0)} rows)
                </option>
              ))}
            </select>
          </div>

          {/* Dimension Name */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Dimension Table Name</label>
            <input
              type="text"
              value={dimName}
              onChange={(e) => setDimName(e.target.value)}
              placeholder="e.g. DIM_CUSTOMER"
              className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-sky-500"
            />
          </div>

          {/* Primary Key Selection */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              Unique Primary Key (Must identify unique dimension rows)
            </label>
            <select
              value={primaryKey}
              onChange={(e) => {
                const val = e.target.value;
                setPrimaryKey(val);
                if (!selectedColumns.includes(val)) {
                  setSelectedColumns([...selectedColumns, val]);
                }
              }}
              className="w-full h-9 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold text-slate-900 focus:outline-sky-500"
            >
              {selectedDataset.columns.map((c) => (
                <option key={c.name} value={c.name}>
                  🔑 {c.name} ({c.type})
                </option>
              ))}
            </select>
          </div>

          {/* Columns Selection */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-[11px] font-bold text-slate-700">Included Attributes</label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedColumns(selectedDataset.columns.map((c) => c.name))}
                  className="text-[10px] text-sky-600 hover:underline font-semibold"
                >
                  Select All
                </button>
                <span className="text-slate-300">|</span>
                <button
                  type="button"
                  onClick={() => setSelectedColumns([primaryKey])}
                  className="text-[10px] text-slate-500 hover:underline font-semibold"
                >
                  Clear Optional
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl max-h-40 overflow-y-auto">
              {selectedDataset.columns.map((col) => {
                const isSelected = selectedColumns.includes(col.name);
                const isPk = col.name === primaryKey;

                return (
                  <button
                    key={col.name}
                    type="button"
                    onClick={() => toggleColumn(col.name)}
                    className={`px-2.5 py-1.5 rounded-lg border text-left text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                      isPk
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold'
                        : isSelected
                        ? 'bg-sky-50 border-sky-300 text-sky-800'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="truncate">
                      {isPk ? '🔑 ' : '🏷️ '}
                      {col.name}
                    </span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 ml-1" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleApply}
            disabled={!dimName.trim() || !primaryKey || selectedColumns.length === 0}
            className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-xs"
          >
            Create Dimension
          </button>
        </div>
      </div>
    </div>
  );
};
