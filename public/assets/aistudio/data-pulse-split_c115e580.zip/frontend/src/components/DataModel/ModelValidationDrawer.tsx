import React from 'react';
import { ModelValidationResult } from '../../types/dataModel';
import { X, ShieldCheck, AlertTriangle, AlertCircle, Info, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  validation: ModelValidationResult;
  onClose: () => void;
}

export const ModelValidationDrawer: React.FC<Props> = ({
  isOpen,
  validation,
  onClose,
}) => {
  if (!isOpen) return null;

  const scoreColor =
    validation.score >= 85
      ? 'text-emerald-600 bg-emerald-50 border-emerald-300'
      : validation.score >= 65
      ? 'text-amber-600 bg-amber-50 border-amber-300'
      : 'text-rose-600 bg-rose-50 border-rose-300';

  const progressBg =
    validation.score >= 85
      ? 'bg-emerald-500'
      : validation.score >= 65
      ? 'bg-amber-500'
      : 'bg-rose-500';

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white border-l border-slate-200 shadow-2xl flex flex-col animate-in slide-in-from-right duration-200 select-none text-slate-800">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900">Star Schema Validation</h2>
            <p className="text-[11px] text-slate-500 font-medium">
              Referential integrity, key uniqueness & modeling hygiene
            </p>
          </div>
        </div>
        <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Score Card */}
      <div className="p-5 border-b border-slate-200 bg-gradient-to-b from-slate-50/50 to-white space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Model Quality Score</span>
          <span className={`text-xl font-black font-mono px-3 py-1 rounded-xl border ${scoreColor}`}>
            {validation.score}/100
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
          <div
            className={`h-full ${progressBg} transition-all duration-500`}
            style={{ width: `${validation.score}%` }}
          />
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium pt-1">
          <span>{validation.passedChecks} of {validation.totalChecks} hygiene checks passed</span>
          <span>{validation.issues.length} observation(s)</span>
        </div>
      </div>

      {/* Issues & Checks List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 text-xs">
        {/* Passed Highlights */}
        {validation.score >= 80 && (
          <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-emerald-900">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Core Star Schema Validated</span>
            </div>
            <p className="text-[11px] text-emerald-700">
              Fact and Dimension tables are cleanly segregated. High-performance joins can be utilized across widgets.
            </p>
          </div>
        )}

        {/* Issues List */}
        {validation.issues.length === 0 ? (
          <div className="p-6 text-center text-slate-400 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
            <p className="font-bold text-slate-800">Perfect Star Schema!</p>
            <p className="text-[11px]">No referential integrity flaws, orphan keys, or cardinality issues found.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
              Observations & Action Items
            </span>

            {validation.issues.map((iss) => {
              const Icon =
                iss.severity === 'error'
                  ? AlertCircle
                  : iss.severity === 'warning'
                  ? AlertTriangle
                  : Info;

              const border =
                iss.severity === 'error'
                  ? 'border-rose-200 bg-rose-50/50'
                  : iss.severity === 'warning'
                  ? 'border-amber-200 bg-amber-50/50'
                  : 'border-sky-200 bg-sky-50/50';

              const iconColor =
                iss.severity === 'error'
                  ? 'text-rose-600'
                  : iss.severity === 'warning'
                  ? 'text-amber-600'
                  : 'text-sky-600';

              return (
                <div key={iss.id} className={`p-3 rounded-xl border ${border} space-y-1.5`}>
                  <div className="flex items-start gap-2">
                    <Icon className={`w-4 h-4 ${iconColor} shrink-0 mt-0.5`} />
                    <div>
                      <h4 className="font-bold text-slate-900 leading-tight">{iss.title}</h4>
                      <p className="text-[11px] text-slate-600 mt-0.5">{iss.message}</p>
                    </div>
                  </div>

                  {iss.suggestedAction && (
                    <div className="pl-6 pt-1 text-[10px] text-slate-500 font-medium">
                      <strong className="text-slate-700">Recommendation:</strong> {iss.suggestedAction}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
        <button
          onClick={onClose}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
        >
          Close Panel
        </button>
      </div>
    </div>
  );
};
