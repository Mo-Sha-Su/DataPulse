import React, { useState, useMemo } from 'react';
import { Dataset } from '../../types/dashboard';
import { FactTable, DimensionTable, Relationship, Cardinality } from '../../types/dataModel';
import { X, Network, AlertTriangle, CheckCircle2, ArrowRight } from 'lucide-react';

interface Props {
  isOpen: boolean;
  factTables: FactTable[];
  dimensionTables: DimensionTable[];
  datasets: Dataset[];
  existingRelationships: Relationship[];
  initialRelationship?: Relationship | null;
  onClose: () => void;
  onSave: (rel: Relationship) => void;
}

export const CreateRelationshipModal: React.FC<Props> = ({
  isOpen,
  factTables,
  dimensionTables,
  datasets,
  existingRelationships,
  initialRelationship,
  onClose,
  onSave,
}) => {
  const allTables = useMemo(() => {
    return [
      ...dimensionTables.map((d) => ({ id: d.id, name: d.name, type: 'DIM' as const, datasetId: d.datasetId, defaultCol: d.primaryKey })),
      ...factTables.map((f) => ({ id: f.id, name: f.name, type: 'FACT' as const, datasetId: f.datasetId, defaultCol: f.foreignKeys[0] || f.primaryKey || '' })),
    ];
  }, [dimensionTables, factTables]);

  const [fromTableId, setFromTableId] = useState<string>(() => {
    if (initialRelationship) return initialRelationship.fromTableId;
    return dimensionTables[0]?.id || allTables[0]?.id || '';
  });

  const [toTableId, setToTableId] = useState<string>(() => {
    if (initialRelationship) return initialRelationship.toTableId;
    return factTables[0]?.id || allTables[1]?.id || '';
  });

  const datasetMap = useMemo(() => {
    const map = new Map<string, Dataset>();
    datasets.forEach((d) => map.set(d.id, d));
    return map;
  }, [datasets]);

  const fromTable = allTables.find((t) => t.id === fromTableId);
  const toTable = allTables.find((t) => t.id === toTableId);

  const fromDataset = fromTable ? datasetMap.get(fromTable.datasetId) : undefined;
  const toDataset = toTable ? datasetMap.get(toTable.datasetId) : undefined;

  const fromColumns = fromDataset ? fromDataset.columns.map((c) => c.name) : [];
  const toColumns = toDataset ? toDataset.columns.map((c) => c.name) : [];

  const [fromColumn, setFromColumn] = useState<string>(() => {
    if (initialRelationship) return initialRelationship.fromColumn;
    return fromTable?.defaultCol || fromColumns[0] || '';
  });

  const [toColumn, setToColumn] = useState<string>(() => {
    if (initialRelationship) return initialRelationship.toColumn;
    return toColumns.find((c) => c.toLowerCase() === fromColumn.toLowerCase()) || toTable?.defaultCol || toColumns[0] || '';
  });

  const [cardinality, setCardinality] = useState<Cardinality>(() => {
    return initialRelationship?.cardinality || '1:*';
  });

  // Validation
  const validation = useMemo(() => {
    const warnings: string[] = [];
    const errors: string[] = [];

    if (!fromTableId || !toTableId) {
      errors.push('Both tables must be selected.');
      return { isValid: false, warnings, errors, matchPct: 0 };
    }

    if (fromTableId === toTableId) {
      errors.push('Cannot create a relationship from a table to itself.');
      return { isValid: false, warnings, errors, matchPct: 0 };
    }

    if (!fromColumn || !toColumn) {
      errors.push('Both joining columns must be selected.');
      return { isValid: false, warnings, errors, matchPct: 0 };
    }

    // Check duplicate relationship
    const isDup = existingRelationships.some(
      (r) =>
        r.id !== initialRelationship?.id &&
        r.fromTableId === fromTableId &&
        r.fromColumn === fromColumn &&
        r.toTableId === toTableId &&
        r.toColumn === toColumn
    );
    if (isDup) {
      errors.push('This relationship already exists.');
    }

    // Referential Integrity Check
    let matchPct = 100;
    if (fromDataset && toDataset) {
      const fromKeys = new Set(fromDataset.data.map((r) => String(r[fromColumn] ?? '')));
      const toKeys = toDataset.data.map((r) => String(r[toColumn] ?? '')).filter((k) => k !== '');

      // Check unique dimension keys
      if (fromTable?.type === 'DIM') {
        const rawFromKeys = fromDataset.data.map((r) => r[fromColumn]);
        const uniqueFromCount = new Set(rawFromKeys).size;
        if (rawFromKeys.length > uniqueFromCount) {
          warnings.push(
            `Primary key column '${fromColumn}' in '${fromTable.name}' contains duplicates. 1:* relationships expect unique dimension keys.`
          );
        }
      }

      if (toKeys.length > 0) {
        const orphans = toKeys.filter((k) => !fromKeys.has(k));
        if (orphans.length > 0) {
          const orphanPct = Math.round((orphans.length / toKeys.length) * 100);
          matchPct = 100 - orphanPct;
          if (orphanPct > 20) {
            warnings.push(
              `${orphanPct}% of records in '${toTable?.name}' have '${toColumn}' keys that do not exist in '${fromTable?.name}'.`
            );
          } else {
            warnings.push(`${orphans.length} orphan records detected (${orphanPct}%).`);
          }
        }
      }

      // Check data type compatibility
      const fromColDef = fromDataset.columns.find((c) => c.name === fromColumn);
      const toColDef = toDataset.columns.find((c) => c.name === toColumn);
      if (fromColDef && toColDef && fromColDef.type !== toColDef.type) {
        warnings.push(
          `Data type mismatch: '${fromColumn}' is ${fromColDef.type}, while '${toColumn}' is ${toColDef.type}.`
        );
      }
    }

    return {
      isValid: errors.length === 0,
      warnings,
      errors,
      matchPct,
    };
  }, [fromTableId, toTableId, fromColumn, toColumn, fromDataset, toDataset, existingRelationships, initialRelationship, fromTable, toTable]);

  if (!isOpen) return null;

  const handleSave = () => {
    if (!validation.isValid) return;

    const rel: Relationship = {
      id: initialRelationship?.id || `rel_${fromTableId}_${toTableId}_${Date.now()}`,
      name: `${fromTable?.name} (${fromColumn}) ── ${cardinality} ──> ${toTable?.name} (${toColumn})`,
      fromTableId,
      fromColumn,
      toTableId,
      toColumn,
      cardinality,
      isActive: true,
      confidence: 100,
    };
    onSave(rel);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <Network className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                {initialRelationship ? 'Edit Relationship' : 'Create Star Schema Relationship'}
              </h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Connect Dimension (1) to Fact (*) or establish table foreign key relationships
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700">
          {/* Visual Link Indicator */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
            <div className="flex-1 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">From (Dimension)</span>
              <span className="font-bold text-slate-900 truncate block">{fromTable?.name || 'Select table'}</span>
              <span className="text-[11px] font-mono text-sky-600 font-semibold">{fromColumn || 'Select column'}</span>
            </div>
            <div className="px-3 flex flex-col items-center">
              <span className="text-[10px] font-bold font-mono px-2 py-0.5 rounded-full bg-sky-100 text-sky-800">
                {cardinality}
              </span>
              <ArrowRight className="w-4 h-4 text-slate-400 my-1" />
            </div>
            <div className="flex-1 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">To (Fact)</span>
              <span className="font-bold text-slate-900 truncate block">{toTable?.name || 'Select table'}</span>
              <span className="text-[11px] font-mono text-sky-600 font-semibold">{toColumn || 'Select column'}</span>
            </div>
          </div>

          {/* Form Grid */}
          <div className="grid grid-cols-2 gap-4">
            {/* From Table & Column */}
            <div className="space-y-3 p-3 bg-white border border-slate-200 rounded-xl">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">From Table (Dimension / Parent)</label>
                <select
                  value={fromTableId}
                  onChange={(e) => {
                    const newId = e.target.value;
                    setFromTableId(newId);
                    const t = allTables.find((tbl) => tbl.id === newId);
                    const ds = t ? datasetMap.get(t.datasetId) : undefined;
                    setFromColumn(t?.defaultCol || ds?.columns[0]?.name || '');
                  }}
                  className="w-full h-8 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                >
                  {allTables.map((t) => (
                    <option key={t.id} value={t.id}>
                      [{t.type}] {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">From Column (Primary Key)</label>
                <select
                  value={fromColumn}
                  onChange={(e) => setFromColumn(e.target.value)}
                  className="w-full h-8 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                >
                  {fromColumns.map((col) => (
                    <option key={col} value={col}>
                      {col}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* To Table & Column */}
            <div className="space-y-3 p-3 bg-white border border-slate-200 rounded-xl">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">To Table (Fact / Child)</label>
                <select
                  value={toTableId}
                  onChange={(e) => {
                    const newId = e.target.value;
                    setToTableId(newId);
                    const t = allTables.find((tbl) => tbl.id === newId);
                    const ds = t ? datasetMap.get(t.datasetId) : undefined;
                    setToColumn(t?.defaultCol || ds?.columns[0]?.name || '');
                  }}
                  className="w-full h-8 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                >
                  {allTables.map((t) => (
                    <option key={t.id} value={t.id}>
                      [{t.type}] {t.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">To Column (Foreign Key)</label>
                <select
                  value={toColumn}
                  onChange={(e) => setToColumn(e.target.value)}
                  className="w-full h-8 px-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                >
                  {toColumns.map((col) => (
                    <option key={col} value={col}>
                      {col}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Cardinality Selector */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">Cardinality</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setCardinality('1:*')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-0.5 transition-all cursor-pointer ${
                  cardinality === '1:*'
                    ? 'bg-sky-50 border-sky-400 text-sky-800 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span>One-to-Many (1 : *)</span>
                <span className="text-[10px] font-normal text-slate-500">Standard Star Schema</span>
              </button>

              <button
                type="button"
                onClick={() => setCardinality('*:1')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-0.5 transition-all cursor-pointer ${
                  cardinality === '*:1'
                    ? 'bg-sky-50 border-sky-400 text-sky-800 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span>Many-to-One (* : 1)</span>
                <span className="text-[10px] font-normal text-slate-500">Fact to Dimension</span>
              </button>

              <button
                type="button"
                onClick={() => setCardinality('1:1')}
                className={`py-2 px-3 rounded-xl border text-xs font-bold flex flex-col items-center gap-0.5 transition-all cursor-pointer ${
                  cardinality === '1:1'
                    ? 'bg-sky-50 border-sky-400 text-sky-800 shadow-xs'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <span>One-to-One (1 : 1)</span>
                <span className="text-[10px] font-normal text-slate-500">Strict mapping</span>
              </button>
            </div>
          </div>

          {/* Validation Feedback */}
          {validation.errors.length > 0 && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-1 text-rose-800">
              {validation.errors.map((err, i) => (
                <div key={i} className="flex items-center gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>{err}</span>
                </div>
              ))}
            </div>
          )}

          {validation.warnings.length > 0 && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1 text-amber-800">
              {validation.warnings.map((warn, i) => (
                <div key={i} className="flex items-center gap-2">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                  <span>{warn}</span>
                </div>
              ))}
            </div>
          )}

          {validation.isValid && validation.warnings.length === 0 && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-800 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Referential integrity verified: 100% key compatibility with zero orphans.</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!validation.isValid}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-700 disabled:bg-slate-300 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer shadow-xs"
          >
            {initialRelationship ? 'Update Relationship' : 'Create Relationship'}
          </button>
        </div>
      </div>
    </div>
  );
};
