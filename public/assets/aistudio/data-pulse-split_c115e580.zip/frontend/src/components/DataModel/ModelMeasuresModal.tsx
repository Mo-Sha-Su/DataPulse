import React, { useState } from 'react';
import { FactTable, DimensionTable, ModelMeasure, MeasureAggregation } from '../../types/dataModel';
import { X, Calculator, Plus, Trash2, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  factTables: FactTable[];
  dimensionTables: DimensionTable[];
  existingMeasures: ModelMeasure[];
  onClose: () => void;
  onSaveMeasure: (measure: ModelMeasure) => void;
  onDeleteMeasure: (id: string) => void;
}

export const ModelMeasuresModal: React.FC<Props> = ({
  isOpen,
  factTables,
  dimensionTables,
  existingMeasures,
  onClose,
  onSaveMeasure,
  onDeleteMeasure,
}) => {
  const [measureName, setMeasureName] = useState('Total Sales');
  const [aggregation, setAggregation] = useState<MeasureAggregation>('sum');
  const [targetTable, setTargetTable] = useState<string>(() => factTables[0]?.name || '');
  const [targetColumn, setTargetColumn] = useState<string>(() => factTables[0]?.measures[0] || '');
  const [secondaryMeasure, setSecondaryMeasure] = useState<string>('');
  const [format, setFormat] = useState<'number' | 'currency' | 'percentage' | 'compact'>('currency');
  const [currencySymbol, setCurrencySymbol] = useState('$');

  const selectedFact = factTables.find((f) => f.name === targetTable) || factTables[0];
  const availableColumns = selectedFact ? [...selectedFact.measures, ...selectedFact.foreignKeys] : [];

  if (!isOpen) return null;

  // Generate formula expression preview
  let expressionPreview = '';
  if (aggregation === 'divide') {
    expressionPreview = `DIVIDE([${measureName || 'Numerator'}], [${secondaryMeasure || 'Denominator'}])`;
  } else {
    expressionPreview = `${(aggregation || 'SUM').toUpperCase()}(${targetTable}[${targetColumn}])`;
  }

  const handleSave = () => {
    if (!measureName.trim() || !targetTable) return;

    const newMeasure: ModelMeasure = {
      id: `meas_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
      name: measureName.trim(),
      expression: expressionPreview,
      aggregation,
      targetTable,
      targetColumn: aggregation === 'divide' ? (selectedFact?.measures[0] || 'Sales') : targetColumn,
      secondaryMeasure: aggregation === 'divide' ? secondaryMeasure : undefined,
      format,
      currencySymbol,
    };

    onSaveMeasure(newMeasure);
    // Reset form
    setMeasureName('');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-2xl bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Calculated Model Measures</h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Create reusable analytical metrics (e.g. SUM, AVG, Ratio DIVIDE) across your star schema
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {/* Existing Measures List */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <span className="text-[11px] font-bold text-slate-700">Existing Model Measures ({existingMeasures.length})</span>
            </div>
            {existingMeasures.length === 0 ? (
              <div className="p-3 bg-slate-50 border border-dashed border-slate-300 rounded-xl text-center text-slate-400">
                No custom measures created yet. Use the visual builder below.
              </div>
            ) : (
              <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                {existingMeasures.map((m) => (
                  <div
                    key={m.id}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between hover:border-sky-300 transition-colors"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">{m.name}</span>
                      <code className="text-[11px] font-mono text-sky-700 font-semibold">{m.expression}</code>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 font-bold uppercase">
                        {m.format}
                      </span>
                      <button
                        onClick={() => onDeleteMeasure(m.id)}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                        title="Delete measure"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-2 border-t border-slate-200">
            <h3 className="font-bold text-slate-900 mb-2">Create New Measure</h3>

            {/* Visual Formula Builder */}
            <div className="space-y-3 p-3 bg-sky-50/50 border border-sky-200 rounded-xl">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Measure Name</label>
                  <input
                    type="text"
                    value={measureName}
                    onChange={(e) => setMeasureName(e.target.value)}
                    placeholder="e.g. Total Revenue or Profit Margin"
                    className="w-full h-8 px-2.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:outline-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Aggregation Function</label>
                  <select
                    value={aggregation}
                    onChange={(e) => setAggregation(e.target.value as MeasureAggregation)}
                    className="w-full h-8 px-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                  >
                    <option value="sum">SUM (Total of column values)</option>
                    <option value="avg">AVERAGE (Mean of values)</option>
                    <option value="count">COUNT (Total rows)</option>
                    <option value="distinct_count">DISTINCT COUNT (Unique values)</option>
                    <option value="min">MIN (Smallest value)</option>
                    <option value="max">MAX (Largest value)</option>
                    <option value="divide">DIVIDE (Ratio of two measures / Profit Margin)</option>
                  </select>
                </div>
              </div>

              {aggregation !== 'divide' ? (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Target Table</label>
                    <select
                      value={targetTable}
                      onChange={(e) => {
                        setTargetTable(e.target.value);
                        const f = factTables.find((tbl) => tbl.name === e.target.value);
                        setTargetColumn(f?.measures[0] || '');
                      }}
                      className="w-full h-8 px-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                    >
                      {factTables.map((f) => (
                        <option key={f.id} value={f.name}>
                          {f.name} (Fact)
                        </option>
                      ))}
                      {dimensionTables.map((d) => (
                        <option key={d.id} value={d.name}>
                          {d.name} (Dimension)
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Target Field / Measure Column</label>
                    <select
                      value={targetColumn}
                      onChange={(e) => setTargetColumn(e.target.value)}
                      className="w-full h-8 px-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                    >
                      {availableColumns.map((col) => (
                        <option key={col} value={col}>
                          {col}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Numerator Measure</label>
                    <select
                      value={targetColumn}
                      onChange={(e) => setTargetColumn(e.target.value)}
                      className="w-full h-8 px-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                    >
                      {selectedFact?.measures.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">Denominator Measure</label>
                    <select
                      value={secondaryMeasure}
                      onChange={(e) => setSecondaryMeasure(e.target.value)}
                      className="w-full h-8 px-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                    >
                      <option value="">Select Denominator...</option>
                      {existingMeasures.map((m) => (
                        <option key={m.name} value={m.name}>
                          [{m.name}]
                        </option>
                      ))}
                      {selectedFact?.measures.map((m) => (
                        <option key={m} value={m}>
                          [{selectedFact.name}[{m}]]
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              {/* Number Format */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Output Format</label>
                  <select
                    value={format}
                    onChange={(e) => setFormat(e.target.value as any)}
                    className="w-full h-8 px-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:outline-sky-500"
                  >
                    <option value="currency">Currency ($1,250.00)</option>
                    <option value="percentage">Percentage (34.5%)</option>
                    <option value="compact">Compact ($1.2M / $45K)</option>
                    <option value="number">Standard Number (1,250)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">Currency Symbol</label>
                  <input
                    type="text"
                    value={currencySymbol}
                    disabled={format !== 'currency' && format !== 'compact'}
                    onChange={(e) => setCurrencySymbol(e.target.value)}
                    className="w-full h-8 px-2.5 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-sky-500 disabled:bg-slate-100"
                  />
                </div>
              </div>

              {/* Generated Formula Expression Display */}
              <div className="p-2.5 bg-white border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Generated Formula</span>
                  <code className="text-xs font-mono font-bold text-sky-700">{expressionPreview}</code>
                </div>
                <button
                  type="button"
                  onClick={handleSave}
                  disabled={!measureName.trim()}
                  className="px-4 py-1.5 bg-sky-600 hover:bg-sky-700 disabled:bg-slate-300 text-white font-bold rounded-lg text-xs transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Measure</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
