import React, { useRef, useState, useEffect } from 'react';
import { Widget, Dataset, CanvasSettings, DataFilter, ReportPage } from '../../types/dashboard';
import { WidgetCard } from '../Widget/WidgetCard';
import { DataModelState } from '../../types/dataModel';
import { getCanvasDimensionsFromSettings } from '../../utils/reportPageDimensions';
import { Maximize2, Sliders, Check, X, Lock, Unlock } from 'lucide-react';

interface Props {
  widgets: Widget[];
  datasets: Dataset[];
  canvas: CanvasSettings;
  pages?: ReportPage[];
  activePageId?: string;
  globalFilters?: DataFilter[];
  dataModel?: DataModelState;
  selectedWidgetId: string | null;
  configuringWidgetId?: string | null;
  isPreviewMode?: boolean;
  onSelectWidget: (widgetId: string | null) => void;
  onUpdateWidgetPosition: (widgetId: string, x: number, y: number, width: number, height: number) => void;
  onDuplicateWidget: (widgetId: string) => void;
  onDeleteWidget: (widgetId: string) => void;
  onOpenWidgetConfig: (widgetId: string) => void;
  onUpdateCanvas?: (updatedCanvas: Partial<CanvasSettings>) => void;
}

export const CanvasWorkspace: React.FC<Props> = ({
  widgets,
  datasets,
  canvas,
  pages = [],
  activePageId,
  globalFilters,
  dataModel,
  selectedWidgetId,
  configuringWidgetId,
  isPreviewMode = false,
  onSelectWidget,
  onUpdateWidgetPosition,
  onDuplicateWidget,
  onDeleteWidget,
  onOpenWidgetConfig,
  onUpdateCanvas,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Derive canvas dimensions and printable page margins
  const { widthPx, heightPx, marginsPx } = getCanvasDimensionsFromSettings(canvas);

  // Interactive manual canvas resizing state
  const [resizingEdge, setResizingEdge] = useState<'right' | 'bottom' | 'corner' | null>(null);
  const [liveSize, setLiveSize] = useState<{ width: number; height: number } | null>(null);
  const resizeStartRef = useRef<{ startX: number; startY: number; startWidth: number; startHeight: number }>({
    startX: 0,
    startY: 0,
    startWidth: 0,
    startHeight: 0,
  });

  // Quick In-Canvas Manual Size Dialog
  const [isQuickSizeOpen, setIsQuickSizeOpen] = useState(false);
  const [quickWidth, setQuickWidth] = useState(widthPx);
  const [quickHeight, setQuickHeight] = useState(heightPx);
  const [quickLockRatio, setQuickLockRatio] = useState(false);

  useEffect(() => {
    setQuickWidth(widthPx);
    setQuickHeight(heightPx);
  }, [widthPx, heightPx]);

  const activeWidth = liveSize ? liveSize.width : widthPx;
  const activeHeight = liveSize ? liveSize.height : heightPx;

  // Filter widgets belonging to current active page
  const activeWidgets = widgets.filter((w) => {
    if (!activePageId) return true;
    if (!w.pageId) {
      const firstPageId = pages && pages.length > 0 ? pages[0].id : null;
      return !firstPageId || activePageId === firstPageId;
    }
    return w.pageId === activePageId;
  });

  // Dynamic Background Style
  const getBackgroundStyle = (): React.CSSProperties => {
    if (canvas.backgroundType === 'gradient') {
      return { background: canvas.gradientValue };
    }
    if (canvas.backgroundType === 'image' && canvas.imageUrl) {
      return {
        backgroundImage: `url(${canvas.imageUrl})`,
        backgroundSize: canvas.imageFit,
        backgroundRepeat: canvas.imageFit === 'tile' ? 'repeat' : 'no-repeat',
        backgroundPosition: 'center',
      };
    }
    return { backgroundColor: canvas.backgroundColor || '#FFFFFF' };
  };

  const effectivePageId = activePageId || (pages && pages[0]?.id) || 'p_1';

  // Manual interactive drag resizing handlers
  const handleStartResize = (e: React.MouseEvent, edge: 'right' | 'bottom' | 'corner') => {
    if (isPreviewMode || !onUpdateCanvas) return;
    e.stopPropagation();
    e.preventDefault();

    setResizingEdge(edge);
    setLiveSize({ width: widthPx, height: heightPx });
    resizeStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      startWidth: widthPx,
      startHeight: heightPx,
    };

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const zoom = canvas.zoom || 1;
      const dx = (moveEvent.clientX - resizeStartRef.current.startX) / zoom;
      const dy = (moveEvent.clientY - resizeStartRef.current.startY) / zoom;

      let newW = resizeStartRef.current.startWidth;
      let newH = resizeStartRef.current.startHeight;

      if (edge === 'right' || edge === 'corner') {
        newW = Math.max(400, Math.min(8000, Math.round(resizeStartRef.current.startWidth + dx)));
        if (canvas.snapToGrid && canvas.gridGap > 0) {
          newW = Math.round(newW / canvas.gridGap) * canvas.gridGap;
        }
      }

      if (edge === 'bottom' || edge === 'corner') {
        newH = Math.max(300, Math.min(8000, Math.round(resizeStartRef.current.startHeight + dy)));
        if (canvas.snapToGrid && canvas.gridGap > 0) {
          newH = Math.round(newH / canvas.gridGap) * canvas.gridGap;
        }
      }

      setLiveSize({ width: newW, height: newH });
    };

    const handleMouseUp = () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      setResizingEdge(null);

      setLiveSize((finalSize) => {
        if (finalSize && (finalSize.width !== widthPx || finalSize.height !== heightPx)) {
          onUpdateCanvas({
            width: finalSize.width,
            height: finalSize.height,
            pageSizePreset: 'Custom Size',
            presetName: `Custom (${finalSize.width}×${finalSize.height})`,
          });
        }
        return null;
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  const handleApplyQuickSize = () => {
    if (!onUpdateCanvas) return;
    const w = Math.max(400, Math.min(8000, Math.round(quickWidth)));
    const h = Math.max(300, Math.min(8000, Math.round(quickHeight)));
    onUpdateCanvas({
      width: w,
      height: h,
      pageSizePreset: 'Custom Size',
      presetName: `Custom (${w}×${h})`,
    });
    setIsQuickSizeOpen(false);
  };

  return (
    <main
      ref={containerRef}
      onClick={() => {
        if (!isPreviewMode) onSelectWidget(null);
      }}
      className="flex-1 h-full overflow-auto bg-slate-200/80 relative p-8 flex flex-col items-center select-none"
    >
      {/* Printable Document Paper Canvas Container */}
      <div
        id="report-canvas-root"
        data-report-page-id={effectivePageId}
        style={{
          width: `${activeWidth}px`,
          height: `${activeHeight}px`,
          transform: `scale(${canvas.zoom})`,
          transformOrigin: 'top center',
          transition: resizingEdge ? 'none' : 'transform 0.15s ease-out, width 0.15s ease, height 0.15s ease',
          ...getBackgroundStyle(),
        }}
        className="relative shadow-2xl rounded-sm border border-slate-300 overflow-hidden shrink-0 bg-white"
      >
        {/* Printable Margins Bounding Box Guideline Overlay */}
        {!isPreviewMode && marginsPx && (
          <div
            data-no-print="true"
            style={{
              top: `${marginsPx.top}px`,
              right: `${marginsPx.right}px`,
              bottom: `${marginsPx.bottom}px`,
              left: `${marginsPx.left}px`,
            }}
            className="absolute border border-dashed border-sky-400/50 pointer-events-none z-10"
          >
            <span className="absolute -top-4 left-0 text-[9px] font-bold tracking-wider text-sky-500 uppercase opacity-70">
              Print Margin ({canvas.margins?.top || 12}{canvas.margins?.unit || 'mm'})
            </span>
          </div>
        )}

        {/* Grid Pattern Overlay */}
        {canvas.showGrid && (
          <div
            data-no-print="true"
            className="absolute inset-0 pointer-events-none opacity-20"
            style={{
              backgroundImage: `radial-gradient(circle, #64748B 1px, transparent 1px)`,
              backgroundSize: `${canvas.gridGap * 2}px ${canvas.gridGap * 2}px`,
            }}
          />
        )}

        {/* Render Canvas Widgets for Active Page */}
        {activeWidgets.map((widget) => (
          <WidgetCard
            key={widget.id}
            widget={widget}
            datasets={datasets}
            canvas={canvas}
            globalFilters={globalFilters}
            dataModel={dataModel}
            isSelected={selectedWidgetId === widget.id}
            isConfiguring={configuringWidgetId === widget.id}
            isPreviewMode={isPreviewMode}
            onSelect={(id) => onSelectWidget(id)}
            onUpdatePosition={onUpdateWidgetPosition}
            onDuplicate={onDuplicateWidget}
            onDelete={onDeleteWidget}
            onOpenConfig={onOpenWidgetConfig}
          />
        ))}

        {/* Empty Page Prompt */}
        {activeWidgets.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-500 pointer-events-none p-6 text-center">
            <div className="p-8 bg-white/95 rounded-3xl border border-slate-200 shadow-xl backdrop-blur max-w-md pointer-events-auto">
              <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center mx-auto text-indigo-600 mb-4 font-bold text-2xl">
                📊
              </div>
              <h3 className="text-lg font-black text-slate-800">
                {datasets.length === 0 ? 'No datasets selected' : 'No widgets yet'}
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 leading-relaxed mb-4">
                {datasets.length === 0
                  ? 'Attach datasets from your Data Hub to begin designing your star schema and adding analytical widgets.'
                  : 'Your data is attached. Add charts, KPIs, tables, or cards from the left sidebar or toolbar.'}
              </p>
              <div className="text-xs font-semibold text-slate-400">
                {datasets.length === 0
                  ? 'Select datasets from the Data Hub or sidebar to begin.'
                  : 'Choose a widget from the toolbar above to get started.'}
              </div>
            </div>
          </div>
        )}

        {/* --- INTERACTIVE CANVAS RESIZE HANDLES (VISIBLE WHEN NOT PREVIEWING) --- */}
        {!isPreviewMode && onUpdateCanvas && (
          <>
            {/* Right Edge Resize Handle */}
            <div
              onMouseDown={(e) => handleStartResize(e, 'right')}
              className="absolute top-0 right-0 w-3 h-full cursor-ew-resize hover:bg-indigo-500/30 transition-colors z-30 group"
              title="Click and drag to manually adjust canvas width"
            >
              <div className="w-1 h-12 bg-slate-400/80 group-hover:bg-indigo-600 rounded-full mx-auto my-auto relative top-1/2 -translate-y-1/2 transition-colors shadow-xs" />
            </div>

            {/* Bottom Edge Resize Handle */}
            <div
              onMouseDown={(e) => handleStartResize(e, 'bottom')}
              className="absolute bottom-0 left-0 w-full h-3 cursor-ns-resize hover:bg-indigo-500/30 transition-colors z-30 group"
              title="Click and drag to manually adjust canvas height"
            >
              <div className="h-1 w-12 bg-slate-400/80 group-hover:bg-indigo-600 rounded-full mx-auto my-auto relative left-1/2 -translate-x-1/2 transition-colors shadow-xs" />
            </div>

            {/* Bottom-Right Corner Resize Handle */}
            <div
              onMouseDown={(e) => handleStartResize(e, 'corner')}
              className="absolute bottom-0 right-0 w-6 h-6 cursor-nwse-resize bg-white/95 border-2 border-indigo-600 rounded-tl-xl shadow-lg flex items-center justify-center text-indigo-600 hover:bg-indigo-600 hover:text-white transition-all z-40 group"
              title="Click and drag to manually resize canvas width and height"
            >
              <Maximize2 className="w-3.5 h-3.5 rotate-90" />
            </div>
          </>
        )}

        {/* Live Resizing Tooltip / Badge */}
        {resizingEdge && (
          <div className="absolute bottom-4 right-8 z-50 bg-slate-900/95 text-white border border-slate-700 px-3 py-1.5 rounded-xl shadow-2xl font-mono text-xs font-bold flex items-center gap-2 backdrop-blur animate-in fade-in duration-100">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>
              {activeWidth} × {activeHeight} px
            </span>
            <span className="text-slate-400 font-sans font-normal text-[10px]">
              ({(activeWidth / activeHeight).toFixed(2)}:1)
            </span>
          </div>
        )}
      </div>

      {/* Floating Canvas Size Badge & Manual Adjuster Button */}
      {!isPreviewMode && onUpdateCanvas && (
        <div className="mt-4 flex items-center gap-2 z-20">
          <div className="bg-white/90 backdrop-blur border border-slate-300 rounded-xl px-3 py-1.5 shadow-md flex items-center gap-2.5 text-xs text-slate-700">
            <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900">
              <span className="text-slate-400 font-sans font-normal text-[11px]">Size:</span>
              <span>{widthPx} × {heightPx} px</span>
            </div>
            <span className="w-1 h-3 bg-slate-200 rounded-full" />
            <button
              type="button"
              onClick={() => setIsQuickSizeOpen((prev) => !prev)}
              className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-md font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
              title="Open Manual Canvas Size Adjuster"
            >
              <Sliders className="w-3 h-3" />
              <span>Adjust Canvas Size</span>
            </button>
          </div>

          {/* Quick Size Popover Dialog */}
          {isQuickSizeOpen && (
            <div className="fixed bottom-16 bg-white border border-slate-200 rounded-2xl shadow-2xl p-4 w-76 text-xs text-slate-800 z-50 animate-in fade-in slide-in-from-bottom-2 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
                <span className="font-bold text-slate-900 text-sm">Manual Canvas Size</span>
                <button
                  type="button"
                  onClick={() => setIsQuickSizeOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 rounded-md cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Width & Height Number Inputs */}
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Width (px)
                  </label>
                  <input
                    type="number"
                    min={400}
                    max={8000}
                    step={10}
                    value={quickWidth}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || 400;
                      setQuickWidth(val);
                      if (quickLockRatio && quickWidth > 0) {
                        const ratio = quickHeight / quickWidth;
                        setQuickHeight(Math.round(val * ratio));
                      }
                    }}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Height (px)
                  </label>
                  <input
                    type="number"
                    min={300}
                    max={8000}
                    step={10}
                    value={quickHeight}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || 300;
                      setQuickHeight(val);
                      if (quickLockRatio && quickHeight > 0) {
                        const ratio = quickWidth / quickHeight;
                        setQuickWidth(Math.round(val * ratio));
                      }
                    }}
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-indigo-500"
                  />
                </div>
              </div>

              {/* Lock Ratio */}
              <div className="flex items-center justify-between mb-3 bg-slate-50 p-2 rounded-xl border border-slate-200/70">
                <span className="text-[11px] font-medium text-slate-600">Lock Aspect Ratio</span>
                <button
                  type="button"
                  onClick={() => setQuickLockRatio((prev) => !prev)}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                    quickLockRatio
                      ? 'bg-indigo-600 text-white'
                      : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {quickLockRatio ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                  <span>{quickLockRatio ? 'Locked' : 'Unlocked'}</span>
                </button>
              </div>

              {/* Quick Preset Buttons */}
              <div className="mb-3">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                  Popular Presets
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setQuickWidth(1920);
                      setQuickHeight(1080);
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-semibold text-left transition-colors cursor-pointer"
                  >
                    1920 × 1080 (16:9 FHD)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickWidth(1366);
                      setQuickHeight(768);
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-semibold text-left transition-colors cursor-pointer"
                  >
                    1366 × 768 (Laptop)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickWidth(2560);
                      setQuickHeight(1440);
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-semibold text-left transition-colors cursor-pointer"
                  >
                    2560 × 1440 (2K QHD)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setQuickWidth(1080);
                      setQuickHeight(1080);
                    }}
                    className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-semibold text-left transition-colors cursor-pointer"
                  >
                    1080 × 1080 (Square)
                  </button>
                </div>
              </div>

              {/* Apply / Cancel */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsQuickSizeOpen(false)}
                  className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleApplyQuickSize}
                  className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1 shadow-sm transition-colors cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Apply Size</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </main>
  );
};
