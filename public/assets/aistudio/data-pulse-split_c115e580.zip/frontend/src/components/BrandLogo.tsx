import React from 'react';

interface BrandLogoProps {
  className?: string;
  size?: number;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ className = '', size = 32 }) => {
  return (
    <div className={`inline-flex items-center justify-center shrink-0 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-sm select-none"
      >
        <defs>
          {/* Main Shield Perimeter Clip */}
          <clipPath id="shieldOuterClip">
            <path d="M 12 14 C 36 8, 64 8, 90 14 C 94 38, 88 64, 50 94 C 18 78, 9 52, 10 32 Z" />
          </clipPath>
          <linearGradient id="shieldNavyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#08173E" />
            <stop offset="100%" stopColor="#0D2254" />
          </linearGradient>
          <linearGradient id="shieldSkyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#2E9BF3" />
            <stop offset="100%" stopColor="#3AA4F7" />
          </linearGradient>
        </defs>

        {/* Shield Body */}
        <g clipPath="url(#shieldOuterClip)">
          {/* Top Navy Blue Region */}
          <rect x="0" y="0" width="100" height="100" fill="url(#shieldNavyGrad)" />

          {/* Bottom Electric Sky Blue Region */}
          <path d="M -5 105 L 105 28 L 105 105 L -5 105 Z" fill="url(#shieldSkyGrad)" />

          {/* Diagonal Divider Line behind arrow */}
          <path d="M -5 100 L 95 32 L 105 32 L -5 106 Z" fill="#FFFFFF" />

          {/* 4 Vertical Circuit Data Bars */}
          {/* Bar 1 (Short - Leftmost) */}
          <line x1="28" y1="62" x2="28" y2="47" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="28" cy="46" r="4.2" fill="#08173E" stroke="#FFFFFF" strokeWidth="2.4" />

          {/* Bar 2 (Tall - Second) */}
          <line x1="40" y1="55" x2="40" y2="25" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="40" cy="24" r="4.2" fill="#08173E" stroke="#FFFFFF" strokeWidth="2.4" />

          {/* Bar 3 (Medium - Third) */}
          <line x1="52" y1="48" x2="52" y2="31" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="52" cy="30" r="4.2" fill="#08173E" stroke="#FFFFFF" strokeWidth="2.4" />

          {/* Bar 4 (Tallest - Right, near arrow head) */}
          <line x1="72" y1="36" x2="72" y2="18" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" />
          <circle cx="72" cy="17" r="4.2" fill="#08173E" stroke="#FFFFFF" strokeWidth="2.4" />
        </g>

        {/* White Diagonal Rising Arrow (Overlapping edge with arrowhead & tail notch) */}
        {/* Shaft */}
        <polygon
          points="8,82 78,35 83,43 14,88"
          fill="#FFFFFF"
        />

        {/* Arrow Head (Upper Right) */}
        <polygon
          points="70,25 94,18 84,42 77,33"
          fill="#FFFFFF"
        />

        {/* Lower Left Tail Notch (extending outward from lower left border) */}
        <polygon
          points="13,56 7,83 23,73"
          fill="#08173E"
        />
        <polygon
          points="7,83 17,77 11,88"
          fill="#FFFFFF"
        />
      </svg>
    </div>
  );
};

interface BrandLockupProps {
  size?: number;
  textSize?: string;
  className?: string;
}

export const BrandLockup: React.FC<BrandLockupProps> = ({
  size = 36,
  textSize = 'text-xl',
  className = '',
}) => {
  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`}>
      <BrandLogo size={size} />
      <span className={`font-black tracking-tight ${textSize} text-[#08173E] font-sans uppercase flex items-center gap-1`}>
        <span className="text-slate-900">DATA</span>
        <span className="text-sky-600">PULSE</span>
      </span>
    </div>
  );
};
