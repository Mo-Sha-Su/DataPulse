import React, { useState } from 'react';
import { DataFilter, Dataset, FilterOperator } from '../../types/dashboard';
import { Plus, Trash2, Check, Filter, ToggleLeft, ToggleRight, Sparkles } from 'lucide-react';

interface Props {
  filters?: DataFilter[];
  dataset?: Dataset;
  datasets?: Dataset[];
  onUpdateFilters: (filters: DataFilter[]) => void;
  isGlobal?: boolean;
}

const OPERATORS: { id: FilterOperator; label: string; symbol: string }[] = [
  { id: 'equals', label: 'Equals', symbol: '=' },
  { id: 'not_equals', label: 'Does Not Equal', symbol: '≠' },
  { id: 'contains', label: 'Contains Text', symbol: '∈' },
  { id: 'greater_than', label: 'Greater Than', symbol: '>' },
  { id: 'less_than', label: 'Less Than', symbol: '<' },
  { id: 'greater_equal', label: 'Greater or Equal', symbol: '≥' },
  { id: 'less_equal', label: 'Less or Equal', symbol: '≤' },
  { id: 'between', label: 'Between Range', symbol: '↔' },
];

export const FilterListEditor: React.FC<Props> = ({
  filters = [],
  dataset,
  datasets = [],
  onUpdateFilters,
  isGlobal = false,
}) => {
  const [selectedDatasetId, setSelectedDatasetId] = useState<string>(
    dataset?.id || datasets[0]?.id || ''
  );

  const activeDataset =
    datasets.find((d) => d.id === selectedDatasetId) || dataset || datasets[0];

  const columns = activeDataset?.columns || [];

  const [colName, setColName] = useState<string>(columns[0]?.name || '');
  const [operator, setOperator] = useState<FilterOperator>('equals');
  const [value, setValue] = useState<string>('');
  const [value2, setValue2] = useState<string>('');

  // Sample values from column for quick picking
  const getUniqueSampleValues = (columnName: string) => {
    if (!activeDataset || !columnName) return [];
    const values = activeDataset.data.map((r) => r[columnName]).filter((v) => v !== undefined && v !== null);
    const unique = Array.from(new Set(values)).slice(0, 8);
    return unique;
  };

  const sampleValues = getUniqueSampleValues(colName);

  const handleAddFilter = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!colName) return;

    const newFilter: DataFilter = {
      id: `filter_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      datasetId: isGlobal ? selectedDatasetId : undefined,
      column: colName,
      operator,
      value: value,
      value2: operator === 'between' ? value2 : undefined,
      enabled: true,
    };

    onUpdateFilters([...filters, newFilter]);
    setValue('');
    setValue2('');
  };

  const handleToggleFilter = (id: string) => {
    onUpdateFilters(
      filters.map((f) => (f.id === id ? { ...f, enabled: !(f.enabled ?? true) } : f))
    );
  };

  const handleDeleteFilter = (id: string) => {
    onUpdateFilters(filters.filter((f) => f.id !== id));
  };

  const handleClearAll = () => {
    onUpdateFilters([]);
  };

  return (
    <div className="space-y-4 text-slate-800 text-xs">
      {/* Existing Filters List */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="font-bold text-slate-700 flex items-center gap-1.5 text-xs">
            <Filter className="w-3.5 h-3.5 text-sky-600" />
            <span>Active Filters ({filters.length})</span>
          </span>
          {filters.length > 0 && (
            <button
              type="button"
              onClick={handleClearAll}
              className="text-[11px] text-rose-600 font-bold hover:underline"
            >
              Clear All
            </button>
          )}
        </div>

        {filters.length === 0 ? (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-center text-slate-500 italic">
            No filters applied. Add a filter condition below.
          </div>
        ) : (
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            {filters.map((f) => {
              const opInfo = OPERATORS.find((op) => op.id === f.operator);
              const isEnabled = f.enabled !== false;
              const dsName = datasets.find((d) => d.id === f.datasetId)?.name;

              return (
                <div
                  key={f.id}
                  className={`p-2 rounded-lg border flex items-center justify-between gap-2 transition-all ${
                    isEnabled
                      ? 'bg-sky-50/60 border-sky-200 text-slate-800'
                      : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <button
                      type="button"
                      onClick={() => handleToggleFilter(f.id)}
                      className="text-sky-600 hover:text-sky-700 shrink-0"
                      title={isEnabled ? 'Disable filter' : 'Enable filter'}
                    >
                      {isEnabled ? (
                        <ToggleRight className="w-5 h-5 text-sky-600" />
                      ) : (
                        <ToggleLeft className="w-5 h-5 text-slate-400" />
                      )}
                    </button>
                    <div className="truncate">
                      {isGlobal && dsName && (
                        <span className="text-[10px] text-slate-500 font-medium block">
                          [{dsName}]
                        </span>
                      )}
                      <span className="font-bold text-slate-900">{f.column}</span>{' '}
                      <span className="font-mono text-sky-600 font-bold">{opInfo?.symbol || f.operator}</span>{' '}
                      <span className="font-medium bg-white/80 px-1.5 py-0.5 rounded border border-slate-200">
                        {f.operator === 'between' ? `${f.value} to ${f.value2}` : String(f.value)}
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDeleteFilter(f.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors shrink-0"
                    title="Remove filter"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Add New Filter Form */}
      <form onSubmit={handleAddFilter} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
        <span className="font-bold text-slate-800 block text-xs">Add New Filter Condition</span>

        {/* Dataset selector if global */}
        {isGlobal && datasets.length > 1 && (
          <div className="space-y-1">
            <label className="text-[11px] font-semibold text-slate-600">Dataset</label>
            <select
              value={selectedDatasetId}
              onChange={(e) => {
                setSelectedDatasetId(e.target.value);
                const ds = datasets.find((d) => d.id === e.target.value);
                if (ds?.columns?.[0]) setColName(ds.columns[0].name);
              }}
              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500"
            >
              {datasets.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name} ({d.rowCount} rows)
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Column Select */}
        <div className="space-y-1">
          <label className="text-[11px] font-semibold text-slate-600">Column Field</label>
          <select
            value={colName}
            onChange={(e) => setColName(e.target.value)}
            className="w-full p-2 bg-white border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500"
          >
            {columns.map((c) => (
              <option key={c.name} value={c.name}>
                {c.name} ({c.type})
              </option>
            ))}
          </select>
        </div>

        {/* Operator Select */}
        <div className="space-y-1">
          <label className="text-[11px] font-semibold text-slate-600">Condition Operator</label>
          <select
            value={operator}
            onChange={(e) => setOperator(e.target.value as FilterOperator)}
            className="w-full p-2 bg-white border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500"
          >
            {OPERATORS.map((op) => (
              <option key={op.id} value={op.id}>
                {op.label} ({op.symbol})
              </option>
            ))}
          </select>
        </div>

        {/* Filter Value Input */}
        <div className="space-y-1">
          <label className="text-[11px] font-semibold text-slate-600">Target Filter Value</label>
          {operator === 'between' ? (
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Min value"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                className="w-1/2 p-2 bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-sky-500"
              />
              <input
                type="text"
                placeholder="Max value"
                value={value2}
                onChange={(e) => setValue2(e.target.value)}
                className="w-1/2 p-2 bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-sky-500"
              />
            </div>
          ) : (
            <input
              type="text"
              placeholder="e.g. Electronics, 500, North"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="w-full p-2 bg-white border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:border-sky-500"
            />
          )}
        </div>

        {/* Sample Values Chips for quick selection */}
        {sampleValues.length > 0 && operator !== 'between' && (
          <div className="space-y-1 pt-1">
            <span className="text-[10px] font-bold text-slate-500 block">Quick values in column:</span>
            <div className="flex flex-wrap gap-1">
              {sampleValues.map((sv, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setValue(String(sv))}
                  className="py-0.5 px-2 bg-white border border-slate-200 hover:border-sky-500 hover:text-sky-600 rounded text-[10px] font-medium transition-colors"
                >
                  {String(sv)}
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={!colName || (!value && operator !== 'between')}
          className="w-full py-2 bg-[#0284C7] hover:bg-sky-700 disabled:opacity-50 text-white font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-sm transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Apply Filter Rule</span>
        </button>
      </form>
    </div>
  );
};
