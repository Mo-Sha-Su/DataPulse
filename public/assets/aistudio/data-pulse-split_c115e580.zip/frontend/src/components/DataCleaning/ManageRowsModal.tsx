import React, { useState } from 'react';
import { X, Rows, Check } from 'lucide-react';

export type RowOperationAction =
  | 'remove_top'
  | 'remove_bottom'
  | 'remove_alternate'
  | 'remove_blank'
  | 'keep_top'
  | 'keep_bottom'
  | 'keep_range';

interface Props {
  isOpen: boolean;
  actionType: RowOperationAction;
  totalRows: number;
  onClose: () => void;
  onApply: (params: {
    action: RowOperationAction;
    count?: number;
    startRow?: number;
    numToRemove?: number;
    numToKeep?: number;
  }) => void;
}

export const ManageRowsModal: React.FC<Props> = ({
  isOpen,
  actionType,
  totalRows,
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  const [count, setCount] = useState<number>(10);
  const [startRow, setStartRow] = useState<number>(1);
  const [numToRemove, setNumToRemove] = useState<number>(1);
  const [numToKeep, setNumToKeep] = useState<number>(1);

  const getTitleAndDesc = () => {
    switch (actionType) {
      case 'remove_top':
        return {
          title: 'Remove Top Rows',
          desc: 'Specify how many rows to remove from the top of the table.',
          label: 'Number of rows to remove',
        };
      case 'remove_bottom':
        return {
          title: 'Remove Bottom Rows',
          desc: 'Specify how many rows to remove from the bottom of the table.',
          label: 'Number of rows to remove',
        };
      case 'remove_blank':
        return {
          title: 'Remove Blank Rows',
          desc: 'Remove all rows in the dataset that contain only null or empty values.',
          label: '',
        };
      case 'remove_alternate':
        return {
          title: 'Remove Alternate Rows',
          desc: 'Remove alternating patterns of rows from your dataset.',
          label: '',
        };
      case 'keep_top':
        return {
          title: 'Keep Top Rows',
          desc: 'Keep the specified number of rows from the top of the table and discard the rest.',
          label: 'Number of rows to keep',
        };
      case 'keep_bottom':
        return {
          title: 'Keep Bottom Rows',
          desc: 'Keep the specified number of rows from the bottom of the table and discard the rest.',
          label: 'Number of rows to keep',
        };
      case 'keep_range':
        return {
          title: 'Keep Range of Rows',
          desc: 'Keep a contiguous slice of rows starting from a specific row position.',
          label: '',
        };
    }
  };

  const info = getTitleAndDesc();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onApply({
      action: actionType,
      count,
      startRow,
      numToRemove,
      numToKeep,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-800">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Rows className="w-4 h-4 text-sky-600" />
            <h3 className="font-semibold text-sm text-slate-900">{info.title}</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/50">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          <p className="text-slate-600 leading-relaxed">{info.desc}</p>

          {['remove_top', 'remove_bottom', 'keep_top', 'keep_bottom'].includes(actionType) && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{info.label}</label>
              <input
                type="number"
                min={1}
                max={totalRows}
                value={count}
                onChange={(e) => setCount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                autoFocus
              />
              <span className="text-[11px] text-slate-500 mt-1 block">Total rows currently: {totalRows}</span>
            </div>
          )}

          {actionType === 'keep_range' && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Starting row index (1-based)</label>
                <input
                  type="number"
                  min={1}
                  max={totalRows}
                  value={startRow}
                  onChange={(e) => setStartRow(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Number of rows to keep</label>
                <input
                  type="number"
                  min={1}
                  max={totalRows}
                  value={count}
                  onChange={(e) => setCount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
            </div>
          )}

          {actionType === 'remove_alternate' && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">First row to remove</label>
                <input
                  type="number"
                  min={1}
                  value={startRow}
                  onChange={(e) => setStartRow(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Number of rows to remove</label>
                <input
                  type="number"
                  min={1}
                  value={numToRemove}
                  onChange={(e) => setNumToRemove(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Number of rows to keep</label>
                <input
                  type="number"
                  min={1}
                  value={numToKeep}
                  onChange={(e) => setNumToKeep(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                />
              </div>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-medium text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" /> Apply
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
