import React, { useState } from 'react';
import { X, Sliders, Check } from 'lucide-react';

export type TransformModalType =
  | 'text_prefix'
  | 'text_suffix'
  | 'text_extract_first'
  | 'text_extract_last'
  | 'text_extract_range'
  | 'text_extract_before'
  | 'text_extract_after'
  | 'number_math'
  | 'number_round'
  | 'replace_errors'
  | 'replace_nulls'
  | 'rename_step'
  | 'rename_column'
  | 'custom_column';

interface Props {
  isOpen: boolean;
  type: TransformModalType;
  column?: string;
  initialValue?: any;
  initialValue2?: any;
  availableColumns?: string[];
  onClose: () => void;
  onApply: (params: any) => void;
}

export const TransformParamModal: React.FC<Props> = ({
  isOpen,
  type,
  column = '',
  initialValue,
  initialValue2,
  availableColumns = [],
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  const [val1, setVal1] = useState<any>(initialValue ?? '');
  const [val2, setVal2] = useState<any>(initialValue2 ?? '');
  const [selectedAction, setSelectedAction] = useState<string>('replace_zero');
  const [mathOp, setMathOp] = useState<string>('+');

  const getDetails = () => {
    switch (type) {
      case 'text_prefix':
        return { title: 'Add Prefix', label: 'Prefix text to prepend', placeholder: 'e.g. ID-', default1: '' };
      case 'text_suffix':
        return { title: 'Add Suffix', label: 'Suffix text to append', placeholder: 'e.g. /year', default1: '' };
      case 'text_extract_first':
        return { title: 'Extract First Characters', label: 'Number of starting characters to keep', placeholder: '3', default1: '3' };
      case 'text_extract_last':
        return { title: 'Extract Last Characters', label: 'Number of ending characters to keep', placeholder: '4', default1: '4' };
      case 'text_extract_range':
        return { title: 'Extract Character Range', label: 'Starting position (1-based)', placeholder: '1', default1: '1' };
      case 'text_extract_before':
        return { title: 'Extract Text Before Delimiter', label: 'Delimiter', placeholder: '@ or , or space', default1: ' ' };
      case 'text_extract_after':
        return { title: 'Extract Text After Delimiter', label: 'Delimiter', placeholder: '@ or , or space', default1: ' ' };
      case 'number_math':
        return { title: `Number Operation on ${column}`, label: 'Value operand', placeholder: '1000', default1: '10' };
      case 'number_round':
        return { title: 'Round Decimals', label: 'Number of decimal places', placeholder: '2', default1: '2' };
      case 'replace_errors':
        return { title: `Replace Errors in ${column}`, label: 'Value to replace errors with', placeholder: '0 or NA', default1: '0' };
      case 'replace_nulls':
        return { title: `Replace Null / Missing in ${column}`, label: '', placeholder: '', default1: '' };
      case 'rename_step':
        return { title: 'Rename Applied Step', label: 'Step Name', placeholder: 'e.g. Cleaned Customer Names', default1: initialValue || 'Step' };
      case 'rename_column':
        return { title: 'Rename Column', label: 'New Column Name', placeholder: column, default1: initialValue || column };
      case 'custom_column':
        return { title: 'Add Custom Calculated Column', label: 'New Column Name', placeholder: 'TotalRevenue', default1: 'Calculated' };
    }
  };

  const details = getDetails();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    switch (type) {
      case 'text_prefix':
        onApply({ column, action: 'prefix', prefix: val1 });
        break;
      case 'text_suffix':
        onApply({ column, action: 'suffix', suffix: val1 });
        break;
      case 'text_extract_first':
        onApply({ column, action: 'extract_first', count: parseInt(val1, 10) || 1 });
        break;
      case 'text_extract_last':
        onApply({ column, action: 'extract_last', count: parseInt(val1, 10) || 1 });
        break;
      case 'text_extract_range':
        onApply({ column, action: 'extract_range', start: parseInt(val1, 10) || 1, length: parseInt(val2, 10) || 1 });
        break;
      case 'text_extract_before':
        onApply({ column, action: 'extract_before_delimiter', delimiter: val1 });
        break;
      case 'text_extract_after':
        onApply({ column, action: 'extract_after_delimiter', delimiter: val1 });
        break;
      case 'number_math':
        onApply({ column, action: mathOp === '+' ? 'add' : mathOp === '-' ? 'subtract' : mathOp === '*' ? 'multiply' : mathOp === '/' ? 'divide' : 'modulo', value: parseFloat(val1) || 0 });
        break;
      case 'number_round':
        onApply({ column, action: 'round', decimals: parseInt(val1, 10) || 0 });
        break;
      case 'replace_errors':
        onApply({ column, replaceValue: val1 });
        break;
      case 'replace_nulls':
        onApply({ column, action: selectedAction, customValue: val1 });
        break;
      case 'rename_step':
        onApply({ newName: val1 });
        break;
      case 'rename_column':
        onApply({ oldName: column, newName: val1 });
        break;
      case 'custom_column':
        onApply({
          newColumnName: val1,
          formulaType: 'math',
          col1: val2,
          col2: '',
          operator: mathOp,
          constantValue: parseFloat(initialValue2) || 0,
        });
        break;
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-sm bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-800">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-600" />
            <h3 className="font-semibold text-sm text-slate-900">{details.title}</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/50">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          {type === 'replace_nulls' ? (
            <div className="space-y-3">
              <label className="block text-xs font-medium text-slate-700">Choose replacement strategy</label>
              <div className="space-y-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                {[
                  { id: 'replace_zero', label: 'Replace with 0' },
                  { id: 'replace_value', label: 'Replace with custom value' },
                  { id: 'replace_avg', label: 'Replace with column Average (Mean)' },
                  { id: 'replace_median', label: 'Replace with column Median' },
                  { id: 'replace_min', label: 'Replace with column Minimum' },
                  { id: 'replace_max', label: 'Replace with column Maximum' },
                  { id: 'fill_down', label: 'Fill Down (from previous non-empty row)' },
                  { id: 'fill_up', label: 'Fill Up (from next non-empty row)' },
                ].map((item) => (
                  <label key={item.id} className="flex items-center gap-2 cursor-pointer text-slate-700 text-xs">
                    <input
                      type="radio"
                      name="nullAction"
                      value={item.id}
                      checked={selectedAction === item.id}
                      onChange={() => setSelectedAction(item.id)}
                      className="text-sky-600 focus:ring-sky-500"
                    />
                    <span>{item.label}</span>
                  </label>
                ))}
              </div>

              {selectedAction === 'replace_value' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Custom value</label>
                  <input
                    type="text"
                    value={val1}
                    onChange={(e) => setVal1(e.target.value)}
                    placeholder="e.g. Unknown or N/A"
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                    autoFocus
                  />
                </div>
              )}
            </div>
          ) : type === 'number_math' ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Operation</label>
                  <select
                    value={mathOp}
                    onChange={(e) => setMathOp(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500"
                  >
                    <option value="+">Add (+)</option>
                    <option value="-">Subtract (-)</option>
                    <option value="*">Multiply (*)</option>
                    <option value="/">Divide (/)</option>
                    <option value="%">Modulo (%)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Value</label>
                  <input
                    type="number"
                    step="any"
                    value={val1}
                    onChange={(e) => setVal1(e.target.value)}
                    placeholder="1000"
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                    autoFocus
                  />
                </div>
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">{details.label}</label>
              <input
                type={type === 'text_extract_first' || type === 'text_extract_last' || type === 'number_round' ? 'number' : 'text'}
                value={val1}
                onChange={(e) => setVal1(e.target.value)}
                placeholder={details.placeholder}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                autoFocus
              />

              {type === 'text_extract_range' && (
                <div className="mt-3">
                  <label className="block text-xs font-medium text-slate-700 mb-1">Number of characters to extract</label>
                  <input
                    type="number"
                    min={1}
                    value={val2 || '5'}
                    onChange={(e) => setVal2(e.target.value)}
                    placeholder="5"
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                  />
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-medium text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" /> OK
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
