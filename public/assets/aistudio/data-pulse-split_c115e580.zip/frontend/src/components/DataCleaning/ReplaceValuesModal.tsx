import React, { useState } from 'react';
import { X, Replace, Check, AlertCircle } from 'lucide-react';
import { isCellError } from '../../utils/transformationEngine';

interface Props {
  isOpen: boolean;
  column: string;
  sampleRows: Record<string, any>[];
  onClose: () => void;
  onApply: (params: {
    column: string;
    findValue: string;
    replaceValue: string;
    matchEntire: boolean;
  }) => void;
}

export const ReplaceValuesModal: React.FC<Props> = ({
  isOpen,
  column,
  sampleRows,
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  const [findValue, setFindValue] = useState('');
  const [replaceValue, setReplaceValue] = useState('');
  const [matchEntire, setMatchEntire] = useState(true);

  // Calculate affected count dynamically across sample
  const affectedCount = sampleRows.filter((r) => {
    const raw = r[column];
    if (isCellError(raw)) return false;
    if (raw === null || raw === undefined) {
      return findValue === '' || findValue.toLowerCase() === 'null';
    }
    const str = String(raw);
    if (matchEntire) {
      return str === findValue;
    }
    return findValue !== '' && str.includes(findValue);
  }).length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onApply({
      column,
      findValue,
      replaceValue,
      matchEntire,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-800">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Replace className="w-4 h-4 text-sky-600" />
            <h3 className="font-semibold text-sm text-slate-900">
              Replace Values in <span className="text-sky-700">{column}</span>
            </h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/50">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Value To Find</label>
            <input
              type="text"
              value={findValue}
              onChange={(e) => setFindValue(e.target.value)}
              placeholder="e.g. USA or null"
              className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
              autoFocus
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Type <code className="text-sky-700">null</code> to target empty/null values.
            </span>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Replace With</label>
            <input
              type="text"
              value={replaceValue}
              onChange={(e) => setReplaceValue(e.target.value)}
              placeholder="e.g. United States"
              className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
            />
          </div>

          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-slate-700">
              <input
                type="radio"
                name="matchRule"
                checked={matchEntire}
                onChange={() => setMatchEntire(true)}
                className="text-sky-600 focus:ring-sky-500"
              />
              <span>Match entire cell contents</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer text-slate-700">
              <input
                type="radio"
                name="matchRule"
                checked={!matchEntire}
                onChange={() => setMatchEntire(false)}
                className="text-sky-600 focus:ring-sky-500"
              />
              <span>Replace text occurrences within cell</span>
            </label>
          </div>

          {/* Dynamic Impact Status Banner */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-600">
              <AlertCircle className="w-4 h-4 text-sky-600" />
              <span>Rows affected in current view:</span>
            </div>
            <span className={`font-mono font-bold px-2 py-0.5 rounded ${
              affectedCount > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
            }`}>
              {affectedCount} {affectedCount === 1 ? 'row' : 'rows'}
            </span>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-medium text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" /> Replace Values
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
