import React, { useState } from 'react';
import { X, Columns, Check, Eye } from 'lucide-react';

interface Props {
  isOpen: boolean;
  column: string;
  sampleRows: Record<string, any>[];
  onClose: () => void;
  onApply: (params: {
    column: string;
    mode: 'delimiter' | 'characters' | 'positions';
    delimiter: string;
    at: 'leftmost' | 'rightmost' | 'every';
    numberOfColumns?: number;
    charCount?: number;
    positions?: string;
  }) => void;
}

export const SplitColumnModal: React.FC<Props> = ({
  isOpen,
  column,
  sampleRows,
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'delimiter' | 'characters' | 'positions'>('delimiter');
  const [delimiterType, setDelimiterType] = useState<'space' | 'comma' | 'semicolon' | 'colon' | 'tab' | 'custom'>('space');
  const [customDelimiter, setCustomDelimiter] = useState('');
  const [splitAt, setSplitAt] = useState<'every' | 'leftmost' | 'rightmost'>('every');
  const [charCount, setCharCount] = useState(5);
  const [positions, setPositions] = useState('0, 5, 10');

  const getEffectiveDelimiter = () => {
    switch (delimiterType) {
      case 'space': return ' ';
      case 'comma': return ',';
      case 'semicolon': return ';';
      case 'colon': return ':';
      case 'tab': return '\t';
      case 'custom': return customDelimiter || ' ';
    }
  };

  const delim = getEffectiveDelimiter();

  // Compute live preview of split
  const previewRows = sampleRows.slice(0, 5).map((row) => {
    const raw = String(row[column] ?? '');
    if (mode === 'characters') {
      return [raw.slice(0, charCount), raw.slice(charCount)];
    }
    if (mode === 'positions') {
      const posList = positions.split(',').map((p) => parseInt(p.trim(), 10)).filter((p) => !isNaN(p));
      const parts: string[] = [];
      let last = 0;
      for (const p of posList) {
        if (p > last) {
          parts.push(raw.slice(last, p));
          last = p;
        }
      }
      parts.push(raw.slice(last));
      return parts;
    }
    // Delimiter
    if (!raw.includes(delim)) return [raw];
    if (splitAt === 'leftmost') {
      const idx = raw.indexOf(delim);
      return [raw.slice(0, idx), raw.slice(idx + delim.length)];
    }
    if (splitAt === 'rightmost') {
      const idx = raw.lastIndexOf(delim);
      return [raw.slice(0, idx), raw.slice(idx + delim.length)];
    }
    return raw.split(delim);
  });

  const maxCols = Math.max(...previewRows.map((r) => r.length), 2);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onApply({
      column,
      mode,
      delimiter: delim,
      at: splitAt,
      charCount,
      positions,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-800">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Columns className="w-4 h-4 text-sky-600" />
            <h3 className="font-semibold text-sm text-slate-900">Split Column: <span className="text-sky-700">{column}</span></h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/50">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          {/* Split Mode Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">Split By</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setMode('delimiter')}
                className={`py-1.5 px-3 rounded-lg border text-xs font-medium transition-all ${
                  mode === 'delimiter'
                    ? 'border-sky-500 bg-sky-50 text-sky-800 shadow-2xs'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                Delimiter
              </button>
              <button
                type="button"
                onClick={() => setMode('characters')}
                className={`py-1.5 px-3 rounded-lg border text-xs font-medium transition-all ${
                  mode === 'characters'
                    ? 'border-sky-500 bg-sky-50 text-sky-800 shadow-2xs'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                Number of Characters
              </button>
              <button
                type="button"
                onClick={() => setMode('positions')}
                className={`py-1.5 px-3 rounded-lg border text-xs font-medium transition-all ${
                  mode === 'positions'
                    ? 'border-sky-500 bg-sky-50 text-sky-800 shadow-2xs'
                    : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                Positions
              </button>
            </div>
          </div>

          {/* Delimiter Mode Controls */}
          {mode === 'delimiter' && (
            <div className="space-y-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Select or enter delimiter</label>
                <select
                  value={delimiterType}
                  onChange={(e) => setDelimiterType(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500"
                >
                  <option value="space">Space ( )</option>
                  <option value="comma">Comma (,)</option>
                  <option value="semicolon">Semicolon (;)</option>
                  <option value="colon">Colon (:)</option>
                  <option value="tab">Tab (\t)</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              {delimiterType === 'custom' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Custom delimiter character(s)</label>
                  <input
                    type="text"
                    value={customDelimiter}
                    onChange={(e) => setCustomDelimiter(e.target.value)}
                    placeholder="e.g. - or _ or @"
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">Split at</label>
                <div className="space-y-1">
                  {[
                    { id: 'leftmost', label: 'Left-most delimiter' },
                    { id: 'rightmost', label: 'Right-most delimiter' },
                    { id: 'every', label: 'Each occurrence of the delimiter' },
                  ].map((opt) => (
                    <label key={opt.id} className="flex items-center gap-2 cursor-pointer text-slate-700">
                      <input
                        type="radio"
                        name="splitAt"
                        value={opt.id}
                        checked={splitAt === opt.id}
                        onChange={() => setSplitAt(opt.id as any)}
                        className="text-sky-600 focus:ring-sky-500"
                      />
                      <span>{opt.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Characters Mode Controls */}
          {mode === 'characters' && (
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <label className="block text-xs font-medium text-slate-700 mb-1">Number of characters</label>
              <input
                type="number"
                min={1}
                max={500}
                value={charCount}
                onChange={(e) => setCharCount(parseInt(e.target.value, 10) || 1)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>
          )}

          {/* Positions Mode Controls */}
          {mode === 'positions' && (
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
              <label className="block text-xs font-medium text-slate-700 mb-1">Positions (comma-separated indices)</label>
              <input
                type="text"
                value={positions}
                onChange={(e) => setPositions(e.target.value)}
                placeholder="e.g. 0, 5, 10"
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">Zero-based character indices where column will be split.</span>
            </div>
          )}

          {/* Live Result Preview */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="px-2.5 py-1.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between text-[11px] text-slate-600 font-medium">
              <span className="flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-sky-600" /> Live Result Preview
              </span>
              <span>Generates {maxCols} columns</span>
            </div>
            <div className="p-2 overflow-x-auto max-h-32 bg-white">
              <table className="w-full text-[11px] font-mono border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500">
                    {Array.from({ length: maxCols }).map((_, i) => (
                      <th key={i} className="text-left py-1 px-2 font-semibold">
                        {column}.{i + 1}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {previewRows.map((parts, rIdx) => (
                    <tr key={rIdx} className="hover:bg-slate-50">
                      {Array.from({ length: maxCols }).map((_, cIdx) => (
                        <td key={cIdx} className="py-1 px-2 truncate max-w-[140px] text-slate-700">
                          {parts[cIdx] || <span className="text-slate-300 italic">empty</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-medium text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Check className="w-3.5 h-3.5" /> Split Column
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
