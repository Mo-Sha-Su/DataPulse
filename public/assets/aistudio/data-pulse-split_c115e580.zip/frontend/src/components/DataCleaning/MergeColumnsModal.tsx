import React, { useState } from 'react';
import { X, Merge, Check, ArrowRight } from 'lucide-react';

interface Props {
  isOpen: boolean;
  availableColumns: string[];
  initialSelectedColumns: string[];
  sampleRows: Record<string, any>[];
  onClose: () => void;
  onApply: (params: {
    columns: string[];
    separator: string;
    customSeparator?: string;
    newColumnName: string;
    removeOriginal: boolean;
  }) => void;
}

export const MergeColumnsModal: React.FC<Props> = ({
  isOpen,
  availableColumns,
  initialSelectedColumns,
  sampleRows,
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  const [selectedCols, setSelectedCols] = useState<string[]>(
    initialSelectedColumns.length > 0 ? initialSelectedColumns : availableColumns.slice(0, 2)
  );
  const [separatorType, setSeparatorType] = useState<string>(' ');
  const [customSeparator, setCustomSeparator] = useState<string>(' - ');
  const [newColumnName, setNewColumnName] = useState<string>('Merged');
  const [removeOriginal, setRemoveOriginal] = useState<boolean>(true);

  const toggleColumn = (col: string) => {
    setSelectedCols((prev) =>
      prev.includes(col) ? prev.filter((c) => c !== col) : [...prev, col]
    );
  };

  const getEffectiveSeparator = () => {
    if (separatorType === 'custom') return customSeparator;
    return separatorType;
  };

  const effectiveSep = getEffectiveSeparator();

  // Preview merged values
  const previewRows = sampleRows.slice(0, 5).map((row) =>
    selectedCols
      .map((c) => (row[c] !== null && row[c] !== undefined ? String(row[c]) : ''))
      .filter((v) => v !== '')
      .join(effectiveSep)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCols.length < 2) return;
    onApply({
      columns: selectedCols,
      separator: separatorType,
      customSeparator,
      newColumnName: newColumnName.trim() || 'Merged',
      removeOriginal,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-lg bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-800">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Merge className="w-4 h-4 text-sky-600" />
            <h3 className="font-semibold text-sm text-slate-900">Merge Columns</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/50">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          {/* Column selector */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Select columns to merge in order ({selectedCols.length} selected)
            </label>
            <div className="max-h-36 overflow-y-auto border border-slate-200 rounded-lg p-2 space-y-1 bg-slate-50">
              {availableColumns.map((col) => {
                const isSelected = selectedCols.includes(col);
                const orderIdx = selectedCols.indexOf(col);
                return (
                  <label
                    key={col}
                    className={`flex items-center justify-between px-2.5 py-1.5 rounded-md cursor-pointer transition-colors ${
                      isSelected ? 'bg-sky-100/70 border border-sky-300 text-sky-900 font-medium' : 'hover:bg-slate-200/50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleColumn(col)}
                        className="rounded text-sky-600 focus:ring-sky-500"
                      />
                      <span>{col}</span>
                    </div>
                    {isSelected && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-sky-200 text-sky-800 font-bold">
                        #{orderIdx + 1}
                      </span>
                    )}
                  </label>
                );
              })}
            </div>
            {selectedCols.length < 2 && (
              <span className="text-[11px] text-amber-600 mt-1 block">Please select at least 2 columns to merge.</span>
            )}
          </div>

          {/* Separator choice */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Separator</label>
              <select
                value={separatorType}
                onChange={(e) => setSeparatorType(e.target.value)}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500"
              >
                <option value=" ">Space ( )</option>
                <option value=", ">Comma ( , )</option>
                <option value=" - ">Dash ( - )</option>
                <option value="; ">Semicolon ( ; )</option>
                <option value="">None (Empty)</option>
                <option value="custom">Custom Separator</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">New Column Name</label>
              <input
                type="text"
                value={newColumnName}
                onChange={(e) => setNewColumnName(e.target.value)}
                placeholder="e.g. Full Name"
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>

          {separatorType === 'custom' && (
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Custom separator string</label>
              <input
                type="text"
                value={customSeparator}
                onChange={(e) => setCustomSeparator(e.target.value)}
                placeholder="e.g. / or | or _"
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>
          )}

          <label className="flex items-center gap-2 cursor-pointer text-slate-700">
            <input
              type="checkbox"
              checked={removeOriginal}
              onChange={(e) => setRemoveOriginal(e.target.checked)}
              className="rounded text-sky-600 focus:ring-sky-500"
            />
            <span>Drop original source columns after merging</span>
          </label>

          {/* Live Preview */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="px-2.5 py-1.5 bg-slate-100 border-b border-slate-200 text-[11px] text-slate-600 font-medium flex items-center justify-between">
              <span>Preview: <span className="font-mono font-bold text-slate-800">{newColumnName || 'Merged'}</span></span>
              <span className="text-slate-400">{selectedCols.join(' + ')}</span>
            </div>
            <div className="p-2 bg-white max-h-24 overflow-y-auto space-y-1">
              {previewRows.map((val, idx) => (
                <div key={idx} className="text-[11px] font-mono py-0.5 px-2 bg-slate-50 rounded border border-slate-100 text-slate-800 truncate">
                  {val || <span className="text-slate-300 italic">empty</span>}
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-medium text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={selectedCols.length < 2}
              className={`px-4 py-1.5 rounded-lg text-white font-medium text-xs flex items-center gap-1.5 shadow-sm cursor-pointer ${
                selectedCols.length >= 2 ? 'bg-sky-600 hover:bg-sky-700' : 'bg-slate-400 cursor-not-allowed'
              }`}
            >
              <Check className="w-3.5 h-3.5" /> Merge Columns
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
