import React, { useState } from 'react';
import { X, CopyX, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  columns: string[];
  initialSelectedColumns?: string[];
  onClose: () => void;
  onApply: (selectedColumns: string[]) => void;
}

export const RemoveDuplicatesModal: React.FC<Props> = ({
  isOpen,
  columns,
  initialSelectedColumns,
  onClose,
  onApply,
}) => {
  if (!isOpen) return null;

  const [selectedCols, setSelectedCols] = useState<string[]>(
    initialSelectedColumns && initialSelectedColumns.length > 0 ? initialSelectedColumns : columns
  );

  const toggleCol = (col: string) => {
    setSelectedCols((prev) =>
      prev.includes(col) ? prev.filter((c) => c !== col) : [...prev, col]
    );
  };

  const handleSelectAll = () => setSelectedCols([...columns]);
  const handleClearAll = () => setSelectedCols([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedCols.length === 0) return;
    onApply(selectedCols);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden flex flex-col text-slate-800">
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CopyX className="w-4 h-4 text-rose-600" />
            <h3 className="font-semibold text-sm text-slate-900">Remove Duplicates</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200/50">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs">
          <p className="text-slate-600">
            Select the columns that will be used to determine duplicate rows. Rows with matching values across all selected columns will be removed, keeping only the first occurrence.
          </p>

          <div className="flex items-center justify-between">
            <span className="font-medium text-slate-700">{selectedCols.length} of {columns.length} columns selected</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleSelectAll}
                className="text-sky-600 hover:underline font-medium text-[11px]"
              >
                Select All
              </button>
              <span className="text-slate-300">·</span>
              <button
                type="button"
                onClick={handleClearAll}
                className="text-sky-600 hover:underline font-medium text-[11px]"
              >
                Clear All
              </button>
            </div>
          </div>

          <div className="max-h-56 overflow-y-auto border border-slate-200 rounded-lg p-2 space-y-1 bg-slate-50">
            {columns.map((col) => {
              const isChecked = selectedCols.includes(col);
              return (
                <label
                  key={col}
                  className={`flex items-center gap-2.5 px-2.5 py-1.5 rounded-md cursor-pointer transition-colors ${
                    isChecked ? 'bg-sky-50 text-sky-900 font-medium' : 'hover:bg-slate-200/50 text-slate-700'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    onChange={() => toggleCol(col)}
                    className="rounded text-sky-600 focus:ring-sky-500"
                  />
                  <span>{col}</span>
                </label>
              );
            })}
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 font-medium text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={selectedCols.length === 0}
              className={`px-4 py-1.5 rounded-lg text-white font-medium text-xs flex items-center gap-1.5 shadow-sm cursor-pointer ${
                selectedCols.length > 0 ? 'bg-rose-600 hover:bg-rose-700' : 'bg-slate-400 cursor-not-allowed'
              }`}
            >
              <Check className="w-3.5 h-3.5" /> Remove Duplicates
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
