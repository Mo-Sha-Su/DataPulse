import React, { useState, useRef, useEffect } from 'react';
import {
  CleaningColumn,
  ColumnDataType,
} from '../../types/dataCleaning';
import { isCellError } from '../../utils/transformationEngine';
import { typeFamily } from '../DataLab/labActions';
import { ColumnHeaderFilterDropdown } from './ColumnHeaderFilterDropdown';
import {
  Hash,
  Type,
  Calendar,
  Clock,
  CheckSquare,
  DollarSign,
  Percent,
  MoreVertical,
  ChevronDown,
  Trash2,
  Copy,
  ArrowLeft,
  ArrowRight,
  Edit2,
  Filter,
  AlertCircle,
  Replace,
  ArrowDown,
  ArrowUp,
  Columns,
} from 'lucide-react';

interface Props {
  columns: CleaningColumn[];
  rows: Record<string, any>[];
  selectedColumn: string | null;
  showQualityBar: boolean;
  onSelectColumn: (col: string) => void;
  onChangeDataType: (col: string, newType: ColumnDataType) => void;
  onRenameColumn: (oldName: string) => void;
  onRemoveColumn: (col: string) => void;
  onDuplicateColumn: (col: string) => void;
  onMoveColumn: (col: string, direction: 'left' | 'right') => void;
  onApplySort: (col: string, direction: 'asc' | 'desc') => void;
  onApplyFilter: (params: { column: string; operator: string; value?: any; value2?: any; selectedValues?: any[] }) => void;
  onOpenSplitColumn: (col: string) => void;
  onOpenReplaceValues: (col: string) => void;
  onOpenReplaceErrors: (col: string) => void;
  onFillDown: (col: string) => void;
  onFillUp: (col: string) => void;
}

const PREVIEW_ROWS = 150;

export const DataGridPreview: React.FC<Props> = ({
  columns,
  rows,
  selectedColumn,
  showQualityBar,
  onSelectColumn,
  onChangeDataType,
  onRenameColumn,
  onRemoveColumn,
  onDuplicateColumn,
  onMoveColumn,
  onApplySort,
  onApplyFilter,
  onOpenSplitColumn,
  onOpenReplaceValues,
  onOpenReplaceErrors,
  onFillDown,
  onFillUp,
}) => {
  const [activeFilterCol, setActiveFilterCol] = useState<string | null>(null);
  const [activeTypeCol, setActiveTypeCol] = useState<string | null>(null);
  const [activeMenuCol, setActiveMenuCol] = useState<string | null>(null);

  const filterContainerRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (filterContainerRef.current && !filterContainerRef.current.contains(e.target as Node)) {
        setActiveFilterCol(null);
        setActiveTypeCol(null);
        setActiveMenuCol(null);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const getTypeIcon = (type: ColumnDataType) => {
    switch (type) {
      case 'Whole Number':
        return <span className="font-mono font-bold text-xs text-sky-300">123</span>;
      case 'Decimal Number':
        return <span className="font-mono font-bold text-xs text-sky-300">1.2</span>;
      case 'Currency':
        return <DollarSign className="w-3.5 h-3.5 text-emerald-300" />;
      case 'Percentage':
        return <Percent className="w-3.5 h-3.5 text-violet-300" />;
      case 'Date':
        return <Calendar className="w-3.5 h-3.5 text-amber-300" />;
      case 'Date/Time':
        return <Calendar className="w-3.5 h-3.5 text-orange-300" />;
      case 'Time':
        return <Clock className="w-3.5 h-3.5 text-cyan-300" />;
      case 'Boolean':
        return <CheckSquare className="w-3.5 h-3.5 text-fuchsia-300" />;
      default:
        return <span className="font-mono font-bold text-[11px] text-lab-dim">ABC</span>;
    }
  };

  const DATA_TYPES: ColumnDataType[] = [
    'Text',
    'Whole Number',
    'Decimal Number',
    'Percentage',
    'Currency',
    'Date',
    'Date/Time',
    'Time',
    'Boolean',
  ];

  if (columns.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-lab-dim bg-lab-bg">
        <Columns className="w-10 h-10 text-lab-faint mb-2" />
        <h4 className="font-semibold text-lab-text text-sm">No Columns in Current View</h4>
        <p className="text-xs text-lab-faint mt-1 max-w-sm">
          The dataset or current transformation step contains no columns. You can undo or remove earlier removal steps.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-lab-bg text-lab-text select-none relative" ref={filterContainerRef}>
      {/* SPREADSHEET TABLE CONTAINER */}
      <div className="flex-1 overflow-auto lab-scroll">
        <table className="w-full border-collapse text-left font-sans text-xs">
          {/* TABLE HEADER */}
          <thead className="sticky top-0 z-10 bg-lab-panel border-b border-lab-line-strong">
            <tr>
              {/* Row Number Header Cell */}
              <th className="w-12 min-w-12 py-2 px-2 text-center font-mono font-semibold text-[11px] text-lab-faint border-r border-lab-line bg-lab-panel">
                #
              </th>

              {/* Column Headers */}
              {columns.map((col, idx) => {
                const isSelected = selectedColumn === col.name;
                const total = Math.max(1, col.validCount + col.emptyCount + col.errorCount);
                const validPct = Math.round((col.validCount / total) * 100);
                const emptyPct = Math.round((col.emptyCount / total) * 100);
                const errorPct = 100 - validPct - emptyPct;

                return (
                  <th
                    key={col.name}
                    onClick={() => onSelectColumn(col.name)}
                    className={`min-w-44 max-w-64 p-0 border-r border-lab-line transition-colors cursor-pointer group align-top ${
                      isSelected ? 'bg-pulse-400/10 ring-1 ring-pulse-400/70 ring-inset' : 'hover:bg-lab-raised'
                    }`}
                  >
                    {/* Header Top Row: Type Icon + Column Name + Filter/Menu triggers */}
                    <div className="px-2.5 py-1.5 flex items-center justify-between gap-1.5 relative">
                      <div className="flex items-center gap-1.5 truncate">
                        {/* Data Type Trigger */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveTypeCol(activeTypeCol === col.name ? null : col.name);
                              setActiveFilterCol(null);
                              setActiveMenuCol(null);
                            }}
                            className="p-1 rounded hover:bg-lab-hover flex items-center gap-0.5 cursor-pointer shrink-0"
                            title={`Data Type: ${col.dataType}. Click to change.`}
                          >
                            {getTypeIcon(col.dataType)}
                            <ChevronDown className="w-2.5 h-2.5 text-lab-faint" />
                          </button>

                          {/* Data Type Selection Dropdown */}
                          {activeTypeCol === col.name && (
                            <div className="absolute top-full left-0 mt-1 w-44 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in zoom-in-95 duration-75">
                              <span className="text-[10px] font-bold text-slate-400 px-2 py-1 uppercase tracking-wider block">
                                Change Data Type
                              </span>
                              {DATA_TYPES.map((dt) => (
                                <button
                                  key={dt}
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onChangeDataType(col.name, dt);
                                    setActiveTypeCol(null);
                                  }}
                                  className={`w-full text-left px-2 py-1.5 rounded-md flex items-center gap-2 hover:bg-slate-100 transition-colors ${
                                    col.dataType === dt ? 'bg-sky-50 text-sky-700 font-semibold' : 'text-slate-700'
                                  }`}
                                >
                                  {getTypeIcon(dt)}
                                  <span>{dt}</span>
                                </button>
                              ))}
                            </div>
                          )}
                        </div>

                        {/* Column Name */}
                        <span className="font-semibold text-lab-text truncate text-[13px]" title={col.name}>
                          {col.name}
                        </span>
                      </div>

                      {/* Header Right Actions */}
                      <div className="flex items-center gap-0.5 shrink-0">
                        {/* Filter Trigger */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveFilterCol(activeFilterCol === col.name ? null : col.name);
                              setActiveTypeCol(null);
                              setActiveMenuCol(null);
                            }}
                            className={`p-1 rounded transition-colors cursor-pointer ${
                              activeFilterCol === col.name
                                ? 'bg-sky-600 text-white'
                                : 'text-lab-faint hover:text-lab-text hover:bg-lab-hover'
                            }`}
                            title="Filter & Sort Column"
                          >
                            <Filter className="w-3.5 h-3.5" />
                          </button>

                          {/* Column Filter Dropdown */}
                          <ColumnHeaderFilterDropdown
                            column={col.name}
                            dataType={col.dataType}
                            rows={rows}
                            isOpen={activeFilterCol === col.name}
                            onClose={() => setActiveFilterCol(null)}
                            onApplySort={(dir) => onApplySort(col.name, dir)}
                            onApplyFilter={(params) => onApplyFilter(params)}
                          />
                        </div>

                        {/* Column Options Menu Trigger */}
                        <div className="relative">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveMenuCol(activeMenuCol === col.name ? null : col.name);
                              setActiveFilterCol(null);
                              setActiveTypeCol(null);
                            }}
                            className="p-1 rounded text-lab-faint hover:text-lab-text hover:bg-lab-hover cursor-pointer"
                            title="Column Operations"
                          >
                            <MoreVertical className="w-3.5 h-3.5" />
                          </button>

                          {/* Column Context Dropdown */}
                          {activeMenuCol === col.name && (
                            <div className="absolute top-full right-0 mt-1 w-48 bg-white border border-slate-200 rounded-xl shadow-xl z-50 p-1 text-xs text-slate-800 animate-in fade-in zoom-in-95 duration-75">
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onRenameColumn(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <Edit2 className="w-3.5 h-3.5 text-slate-500" />
                                <span>Rename...</span>
                              </button>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onDuplicateColumn(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <Copy className="w-3.5 h-3.5 text-slate-500" />
                                <span>Duplicate Column</span>
                              </button>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenSplitColumn(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <Columns className="w-3.5 h-3.5 text-sky-600" />
                                <span>Split Column...</span>
                              </button>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenReplaceValues(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <Replace className="w-3.5 h-3.5 text-indigo-600" />
                                <span>Replace Values...</span>
                              </button>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onOpenReplaceErrors(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                                <span>Replace Errors...</span>
                              </button>

                              <div className="my-1 border-t border-slate-100" />

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onFillDown(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <ArrowDown className="w-3.5 h-3.5 text-slate-500" />
                                <span>Fill Down</span>
                              </button>

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onFillUp(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                              >
                                <ArrowUp className="w-3.5 h-3.5 text-slate-500" />
                                <span>Fill Up</span>
                              </button>

                              <div className="my-1 border-t border-slate-100" />

                              {idx > 0 && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onMoveColumn(col.name, 'left');
                                    setActiveMenuCol(null);
                                  }}
                                  className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                                >
                                  <ArrowLeft className="w-3.5 h-3.5 text-slate-500" />
                                  <span>Move Left</span>
                                </button>
                              )}

                              {idx < columns.length - 1 && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onMoveColumn(col.name, 'right');
                                    setActiveMenuCol(null);
                                  }}
                                  className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-slate-100 text-slate-700"
                                >
                                  <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                                  <span>Move Right</span>
                                </button>
                              )}

                              <div className="my-1 border-t border-slate-100" />

                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onRemoveColumn(col.name);
                                  setActiveMenuCol(null);
                                }}
                                className="w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 hover:bg-rose-50 text-rose-600 font-medium"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                                <span>Remove Column</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Health strip: how much of this column is valid / empty / broken */}
                    {showQualityBar && (
                      <div className="px-2.5 pb-2" title={`Valid: ${col.validCount} (${validPct}%) | Empty: ${col.emptyCount} (${emptyPct}%) | Errors: ${col.errorCount} (${errorPct}%)`}>
                        <div className="h-1.5 w-full flex rounded-full overflow-hidden bg-lab-raised">
                          <div style={{ width: `${validPct}%` }} className="bg-emerald-400 h-full" />
                          <div style={{ width: `${emptyPct}%` }} className="bg-amber-400 h-full" />
                          <div style={{ width: `${errorPct}%` }} className="bg-rose-500 h-full" />
                        </div>
                        <div className="mt-1 flex justify-between font-mono text-[10px] text-lab-faint">
                          <span>{validPct}% valid</span>
                          {(col.emptyCount > 0 || col.errorCount > 0) && (
                            <span className={col.errorCount > 0 ? 'text-rose-300' : 'text-amber-300'}>
                              {col.emptyCount + col.errorCount} to fix
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>

          {/* TABLE BODY (Spreadsheet Grid) */}
          <tbody className="divide-y divide-lab-line/60 font-mono text-[12px]">
            {rows.slice(0, PREVIEW_ROWS).map((row, rIdx) => (
              <tr key={rIdx} className="even:bg-white/[0.018] hover:bg-pulse-400/[0.08] transition-colors">
                {/* Row Number Cell */}
                <td className="w-12 py-1.5 px-2 text-center text-lab-faint border-r border-lab-line bg-lab-panel/70 font-medium select-none">
                  {rIdx + 1}
                </td>

                {/* Data Cells */}
                {columns.map((col) => {
                  const val = row[col.name];
                  const isErr = isCellError(val);
                  const isNull = val === null || val === undefined || val === '';
                  const isSelected = selectedColumn === col.name;

                  return (
                    <td
                      key={col.name}
                      onClick={() => onSelectColumn(col.name)}
                      className={`py-1.5 px-2.5 border-r border-lab-line/60 truncate max-w-64 tabular-nums ${
                        typeFamily(col.dataType) === 'number' ? 'text-right' : ''
                      } ${isSelected ? 'bg-pulse-400/[0.07]' : ''}`}
                    >
                      {isErr ? (
                        <span
                          className="px-1.5 py-0.5 rounded bg-rose-500/15 text-rose-300 font-bold text-[10px] inline-flex items-center gap-1"
                          title={val.message || 'Conversion error'}
                        >
                          <AlertCircle className="w-3 h-3 text-rose-300" />
                          <span>Error</span>
                        </span>
                      ) : isNull ? (
                        <span className="text-lab-faint italic font-sans">null</span>
                      ) : typeof val === 'boolean' ? (
                        <span className={`font-semibold ${val ? 'text-emerald-300' : 'text-lab-dim'}`}>
                          {val ? 'TRUE' : 'FALSE'}
                        </span>
                      ) : (
                        <span className="text-lab-text">{String(val)}</span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length > PREVIEW_ROWS && (
          <div className="sticky left-0 px-4 py-3 text-[11px] text-lab-dim bg-lab-bg border-t border-lab-line">
            Previewing the first <b className="font-mono text-lab-text">{PREVIEW_ROWS}</b> of <b className="font-mono text-lab-text">{rows.length.toLocaleString()}</b> rows. Every step runs on all rows.
          </div>
        )}
      </div>
    </div>
  );
};
