import React, { useState, useEffect } from 'react';
import { Widget, Dataset, WidgetConfig, AggregationMethod, NumberFormatType } from '../../types/dashboard';
import { DataModelState } from '../../types/dataModel';
import { processWidgetData } from '../../utils/dataProcessor';
import { hasActiveDataModel, queryWidgetData } from '../../utils/semanticQueryEngine';
import { FilterListEditor } from '../Filters/FilterListEditor';
import {
  X,
  Sliders,
  Palette,
  Check,
  RotateCcw,
  Eye,
  Table,
  Layers,
  Sparkles,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Bold,
  Italic,
  Type,
  Filter,
  Network,
} from 'lucide-react';

interface Props {
  widget: Widget | null;
  datasets: Dataset[];
  dataModel?: DataModelState;
  onUpdateWidgetConfig: (widgetId: string, updatedConfig: WidgetConfig) => void;
  onClose: () => void;
}

const PALETTE_PRESETS = [
  ['#0284C7', '#0B1936', '#38BDF8', '#10B981', '#F59E0B'],
  ['#0B1936', '#38BDF8', '#6366F1', '#EC4899', '#10B981'],
  ['#0284C7', '#10B981', '#F59E0B', '#8B5CF6', '#F43F5E'],
  ['#38BDF8', '#0284C7', '#0B1936', '#84CC16', '#F97316'],
];

const BG_COLOR_PRESETS = [
  { name: 'Pure White', hex: '#FFFFFF' },
  { name: 'Light Slate', hex: '#F8FAFC' },
  { name: 'Soft Sky', hex: '#F0F9FF' },
  { name: 'Soft Indigo', hex: '#EEF2FF' },
  { name: 'Soft Emerald', hex: '#ECFDF5' },
  { name: 'Soft Amber', hex: '#FFFBEB' },
  { name: 'Deep Navy', hex: '#0B1936' },
  { name: 'Dark Slate', hex: '#0F172A' },
  { name: 'Dark Zinc', hex: '#18181B' },
];

const FONT_FAMILY_OPTIONS = [
  { id: 'sans', label: 'System Sans (Modern)', fontCss: 'system-ui, sans-serif' },
  { id: 'display', label: 'Plus Jakarta (Display)', fontCss: '"Plus Jakarta Sans", sans-serif' },
  { id: 'serif', label: 'Georgia (Serif)', fontCss: 'Georgia, serif' },
  { id: 'mono', label: 'Monospace (Code)', fontCss: 'monospace' },
  { id: 'cursive', label: 'Handwritten (Casual)', fontCss: 'cursive' },
];

const TITLE_COLOR_PRESETS = [
  '#0F172A', '#0284C7', '#10B981', '#F59E0B', '#FFFFFF', '#64748B', '#E11D48', '#8B5CF6'
];

export const RightConfigPanel: React.FC<Props> = ({
  widget,
  datasets,
  dataModel,
  onUpdateWidgetConfig,
  onClose,
}) => {
  if (!widget) return null;

  const [tempConfig, setTempConfig] = useState<WidgetConfig>({ ...widget.config });
  const [activeTab, setActiveTab] = useState<'mapping' | 'styling' | 'preview'>('mapping');

  useEffect(() => {
    setTempConfig({ ...widget.config });
  }, [widget]);

  const activeDataset = datasets.find((d) => d.id === tempConfig.datasetId) || datasets[0];

  const modelActive = hasActiveDataModel(dataModel);

  // A column name that exists in several model tables (e.g. a key shared by a fact and a dimension) is emitted as
  // "TABLE.Column" so the query engine binds the exact table; unique names stay bare for backward compatibility.
  const nameCounts = new Map<string, number>();
  if (modelActive && dataModel) {
    const bump = (n?: string) => n && nameCounts.set(n.toLowerCase(), (nameCounts.get(n.toLowerCase()) || 0) + 1);
    dataModel.factTables.forEach((f) => [...f.measures, ...f.foreignKeys, ...(f.attributes || [])].forEach(bump));
    dataModel.dimensionTables.forEach((d) => [d.primaryKey, ...d.attributes].forEach(bump));
  }
  const fieldValue = (table: string, col: string) =>
    (nameCounts.get(col.toLowerCase()) || 0) > 1 ? `${table}.${col}` : col;

  const renderFieldOptions = () => {
    if (modelActive && dataModel) {
      return (
        <>
          {dataModel.factTables.map((f) => (
            <optgroup key={f.id} label={`FACT: ${f.name}`}>
              {f.measures.map((m) => (
                <option key={`f_m_${f.id}_${m}`} value={fieldValue(f.name, m)}>
                  📐 {m} (Measure)
                </option>
              ))}
              {f.foreignKeys.map((k) => (
                <option key={`f_k_${f.id}_${k}`} value={fieldValue(f.name, k)}>
                  🔗 {k} (Foreign Key)
                </option>
              ))}
            </optgroup>
          ))}
          {dataModel.dimensionTables.map((d) => (
            <optgroup key={d.id} label={`DIM: ${d.name}`}>
              <option value={fieldValue(d.name, d.primaryKey)}>🔑 {d.primaryKey} (PK)</option>
              {d.attributes.map((a) => (
                <option key={`d_a_${d.id}_${a}`} value={fieldValue(d.name, a)}>
                  🏷️ {a}
                </option>
              ))}
            </optgroup>
          ))}
          {dataModel.measures && dataModel.measures.length > 0 && (
            <optgroup label="✨ CALCULATED MEASURES">
              {dataModel.measures.map((m) => (
                <option key={m.id} value={m.name}>
                  ✨ {m.name}
                </option>
              ))}
            </optgroup>
          )}
        </>
      );
    }

    return activeDataset?.columns.map((c) => (
      <option key={c.name} value={c.name}>
        {c.name} ({c.type})
      </option>
    ));
  };

  const handleApply = () => {
    onUpdateWidgetConfig(widget.id, tempConfig);
  };

  const handleReset = () => {
    setTempConfig({ ...widget.config });
  };

  // Preview with exactly what the canvas will render: through the Data Model when there is one.
  const modelPreview = modelActive
    ? queryWidgetData({ config: tempConfig, dataset: activeDataset, dataModel, datasets })
    : null;
  const sampleProcessed = modelPreview
    ? modelPreview.data
    : processWidgetData(
        activeDataset,
        tempConfig.xAxisField,
        tempConfig.yAxisField,
        tempConfig.aggregation,
        tempConfig.zAxisField,
        tempConfig.secondaryField,
        tempConfig.numberFormat,
        tempConfig.currencySymbol,
        tempConfig.filters
      );

  return (
    <aside className="w-[340px] h-full bg-white border-l border-slate-200 flex flex-col z-20 shrink-0 text-slate-800 shadow-xl select-none">
      {/* Drawer Header */}
      <div className="h-14 px-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/80">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-sky-600" />
          <span className="font-bold text-sm text-slate-900 truncate max-w-[200px]">
            Configure: {widget.title}
          </span>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-slate-800 rounded-lg hover:bg-slate-200/60 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 bg-slate-100/80 p-1 gap-1">
        <button
          onClick={() => setActiveTab('mapping')}
          className={`flex-1 py-1.5 rounded-md text-[11px] font-bold ${
            activeTab === 'mapping' ? 'bg-[#0284C7] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Data Binding
        </button>
        <button
          onClick={() => setActiveTab('styling')}
          className={`flex-1 py-1.5 rounded-md text-[11px] font-bold ${
            activeTab === 'styling' ? 'bg-[#0284C7] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Styling & Options
        </button>
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-1.5 rounded-md text-[11px] font-bold ${
            activeTab === 'preview' ? 'bg-[#0284C7] text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Sample Data
        </button>
      </div>

      {/* BODY CONTENT */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
        {/* TAB 1: DATA BINDING / TEXT CONTENT */}
        {activeTab === 'mapping' && (
          <>
            <div
              className={`flex items-start gap-2 rounded-lg border px-3 py-2 text-[11px] leading-snug ${
                modelActive
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-amber-50 border-amber-200 text-amber-800'
              }`}
            >
              <Network className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              <span>
                {modelActive
                  ? `Driven by the Data Model "${dataModel!.name}": fields are joined through its relationships, filters on dimensions reach the facts, and measures use the model's definitions.`
                  : 'No Data Model yet: this widget reads a single dataset. Attach datasets to the dashboard to build the model.'}
              </span>
            </div>
            {widget.type === 'textbox' ? (
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-sky-600" />
                    <span>Text Content</span>
                  </label>
                  <textarea
                    rows={4}
                    value={tempConfig.textContent ?? tempConfig.title ?? ''}
                    onChange={(e) =>
                      setTempConfig({
                        ...tempConfig,
                        textContent: e.target.value,
                        title: e.target.value,
                      })
                    }
                    placeholder="Enter dashboard title, heading, note, or callout..."
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 font-sans"
                  />
                </div>

                {/* Font Family Selection */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 block">Font Family / Typography</label>
                  <select
                    value={tempConfig.fontFamily || 'sans'}
                    onChange={(e) => setTempConfig({ ...tempConfig, fontFamily: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500"
                  >
                    {FONT_FAMILY_OPTIONS.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Font Size & Formatting */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label className="font-bold text-slate-700">
                      Font Size ({tempConfig.fontSize || 18}px)
                    </label>
                  </div>
                  <input
                    type="range"
                    min={12}
                    max={60}
                    step={1}
                    value={tempConfig.fontSize || 18}
                    onChange={(e) =>
                      setTempConfig({ ...tempConfig, fontSize: Number(e.target.value) })
                    }
                    className="w-full accent-sky-600 cursor-pointer"
                  />
                </div>

                {/* Formatting Toggles */}
                <div className="flex gap-2">
                  <div className="flex-1 space-y-1">
                    <label className="font-bold text-slate-700 block">Style</label>
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => setTempConfig({ ...tempConfig, isBold: !tempConfig.isBold })}
                        className={`p-2 rounded-lg border flex-1 flex items-center justify-center font-bold ${
                          tempConfig.isBold
                            ? 'bg-sky-600 text-white border-sky-600'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                        title="Bold"
                      >
                        <Bold className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setTempConfig({ ...tempConfig, isItalic: !tempConfig.isItalic })}
                        className={`p-2 rounded-lg border flex-1 flex items-center justify-center font-bold ${
                          tempConfig.isItalic
                            ? 'bg-sky-600 text-white border-sky-600'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                        title="Italic"
                      >
                        <Italic className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="flex-1 space-y-1">
                    <label className="font-bold text-slate-700 block">Alignment</label>
                    <div className="flex gap-1">
                      {(['left', 'center', 'right'] as const).map((align) => (
                        <button
                          key={align}
                          type="button"
                          onClick={() => setTempConfig({ ...tempConfig, textAlign: align })}
                          className={`p-2 rounded-lg border flex-1 flex items-center justify-center ${
                            (tempConfig.textAlign || 'left') === align
                              ? 'bg-sky-600 text-white border-sky-600'
                              : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                          title={`Align ${align}`}
                        >
                          {align === 'left' && <AlignLeft className="w-4 h-4" />}
                          {align === 'center' && <AlignCenter className="w-4 h-4" />}
                          {align === 'right' && <AlignRight className="w-4 h-4" />}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Quick Transparent Background button for text box */}
                <div className="pt-2 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() =>
                      setTempConfig({
                        ...tempConfig,
                        backgroundColor:
                          tempConfig.backgroundColor === 'transparent' ? '#FFFFFF' : 'transparent',
                      })
                    }
                    className={`w-full py-2 px-3 rounded-lg border font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                      tempConfig.backgroundColor === 'transparent'
                        ? 'bg-sky-600 text-white border-sky-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>Transparent Background</span>
                    {tempConfig.backgroundColor === 'transparent' && <Check className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Target Dataset Selection */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 block text-xs">Target Dataset</label>
                  <select
                    value={tempConfig.datasetId}
                    onChange={(e) => {
                      const newDs = datasets.find((d) => d.id === e.target.value);
                      setTempConfig({
                        ...tempConfig,
                        datasetId: e.target.value,
                        xAxisField: newDs?.columns[0]?.name || '',
                        yAxisField: newDs?.columns[1]?.name || '',
                      });
                    }}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                  >
                    {datasets.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.rowCount} rows)
                      </option>
                    ))}
                  </select>
                </div>

                {/* 1. Category / X-Axis Field (Hidden for Histogram, KPI, Gauge, Sparkline, Progress Bar) */}
                {!['histogram', 'kpi', 'gauge', 'sparkline', 'progress_bar'].includes(widget.type) && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700 block text-xs">
                      {widget.type === 'heatmap'
                        ? 'Row Field (Required)'
                        : widget.type === 'treemap'
                        ? 'Parent Category Field (Required)'
                        : widget.type === 'funnel'
                        ? 'Stage Field (Required)'
                        : ['pie'].includes(widget.type)
                        ? 'Category (Labels) Field (Required)'
                        : widget.type === 'scatter'
                        ? 'X Field (Required)'
                        : widget.type === 'target_vs_actual'
                        ? 'Actual Value Field (Required)'
                        : widget.type === 'metric'
                        ? 'Previous / Comparison Value Field (Optional)'
                        : widget.category === '3d'
                        ? 'X Field (Required)'
                        : 'Category (X-Axis) Field (Required)'}
                    </label>
                    <select
                      value={tempConfig.xAxisField}
                      onChange={(e) => setTempConfig({ ...tempConfig, xAxisField: e.target.value })}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                    >
                      <option value="">-- Select Field --</option>
                      {renderFieldOptions()}
                    </select>
                  </div>
                )}

                {/* 2. Value / Y-Axis Field */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 block text-xs">
                    {widget.type === 'heatmap'
                      ? 'Column Field (Required)'
                      : widget.type === 'treemap'
                      ? 'Child Category Field (Required)'
                      : widget.type === 'funnel'
                      ? 'Value Field (Required)'
                      : ['pie'].includes(widget.type)
                      ? 'Value Field (Required)'
                      : widget.type === 'scatter'
                      ? 'Y Field (Required)'
                      : widget.type === 'target_vs_actual'
                      ? 'Target Value Field (Required)'
                      : widget.type === 'metric'
                      ? 'Current Value Field (Required)'
                      : widget.type === 'histogram'
                      ? 'Numeric Value Column (Required)'
                      : ['kpi', 'gauge', 'sparkline', 'progress_bar'].includes(widget.type)
                      ? 'Numeric Value Field (Required)'
                      : widget.category === '3d'
                      ? 'Y Field (Required)'
                      : 'Value (Y-Axis) Field (Required)'}
                  </label>
                  <select
                    value={tempConfig.yAxisField}
                    onChange={(e) => setTempConfig({ ...tempConfig, yAxisField: e.target.value })}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                  >
                    {renderFieldOptions()}
                  </select>
                </div>

                {/* 3. Secondary / Z-Axis Field (For 3D, Heatmap, Treemap, Scatter, Bubble, Group By, Metric Card) */}
                {(widget.category === '3d' ||
                  ['heatmap', 'treemap', 'scatter', 'bubble', 'bar', 'line', 'metric'].includes(widget.type)) && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700 block text-xs">
                      {widget.category === '3d'
                        ? 'Z Field (Required)'
                        : widget.type === 'heatmap'
                        ? 'Value Field (Required)'
                        : widget.type === 'treemap'
                        ? 'Value Metric Field (Optional)'
                        : ['scatter', 'bubble'].includes(widget.type)
                        ? 'Size By Field (Optional)'
                        : widget.type === 'metric'
                        ? 'Target Value Field (Optional)'
                        : 'Group By Column (Optional)'}
                    </label>
                    <select
                      value={tempConfig.zAxisField || ''}
                      onChange={(e) =>
                        setTempConfig({
                          ...tempConfig,
                          zAxisField: e.target.value || undefined,
                        })
                      }
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                    >
                      <option value="">-- None --</option>
                      {renderFieldOptions()}
                    </select>
                  </div>
                )}

                {/* 4. Color By Field (For Scatter Plot & 3D Charts) */}
                {(widget.type === 'scatter' || widget.category === '3d') && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700 block text-xs">Color By Field (Optional)</label>
                    <select
                      value={tempConfig.secondaryField || ''}
                      onChange={(e) =>
                        setTempConfig({
                          ...tempConfig,
                          secondaryField: e.target.value || undefined,
                        })
                      }
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                    >
                      <option value="">-- None --</option>
                      {renderFieldOptions()}
                    </select>
                  </div>
                )}

                {/* 5. Aggregation Method */}
                {!['histogram', 'progress_bar', 'sparkline', 'text_box'].includes(widget.type) && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700 block text-xs">Aggregation Method</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['sum', 'avg', 'count', 'min', 'max', 'none'] as AggregationMethod[]).map(
                        (m) => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => setTempConfig({ ...tempConfig, aggregation: m })}
                            className={`py-1.5 rounded-lg font-bold uppercase text-[10px] border transition-all ${
                              tempConfig.aggregation === m
                                ? 'bg-[#0284C7] border-sky-600 text-white shadow-sm'
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            {m}
                          </button>
                        )
                      )}
                    </div>
                  </div>
                )}

                {/* 6. Widget Specific Data Options */}

                {/* Prefix & Suffix (KPI, Metric Card, Funnel, Treemap, Gauge) */}
                {['kpi', 'metric', 'funnel', 'treemap', 'gauge'].includes(widget.type) && (
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="font-bold text-slate-700 text-xs block">Prefix</label>
                      <input
                        type="text"
                        placeholder="e.g. $"
                        value={tempConfig.prefix || ''}
                        onChange={(e) => setTempConfig({ ...tempConfig, prefix: e.target.value })}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="font-bold text-slate-700 text-xs block">Suffix</label>
                      <input
                        type="text"
                        placeholder="e.g. /mo or %"
                        value={tempConfig.suffix || ''}
                        onChange={(e) => setTempConfig({ ...tempConfig, suffix: e.target.value })}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                      />
                    </div>
                  </div>
                )}

                {/* Max Value (Gauge, Progress Bar) */}
                {['gauge', 'progress_bar'].includes(widget.type) && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700 block text-xs">Maximum Target Value</label>
                    <input
                      type="number"
                      value={tempConfig.maxValue ?? 100}
                      onChange={(e) => setTempConfig({ ...tempConfig, maxValue: Number(e.target.value) })}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                    />
                  </div>
                )}

                {/* Sort Option (Bar Chart, Funnel Chart) */}
                {['bar', 'funnel'].includes(widget.type) && (
                  <div className="space-y-1.5">
                    <label className="font-bold text-slate-700 block text-xs">Sort Direction</label>
                    <select
                      value={tempConfig.sortBy || 'none'}
                      onChange={(e) => setTempConfig({ ...tempConfig, sortBy: e.target.value as any })}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                    >
                      <option value="none">Default Dataset Order</option>
                      <option value="asc">Ascending (Low to High)</option>
                      <option value="desc">Descending (High to Low)</option>
                    </select>
                  </div>
                )}

                {/* Histogram Specific Options */}
                {widget.type === 'histogram' && (
                  <div className="space-y-2 pt-1 border-t border-slate-200">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                        <span>Bins ({tempConfig.binCount || 10})</span>
                      </div>
                      <input
                        type="range"
                        min={3}
                        max={30}
                        value={tempConfig.binCount || 10}
                        onChange={(e) => setTempConfig({ ...tempConfig, binCount: Number(e.target.value) })}
                        className="w-full accent-sky-600 cursor-pointer"
                      />
                    </div>
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={!!tempConfig.density}
                          onChange={(e) => setTempConfig({ ...tempConfig, density: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-0"
                        />
                        <span>Density Mode</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={!!tempConfig.cumulative}
                          onChange={(e) => setTempConfig({ ...tempConfig, cumulative: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-0"
                        />
                        <span>Cumulative</span>
                      </label>
                    </div>
                  </div>
                )}

                {/* Display Feature Toggles in Data Binding */}
                <div className="space-y-2 pt-1 border-t border-slate-200">
                  <span className="font-bold text-slate-700 text-xs block">Specific View Options</span>

                  {/* Horizontal mode for Bar chart */}
                  {widget.type === 'bar' && (
                    <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-xs">
                      <span className="text-slate-700 font-medium">Horizontal Bar Layout</span>
                      <input
                        type="checkbox"
                        checked={!!tempConfig.horizontal}
                        onChange={(e) => setTempConfig({ ...tempConfig, horizontal: e.target.checked })}
                        className="rounded text-sky-600 focus:ring-0"
                      />
                    </label>
                  )}

                  {/* Line Chart Options */}
                  {widget.type === 'line' && (
                    <>
                      <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-xs">
                        <span className="text-slate-700 font-medium">Smooth Line Curves</span>
                        <input
                          type="checkbox"
                          checked={!!tempConfig.smoothLines}
                          onChange={(e) => setTempConfig({ ...tempConfig, smoothLines: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-0"
                        />
                      </label>
                      <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-xs">
                        <span className="text-slate-700 font-medium">Show Data Markers</span>
                        <input
                          type="checkbox"
                          checked={!!tempConfig.showMarkers}
                          onChange={(e) => setTempConfig({ ...tempConfig, showMarkers: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-0"
                        />
                      </label>
                    </>
                  )}

                  {/* Pie / Donut Chart Options */}
                  {['pie'].includes(widget.type) && (
                    <>
                      <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-xs">
                        <span className="text-slate-700 font-medium">Donut Hole Style</span>
                        <input
                          type="checkbox"
                          checked={!!tempConfig.donutStyle}
                          onChange={(e) => setTempConfig({ ...tempConfig, donutStyle: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-0"
                        />
                      </label>
                      <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-xs">
                        <span className="text-slate-700 font-medium">Show Percentage Labels</span>
                        <input
                          type="checkbox"
                          checked={!!tempConfig.showPercentages}
                          onChange={(e) => setTempConfig({ ...tempConfig, showPercentages: e.target.checked })}
                          className="rounded text-sky-600 focus:ring-0"
                        />
                      </label>
                    </>
                  )}

                  {/* Scatter Plot Trendline */}
                  {widget.type === 'scatter' && (
                    <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-xs">
                      <span className="text-slate-700 font-medium">Show Linear Trendline</span>
                      <input
                        type="checkbox"
                        checked={!!tempConfig.showTrendline}
                        onChange={(e) => setTempConfig({ ...tempConfig, showTrendline: e.target.checked })}
                        className="rounded text-sky-600 focus:ring-0"
                      />
                    </label>
                  )}
                </div>

                {/* Number Formatting */}
                <div className="space-y-1.5 pt-1 border-t border-slate-200">
                  <label className="font-bold text-slate-700 block text-xs">Number Formatting</label>
                  <select
                    value={tempConfig.numberFormat}
                    onChange={(e) =>
                      setTempConfig({
                        ...tempConfig,
                        numberFormat: e.target.value as NumberFormatType,
                      })
                    }
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500 text-xs"
                  >
                    <option value="number">Raw Standard Number</option>
                    <option value="currency">Currency ($ / € / £ / ¥)</option>
                    <option value="percentage">Percentage (%)</option>
                    <option value="compact">Compact Abbreviated (1.2M, 45.8K)</option>
                  </select>
                </div>
              </>
            )}
          </>
        )}

        {/* TAB 2: STYLING & WIDGET OPTIONS */}
        {activeTab === 'styling' && (
          <>
            {/* Widget Title */}
            <div className="space-y-1.5">
              <label className="font-bold text-slate-700">Widget Header / Label</label>
              <input
                type="text"
                value={tempConfig.title}
                onChange={(e) => setTempConfig({ ...tempConfig, title: e.target.value })}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500"
              />
            </div>

            {/* Graph / Widget Background Color */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-700 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-sky-600" />
                  <span>Graph / Widget Background Color</span>
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={tempConfig.backgroundColor === 'transparent' ? '#FFFFFF' : (tempConfig.backgroundColor || '#FFFFFF')}
                    onChange={(e) => setTempConfig({ ...tempConfig, backgroundColor: e.target.value })}
                    className="w-6 h-6 rounded cursor-pointer border border-slate-300 p-0"
                    title="Choose custom background color"
                  />
                  <span className="font-mono text-[10px] text-slate-500 uppercase">
                    {tempConfig.backgroundColor === 'transparent' ? 'Transparent' : (tempConfig.backgroundColor || '#FFFFFF')}
                  </span>
                </div>
              </div>

              {/* Transparent Background Option Button */}
              <button
                type="button"
                onClick={() =>
                  setTempConfig({
                    ...tempConfig,
                    backgroundColor:
                      tempConfig.backgroundColor === 'transparent' ? '#FFFFFF' : 'transparent',
                  })
                }
                className={`w-full py-1.5 px-3 rounded-lg border font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                  tempConfig.backgroundColor === 'transparent'
                    ? 'bg-sky-600 text-white border-sky-600 shadow-sm'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>Transparent Background</span>
                {tempConfig.backgroundColor === 'transparent' && <Check className="w-4 h-4" />}
              </button>

              {/* Background Color Swatches */}
              <div className="grid grid-cols-5 gap-1.5">
                {BG_COLOR_PRESETS.map((preset) => (
                  <button
                    key={preset.hex}
                    type="button"
                    onClick={() => setTempConfig({ ...tempConfig, backgroundColor: preset.hex })}
                    className={`h-7 rounded-md border flex items-center justify-center transition-all shadow-2xs relative ${
                      tempConfig.backgroundColor !== 'transparent' &&
                      (tempConfig.backgroundColor || '#FFFFFF').toUpperCase() === (preset.hex || '').toUpperCase()
                        ? 'ring-2 ring-sky-500 border-sky-600 scale-105'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                    style={{ backgroundColor: preset.hex }}
                    title={preset.name}
                  >
                    {tempConfig.backgroundColor !== 'transparent' &&
                      (tempConfig.backgroundColor || '#FFFFFF').toUpperCase() === (preset.hex || '').toUpperCase() && (
                      <Check
                        className={`w-3.5 h-3.5 ${
                          ['#FFFFFF', '#F8FAFC', '#F0F9FF', '#EEF2FF', '#ECFDF5', '#FFFBEB'].includes(preset.hex)
                            ? 'text-slate-900'
                            : 'text-white'
                        }`}
                      />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Typography & Font Settings */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <label className="font-bold text-slate-700 flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-sky-600" />
                <span>Typography & Text Style</span>
              </label>

              {/* Font Family */}
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-600">Font Family</label>
                <select
                  value={tempConfig.fontFamily || 'sans'}
                  onChange={(e) => setTempConfig({ ...tempConfig, fontFamily: e.target.value })}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 font-medium focus:outline-none focus:border-sky-500"
                >
                  {FONT_FAMILY_OPTIONS.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Font Size */}
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-semibold text-slate-600">
                    Font Size ({tempConfig.fontSize || (widget.type === 'textbox' ? 18 : 14)}px)
                  </label>
                </div>
                <input
                  type="range"
                  min={10}
                  max={60}
                  step={1}
                  value={tempConfig.fontSize || (widget.type === 'textbox' ? 18 : 14)}
                  onChange={(e) =>
                    setTempConfig({ ...tempConfig, fontSize: Number(e.target.value) })
                  }
                  className="w-full accent-sky-600 cursor-pointer"
                />
              </div>

              {/* Style & Alignment Toggles */}
              <div className="flex gap-2">
                <div className="flex-1 space-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 block">Weight & Style</label>
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => setTempConfig({ ...tempConfig, isBold: !tempConfig.isBold })}
                      className={`p-2 rounded-lg border flex-1 flex items-center justify-center font-bold ${
                        tempConfig.isBold
                          ? 'bg-sky-600 text-white border-sky-600'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                      title="Bold"
                    >
                      <Bold className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setTempConfig({ ...tempConfig, isItalic: !tempConfig.isItalic })}
                      className={`p-2 rounded-lg border flex-1 flex items-center justify-center font-bold ${
                        tempConfig.isItalic
                          ? 'bg-sky-600 text-white border-sky-600'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                      title="Italic"
                    >
                      <Italic className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 space-y-1">
                  <label className="text-[11px] font-semibold text-slate-600 block">Alignment</label>
                  <div className="flex gap-1">
                    {(['left', 'center', 'right'] as const).map((align) => (
                      <button
                        key={align}
                        type="button"
                        onClick={() => setTempConfig({ ...tempConfig, textAlign: align })}
                        className={`p-2 rounded-lg border flex-1 flex items-center justify-center ${
                          (tempConfig.textAlign || 'left') === align
                            ? 'bg-sky-600 text-white border-sky-600'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                        title={`Align ${align}`}
                      >
                        {align === 'left' && <AlignLeft className="w-3.5 h-3.5" />}
                        {align === 'center' && <AlignCenter className="w-3.5 h-3.5" />}
                        {align === 'right' && <AlignRight className="w-3.5 h-3.5" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Title / Text Color */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <label className="font-bold text-slate-700">Text & Title Color</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="color"
                    value={tempConfig.titleColor || '#0F172A'}
                    onChange={(e) => setTempConfig({ ...tempConfig, titleColor: e.target.value })}
                    className="w-6 h-6 rounded cursor-pointer border border-slate-300 p-0"
                    title="Choose custom title color"
                  />
                  <span className="font-mono text-[10px] text-slate-500 uppercase">{tempConfig.titleColor || '#0F172A'}</span>
                </div>
              </div>

              <div className="flex gap-1.5 flex-wrap">
                {TITLE_COLOR_PRESETS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setTempConfig({ ...tempConfig, titleColor: color })}
                    className={`w-6 h-6 rounded-full border transition-all ${
                      tempConfig.titleColor === color ? 'ring-2 ring-sky-500 scale-110' : 'border-slate-200'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {/* Color Palette Selection */}
            <div className="space-y-1.5 pt-2 border-t border-slate-200">
              <label className="font-bold text-slate-700">Data Series Palette</label>
              <div className="grid grid-cols-2 gap-2">
                {PALETTE_PRESETS.map((palette, i) => (
                  <div
                    key={i}
                    onClick={() => setTempConfig({ ...tempConfig, colorPalette: palette, primaryColor: palette[0] })}
                    className={`p-2 rounded-lg border cursor-pointer flex gap-1 items-center justify-center transition-all ${
                      tempConfig.primaryColor === palette[0]
                        ? 'border-sky-500 bg-sky-50/50 ring-1 ring-sky-500'
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    {palette.map((c, idx) => (
                      <div key={idx} className="w-3.5 h-3.5 rounded-full shadow-2xs" style={{ backgroundColor: c }} />
                    ))}
                  </div>
                ))}
              </div>
            </div>

            {/* Specific Toggles */}
            <div className="space-y-2 pt-2 border-t border-slate-200">
              <span className="font-bold text-slate-700">Display Options</span>

              <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer">
                <span className="text-slate-700 font-medium">Horizontal Bar Mode</span>
                <input
                  type="checkbox"
                  checked={!!tempConfig.horizontal}
                  onChange={(e) => setTempConfig({ ...tempConfig, horizontal: e.target.checked })}
                  className="rounded text-sky-600 focus:ring-0"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer">
                <span className="text-slate-700 font-medium">Smooth Line Curves</span>
                <input
                  type="checkbox"
                  checked={!!tempConfig.smoothLines}
                  onChange={(e) => setTempConfig({ ...tempConfig, smoothLines: e.target.checked })}
                  className="rounded text-sky-600 focus:ring-0"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer">
                <span className="text-slate-700 font-medium">Donut Hole Style</span>
                <input
                  type="checkbox"
                  checked={!!tempConfig.donutStyle}
                  onChange={(e) => setTempConfig({ ...tempConfig, donutStyle: e.target.checked })}
                  className="rounded text-sky-600 focus:ring-0"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer">
                <span className="text-slate-700 font-medium">Show Data Markers</span>
                <input
                  type="checkbox"
                  checked={!!tempConfig.showMarkers}
                  onChange={(e) => setTempConfig({ ...tempConfig, showMarkers: e.target.checked })}
                  className="rounded text-sky-600 focus:ring-0"
                />
              </label>
            </div>
          </>
        )}

        {/* TAB 3: DATA PREVIEW */}
        {activeTab === 'preview' && (
          <div className="space-y-2">
            <span className="font-bold text-slate-700">
              Aggregated Sample Output ({sampleProcessed.length} points)
            </span>
            {modelPreview?.error && sampleProcessed.length === 0 && (
              <div className="text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                {modelPreview.error}
              </div>
            )}
            <div className="max-h-64 overflow-y-auto border border-slate-200 rounded-lg bg-slate-50">
              <table className="w-full text-left text-[11px] text-slate-700">
                <thead className="bg-slate-100 sticky top-0 border-b border-slate-200 text-slate-600 font-bold">
                  <tr>
                    <th className="p-2">Category (X)</th>
                    <th className="p-2">Metric Value (Y)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {sampleProcessed.map((pt, i) => (
                    <tr key={i} className="hover:bg-slate-100/80">
                      <td className="p-2 font-mono text-indigo-600 truncate max-w-[120px]">{String(pt.x)}</td>
                      <td className="p-2 font-mono font-bold text-slate-900">{pt.formattedY}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* FOOTER ACTIONS */}
      <div className="p-3 border-t border-slate-200 bg-slate-50/80 flex gap-2">
        <button
          onClick={handleReset}
          className="py-2 px-3 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg font-semibold text-xs text-slate-700 flex items-center justify-center gap-1.5 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
        <button
          onClick={handleApply}
          className="flex-1 py-2.5 px-3 bg-gradient-to-r from-[#0B1936] to-[#0284C7] hover:from-[#0B1936] hover:to-sky-600 rounded-lg font-bold text-xs text-white flex items-center justify-center gap-1.5 shadow-md shadow-sky-600/20 transition-all border border-sky-400/20"
        >
          <Check className="w-4 h-4" />
          <span>Apply Configuration</span>
        </button>
      </div>
    </aside>
  );
};
