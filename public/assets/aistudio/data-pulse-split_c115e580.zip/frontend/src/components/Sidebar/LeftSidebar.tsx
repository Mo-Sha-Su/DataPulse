import React, { useState } from 'react';
import Papa from 'papaparse';
import { loadXLSX } from '../../utils/xlsxLazy';
import { Dataset, WidgetType, WidgetCategory } from '../../types/dashboard';
import { WIDGET_DEFINITIONS } from '../../data/widgetDefinitions';
import { BrandLogo } from '../BrandLogo';
import {
  UploadCloud,
  Database,
  BarChart3,
  TrendingUp,
  PieChart,
  Box,
  Plus,
  Table,
  Search,
  FileSpreadsheet,
  Info,
  CheckCircle2,
  Activity,
  Layers,
  Trash2,
  Sparkles,
  Network,
} from 'lucide-react';

interface Props {
  datasets: Dataset[];
  onAddDataset: (newDataset: Dataset) => void;
  onSelectDatasetToInspect: (dataset: Dataset) => void;
  onAddWidgetToCanvas: (type: WidgetType, category: WidgetCategory) => void;
  onDeleteDataset?: (datasetId: string) => void;
  onOpenDataCleaning?: (datasetId?: string) => void;
  onOpenSelectDatasets?: () => void;
  onOpenDataModel?: () => void;
}

export const LeftSidebar: React.FC<Props> = ({
  datasets,
  onAddDataset,
  onSelectDatasetToInspect,
  onAddWidgetToCanvas,
  onDeleteDataset,
  onOpenDataCleaning,
  onOpenSelectDatasets,
  onOpenDataModel,
}) => {
  const [activeTab, setActiveTab] = useState<'data' | 'widgets'>('widgets');
  const [selectedWidgetCategory, setSelectedWidgetCategory] = useState<WidgetCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  // File Upload Handler (CSV & XLSX)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const fileName = file.name;
    const isCsv = fileName.endsWith('.csv');

    if (isCsv) {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        complete: (results) => {
          if (results.data && results.data.length > 0) {
            const rawRows = results.data as Record<string, any>[];
            const sampleRow = rawRows[0] || {};
            const cols = Object.keys(sampleRow).map((key) => ({
              name: key,
              type: typeof sampleRow[key] === 'number' ? ('number' as const) : ('string' as const),
              sampleValue: sampleRow[key],
            }));

            const newDs: Dataset = {
              id: `ds_${Date.now()}`,
              name: fileName.replace(/\.[^/.]+$/, ''),
              rowCount: rawRows.length,
              columnCount: cols.length,
              columns: cols,
              data: rawRows,
              uploadedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
              sourceType: 'csv',
            };

            onAddDataset(newDs);
          }
          setIsUploading(false);
        },
      });
    } else {
      // Excel Reader using XLSX
      const reader = new FileReader();
      reader.onload = async (evt) => {
        const bstr = evt.target?.result;
        const XLSX = await loadXLSX();
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws) as Record<string, any>[];

        if (data && data.length > 0) {
          const sampleRow = data[0] || {};
          const cols = Object.keys(sampleRow).map((key) => ({
            name: key,
            type: typeof sampleRow[key] === 'number' ? ('number' as const) : ('string' as const),
            sampleValue: sampleRow[key],
          }));

          const newDs: Dataset = {
            id: `ds_${Date.now()}`,
            name: fileName.replace(/\.[^/.]+$/, ''),
            rowCount: data.length,
            columnCount: cols.length,
            columns: cols,
            data,
            uploadedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
            sourceType: 'excel',
          };

          onAddDataset(newDs);
        }
        setIsUploading(false);
      };
      reader.readAsBinaryString(file);
    }
  };

  const filteredWidgets = WIDGET_DEFINITIONS.filter((w) => {
    const matchesCat = selectedWidgetCategory === 'all' || w.category === selectedWidgetCategory;
    const matchesSearch =
      w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <aside className="w-[280px] h-full bg-white border-r border-slate-200 flex flex-col z-20 shrink-0 text-slate-800 select-none shadow-sm">
      {/* Platform Branding Header */}
      <div className="h-14 px-4 border-b border-slate-200 flex items-center justify-between bg-slate-50/90">
        <div className="flex items-center gap-2.5">
          <div className="p-1 rounded-lg bg-[#0B1936] flex items-center justify-center text-white shadow-md shadow-[#0B1936]/20 border border-sky-500/30">
            <BrandLogo size={28} />
          </div>
          <div>
            <h1 className="font-extrabold text-sm tracking-tight text-slate-900 leading-none">Data Pulse</h1>
            <span className="text-[10px] text-sky-600 font-bold tracking-wide">Intelligence in motion</span>
          </div>
        </div>
      </div>

      {/* Primary Sidebar Mode Tabs */}
      <div className="flex border-b border-slate-200 bg-slate-100/80 p-1">
        <button
          onClick={() => setActiveTab('widgets')}
          className={`flex-1 py-1.5 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'widgets'
              ? 'bg-[#0284C7] text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" />
          <span>Widgets ({WIDGET_DEFINITIONS.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('data')}
          className={`flex-1 py-1.5 rounded-md text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'data'
              ? 'bg-[#0284C7] text-white shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Data ({datasets.length})</span>
        </button>
      </div>

      {/* TAB CONTENT 1: WIDGET LIBRARY */}
      {activeTab === 'widgets' && (
        <div className="flex-1 flex flex-col overflow-hidden p-3 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search 30+ chart types..."
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-sky-500 font-medium"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex gap-1 overflow-x-auto pb-1 text-[11px]">
            <button
              onClick={() => setSelectedWidgetCategory('all')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap font-semibold ${
                selectedWidgetCategory === 'all'
                  ? 'bg-slate-800 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setSelectedWidgetCategory('charts')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap font-semibold ${
                selectedWidgetCategory === 'charts'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              Charts (8)
            </button>
            <button
              onClick={() => setSelectedWidgetCategory('analytics')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap font-semibold ${
                selectedWidgetCategory === 'analytics'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              Analytics (11)
            </button>
            <button
              onClick={() => setSelectedWidgetCategory('3d')}
              className={`px-2.5 py-1 rounded-full whitespace-nowrap font-semibold ${
                selectedWidgetCategory === '3d'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900'
              }`}
            >
              3D Graphs (11)
            </button>
          </div>

          {/* Widget List */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-2">
            {filteredWidgets.map((item) => (
              <div
                key={item.type}
                className="p-2.5 bg-slate-50 hover:bg-sky-50/50 border border-slate-200 hover:border-sky-400 rounded-xl transition-all flex items-start justify-between group cursor-pointer shadow-2xs"
                onClick={() => onAddWidgetToCanvas(item.type, item.category)}
              >
                <div className="space-y-1 pr-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-900 group-hover:text-sky-700 transition-colors">
                      {item.name}
                    </span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                        item.category === 'charts'
                          ? 'bg-sky-50 text-sky-700 border border-sky-200'
                          : item.category === 'analytics'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                      }`}
                    >
                      {item.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed font-normal">
                    {item.description}
                  </p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddWidgetToCanvas(item.type, item.category);
                  }}
                  className="p-1.5 bg-sky-50 hover:bg-sky-600 text-sky-600 hover:text-white rounded-lg transition-colors shrink-0 mt-0.5 border border-sky-200"
                  title="Add Widget to Canvas"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: DATA SOURCES */}
      {activeTab === 'data' && (
        <div className="flex-1 flex flex-col overflow-hidden p-3 gap-3">
          {/* Upload Dropzone */}
          <label className="border-2 border-dashed border-slate-300 hover:border-sky-500 bg-slate-50 hover:bg-sky-50/30 p-4 rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors text-center group">
            <UploadCloud className="w-7 h-7 text-sky-600 group-hover:scale-110 transition-transform" />
            <div>
              <span className="text-xs font-bold text-slate-800">
                {isUploading ? 'Parsing file...' : 'Upload CSV or Excel'}
              </span>
              <p className="text-[10px] text-slate-500 mt-0.5">Drag & drop or click to browse</p>
            </div>
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              className="hidden"
              onChange={handleFileUpload}
              disabled={isUploading}
            />
          </label>

          {/* Quick Explore the data Launcher Button */}
          {onOpenDataCleaning && (
            <button
              type="button"
              onClick={() => onOpenDataCleaning()}
              className="w-full py-2 px-3 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded-xl text-sky-800 font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-2xs cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-sky-600" />
              <span>Explore the data</span>
            </button>
          )}

          {/* Data Model & Dataset Selection Actions */}
          <div className="grid grid-cols-2 gap-1.5">
            {onOpenSelectDatasets && (
              <button
                type="button"
                onClick={onOpenSelectDatasets}
                className="py-1.5 px-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-700 font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                title="Select which global datasets are included"
              >
                <Database className="w-3.5 h-3.5 text-indigo-600" />
                <span>Select Data</span>
              </button>
            )}

            {onOpenDataModel && (
              <button
                type="button"
                onClick={onOpenDataModel}
                className="py-1.5 px-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl text-indigo-700 font-semibold text-[11px] flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                title="Open Star Schema Data Model Designer"
              >
                <Network className="w-3.5 h-3.5 text-indigo-600" />
                <span>Data Model</span>
              </button>
            )}
          </div>

          {/* Datasets List */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-2">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Loaded Datasets ({datasets.length})
            </span>
            {datasets.length === 0 ? (
              <div className="p-4 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-center space-y-2 my-2">
                <Database className="w-6 h-6 text-slate-400 mx-auto" />
                <p className="text-xs font-semibold text-slate-700">No datasets selected</p>
                <p className="text-[10px] text-slate-400 leading-snug">
                  Attach datasets to this dashboard to start building widgets.
                </p>
                {onOpenSelectDatasets && (
                  <button
                    type="button"
                    onClick={onOpenSelectDatasets}
                    className="w-full py-1.5 px-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-[11px] transition-colors cursor-pointer"
                  >
                    Select Datasets
                  </button>
                )}
              </div>
            ) : (
              (datasets || []).filter(Boolean).map((ds) => (
                <div
                  key={ds.id}
                  className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 hover:border-sky-400 transition-colors shadow-2xs"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xs text-slate-900 truncate max-w-[170px]">{ds.name || 'Dataset'}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-sky-100 text-sky-800 font-mono font-bold">
                      {(ds.sourceType || (ds as any)?.source_type || 'CSV').toUpperCase()}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-500 font-medium">
                    <span>{(Number(ds?.rowCount ?? (ds as any)?.row_count ?? (ds?.data?.length || 0)) || 0).toLocaleString()} rows</span>
                    <span>•</span>
                    <span>{Number(ds?.columnCount ?? (ds as any)?.column_count ?? (ds?.columns?.length || 0)) || 0} cols</span>
                  </div>

                  <div className="flex items-center gap-1.5 pt-1">
                    <button
                      onClick={() => onSelectDatasetToInspect(ds)}
                      className="flex-1 py-1 px-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-[11px] font-semibold text-slate-700 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Quick inspect"
                    >
                      <Table className="w-3 h-3 text-slate-500" />
                      <span>Inspect</span>
                    </button>

                    {onOpenDataCleaning && (
                      <button
                        onClick={() => onOpenDataCleaning(ds.id)}
                        className="flex-1 py-1 px-1.5 bg-sky-50 hover:bg-sky-100 border border-sky-300 rounded-lg text-[11px] font-semibold text-sky-800 flex items-center justify-center gap-1 transition-colors cursor-pointer"
                        title="Explore the data / Clean & Transform Editor"
                      >
                        <Sparkles className="w-3 h-3 text-sky-600" />
                        <span>Transform</span>
                      </button>
                    )}

                    {onDeleteDataset && (
                      <button
                        onClick={() => onDeleteDataset(ds.id)}
                        className="p-1 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-300 text-slate-400 hover:text-rose-600 rounded-lg transition-colors shrink-0 cursor-pointer"
                        title="Delete dataset"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </aside>
  );
};
