import { describe, expect, it } from 'vitest';
import { detectColumnType, evaluatePipeline } from './transformationEngine';
import { DataCleaningStep } from '../types/dataCleaning';

const step = (id: string, type: string, params: Record<string, any>): DataCleaningStep =>
  ({ id, name: id, type, description: '', mFormula: '', params } as DataCleaningStep);

const rows = () => [
  { region: 'North', sales: 100, city: 'A' },
  { region: 'North', sales: 100, city: 'A' },
  { region: 'South', sales: 250, city: 'B' },
  { region: null as any, sales: 40, city: 'C' },
];

describe('detectColumnType', () => {
  it('detects numbers and text', () => {
    expect(detectColumnType([1, 2, 3])).toMatch(/number/i);
    expect(detectColumnType(['a', 'b', 'c'])).toBe('Text');
  });
});

describe('evaluatePipeline', () => {
  it('returns an empty result for empty input without throwing', () => {
    const r = evaluatePipeline([], [step('s1', 'remove_duplicates', {})]);
    expect(r).toMatchObject({ rows: [], columns: [], totalRows: 0, totalColumns: 0 });
  });

  it('with no steps returns the source rows unchanged', () => {
    const r = evaluatePipeline(rows(), []);
    expect(r.totalRows).toBe(4);
    expect(r.columns.map((c) => c.name)).toEqual(['region', 'sales', 'city']);
  });

  it('removes duplicate rows', () => {
    const r = evaluatePipeline(rows(), [step('d', 'remove_duplicates', {})]);
    expect(r.totalRows).toBe(3);
  });

  it('removes duplicates by a subset of columns', () => {
    const r = evaluatePipeline(rows(), [step('d', 'remove_duplicates', { columns: ['city'] })]);
    expect(r.rows.map((x) => x.city)).toEqual(['A', 'B', 'C']);
  });

  it('renames a column in both schema and rows', () => {
    const r = evaluatePipeline(rows(), [step('r', 'rename_column', { oldName: 'sales', newName: 'revenue' })]);
    expect(r.columns.map((c) => c.name)).toContain('revenue');
    expect(r.columns.map((c) => c.name)).not.toContain('sales');
    expect(r.rows[0].revenue).toBe(100);
    expect(r.rows[0]).not.toHaveProperty('sales');
  });

  it('ignores a rename to the same name or with missing params', () => {
    const r = evaluatePipeline(rows(), [step('r', 'rename_column', { oldName: 'sales', newName: 'sales' })]);
    expect(r.columns.map((c) => c.name)).toEqual(['region', 'sales', 'city']);
  });

  it('removes columns', () => {
    const r = evaluatePipeline(rows(), [step('x', 'remove_columns', { columns: ['city', 'sales'] })]);
    expect(r.columns.map((c) => c.name)).toEqual(['region']);
    expect(Object.keys(r.rows[0])).toEqual(['region']);
  });

  it('replaces values and leaves nulls alone', () => {
    const r = evaluatePipeline(rows(), [step('v', 'replace_values', { column: 'region', findValue: 'North', replaceValue: 'N', matchEntire: true })]);
    expect(r.rows.map((x) => x.region)).toEqual(['N', 'N', 'South', null]);
  });

  it('fills down missing values', () => {
    const r = evaluatePipeline(rows(), [step('f', 'fill_down', { column: 'region' })]);
    expect(r.rows[3].region).toBe('South');
  });

  it('filters rows by a list of selected values', () => {
    const r = evaluatePipeline(rows(), [step('f', 'filter_rows', { column: 'region', selectedValues: ['South'] })]);
    expect(r.rows).toHaveLength(1);
    expect(r.rows[0].city).toBe('B');
  });

  it('does not mutate the caller\'s data', () => {
    const input = rows();
    const snapshot = JSON.stringify(input);
    evaluatePipeline(input, [
      step('a', 'rename_column', { oldName: 'sales', newName: 'x' }),
      step('b', 'remove_duplicates', {}),
      step('c', 'fill_down', { column: 'region' }),
    ]);
    expect(JSON.stringify(input)).toBe(snapshot);
  });

  it('stops at targetStepId (used for step-by-step preview)', () => {
    const steps = [step('a', 'remove_duplicates', {}), step('b', 'remove_columns', { columns: ['city'] })];
    expect(evaluatePipeline(rows(), steps, 'a').columns.map((c) => c.name)).toContain('city');
    expect(evaluatePipeline(rows(), steps, 'b').columns.map((c) => c.name)).not.toContain('city');
  });
});
