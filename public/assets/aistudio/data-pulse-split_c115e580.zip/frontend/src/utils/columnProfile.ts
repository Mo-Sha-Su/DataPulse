import { CleaningColumn, ColumnDataType, DataCleaningStepType } from '../types/dataCleaning';
import { isCellError } from './transformationEngine';

export interface ValueCount {
  value: string;
  count: number;
}

export interface NumericStats {
  min: number;
  max: number;
  mean: number;
  median: number;
}

export interface ColumnProfile {
  name: string;
  total: number;
  valid: number;
  empty: number;
  errors: number;
  distinct: number;
  /** distinct / valid, 1 means every value is unique (an identifier) */
  uniqueness: number;
  top: ValueCount[];
  numeric?: NumericStats;
  text?: { minLength: number; maxLength: number };
}

const isEmpty = (v: any) => v === null || v === undefined || v === '';

/** Profile of one column of the current step's rows. Pure; O(n). */
export function profileColumn(rows: Record<string, any>[], name: string, topN = 6): ColumnProfile {
  const counts = new Map<string, number>();
  const nums: number[] = [];
  let valid = 0;
  let empty = 0;
  let errors = 0;
  let minLen = Infinity;
  let maxLen = 0;

  for (const row of rows) {
    const v = row[name];
    if (isCellError(v)) {
      errors++;
      continue;
    }
    if (isEmpty(v)) {
      empty++;
      continue;
    }
    valid++;
    const key = String(v);
    counts.set(key, (counts.get(key) || 0) + 1);
    if (typeof v === 'number' && Number.isFinite(v)) nums.push(v);
    if (key.length < minLen) minLen = key.length;
    if (key.length > maxLen) maxLen = key.length;
  }

  const top = [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, topN)
    .map(([value, count]) => ({ value, count }));

  let numeric: NumericStats | undefined;
  if (nums.length > 0 && nums.length >= valid * 0.8) {
    const sorted = [...nums].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    numeric = {
      min: sorted[0],
      max: sorted[sorted.length - 1],
      mean: nums.reduce((a, b) => a + b, 0) / nums.length,
      median: sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2,
    };
  }

  return {
    name,
    total: rows.length,
    valid,
    empty,
    errors,
    distinct: counts.size,
    uniqueness: valid === 0 ? 0 : counts.size / valid,
    top,
    numeric,
    text: valid > 0 ? { minLength: minLen === Infinity ? 0 : minLen, maxLength: maxLen } : undefined,
  };
}

/** One-click fix that maps straight onto a pipeline step. */
export interface Suggestion {
  id: string;
  title: string;
  detail: string;
  /** how many cells/rows it would touch */
  affected: number;
  tone: 'clean' | 'shape' | 'compute';
  step: { type: DataCleaningStepType; name: string; params: Record<string, any> };
}

const NUMBER_TEXT = /^\s*-?[\d,]+(\.\d+)?\s*$/;
const DATE_TEXT = /^(\d{4}-\d{2}-\d{2}([T\s]\d{2}:\d{2}(:\d{2})?)?|\d{1,2}\/\d{1,2}\/\d{4})$/;

/**
 * Looks at the actual cell values and proposes fixes a person would otherwise hunt for by eye.
 * Every suggestion is a normal pipeline step (visible, reorderable, deletable), never a hidden change.
 */
export function suggestFixes(column: CleaningColumn, rows: Record<string, any>[]): Suggestion[] {
  const name = column.name;
  const out: Suggestion[] = [];
  const strings: string[] = [];
  let emptyCount = 0;
  for (const r of rows) {
    const v = r[name];
    if (isCellError(v)) continue;
    if (isEmpty(v)) emptyCount++;
    else if (typeof v === 'string') strings.push(v);
  }

  // 1) stray whitespace
  const padded = strings.filter((s) => s !== s.trim()).length;
  if (padded > 0) {
    out.push({
      id: `trim:${name}`,
      title: 'Trim stray spaces',
      detail: `${padded} value${padded === 1 ? '' : 's'} start or end with whitespace`,
      affected: padded,
      tone: 'clean',
      step: { type: 'text_transform', name: `Trimmed Text (${name})`, params: { column: name, action: 'trim' } },
    });
  }

  // 2) same word, different capitalisation ("Shipped" / "shipped")
  const byLower = new Map<string, Set<string>>();
  for (const s of strings) {
    const k = s.trim().toLowerCase();
    if (!byLower.has(k)) byLower.set(k, new Set());
    byLower.get(k)!.add(s.trim());
  }
  const variantGroups = [...byLower.values()].filter((set) => set.size > 1);
  if (variantGroups.length > 0) {
    const affected = strings.filter((s) => (byLower.get(s.trim().toLowerCase())?.size || 0) > 1).length;
    // Same rule as the engine's "capitalize" step; pick the action that really collapses every variant group.
    const titleCase = (v: string) => v.replace(/\b\w/g, (c) => c.toUpperCase());
    const titleUnifies = variantGroups.every((g) => new Set([...g].map(titleCase)).size === 1);
    const action = titleUnifies ? 'capitalize' : 'lowercase';
    out.push({
      id: `case:${name}`,
      title: titleUnifies ? 'Standardise capitalisation (Title Case)' : 'Standardise capitalisation (lowercase)',
      detail: `${variantGroups.length} value${variantGroups.length === 1 ? ' is' : 's are'} spelled with different casing (e.g. ${[...variantGroups[0]].slice(0, 2).map((v) => `"${v}"`).join(' / ')})`,
      affected,
      tone: 'clean',
      step: {
        type: 'text_transform',
        name: `${titleUnifies ? 'Capitalized' : 'Lowercased'} Text (${name})`,
        params: { column: name, action },
      },
    });
  }

  // 3) empty cells
  if (emptyCount > 0) {
    const numeric = ['Whole Number', 'Decimal Number', 'Currency', 'Percentage'].includes(column.dataType);
    out.push({
      id: `nulls:${name}`,
      title: numeric ? 'Fill empty cells with 0' : 'Fill empty cells with "Unknown"',
      detail: `${emptyCount} empty cell${emptyCount === 1 ? '' : 's'}`,
      affected: emptyCount,
      tone: 'clean',
      step: numeric
        ? { type: 'replace_nulls', name: `Replaced Nulls (${name})`, params: { column: name, action: 'replace_zero' } }
        : { type: 'replace_nulls', name: `Replaced Nulls (${name})`, params: { column: name, action: 'replace_value', customValue: 'Unknown' } },
    });
  }

  // 4) values that are still text although the column is (or clearly should be) numeric / a date
  const NUMERIC_TYPES: ColumnDataType[] = ['Whole Number', 'Decimal Number'];
  const sample = strings.filter((s) => s.trim() !== '');
  if (sample.length > 0) {
    const numLike = sample.filter((s) => NUMBER_TEXT.test(s)).length;
    const dateLike = sample.filter((s) => DATE_TEXT.test(s.trim())).length;
    const push = (newType: ColumnDataType, count: number, why: string) =>
      out.push({
        id: `type:${name}`,
        title: `Convert to ${newType}`,
        detail: `${count} of ${sample.length} values ${why}`,
        affected: count,
        tone: 'compute',
        step: { type: 'changed_type', name: `Changed Type (${name})`, params: { column: name, newType } },
      });

    if (column.dataType === 'Text') {
      if (numLike / sample.length >= 0.8) {
        push(sample.some((s) => s.includes('.')) ? 'Decimal Number' : 'Whole Number', numLike, 'are numbers stored as text');
      } else if (dateLike / sample.length >= 0.8) {
        push('Date', dateLike, 'look like dates stored as text');
      }
    } else if (NUMERIC_TYPES.includes(column.dataType) && numLike > 0) {
      push(column.dataType, numLike, 'are still text; the column is typed as a number but its cells are not converted yet');
    } else if (column.dataType === 'Date' && dateLike > 0) {
      push('Date', dateLike, 'are still text; the column looks like dates but its cells are not converted yet');
    }
  }

  return out;
}

/** Whole-table observations (not tied to one column). */
export function tableIssues(columns: CleaningColumn[], rows: Record<string, any>[]): Suggestion[] {
  const out: Suggestion[] = [];
  if (rows.length === 0 || columns.length === 0) return out;
  const names = columns.map((c) => c.name);

  const seen = new Set<string>();
  let dupes = 0;
  for (const r of rows) {
    const key = names.map((n) => String(r[n] ?? '')).join('\u0001');
    if (seen.has(key)) dupes++;
    else seen.add(key);
  }
  if (dupes > 0) {
    out.push({
      id: 'dupes',
      title: 'Remove duplicate rows',
      detail: `${dupes} row${dupes === 1 ? ' is' : 's are'} an exact copy of an earlier row`,
      affected: dupes,
      tone: 'shape',
      step: { type: 'remove_duplicates', name: 'Removed Duplicates', params: { columns: names } },
    });
  }

  const blank = rows.filter((r) => names.every((n) => isEmpty(r[n]))).length;
  if (blank > 0) {
    out.push({
      id: 'blank-rows',
      title: 'Remove blank rows',
      detail: `${blank} row${blank === 1 ? ' is' : 's are'} completely empty`,
      affected: blank,
      tone: 'shape',
      step: { type: 'remove_rows', name: 'Removed Blank Rows', params: { action: 'remove_blank' } },
    });
  }
  return out;
}

/** 0-100 share of cells that are valid (neither empty nor an error). */
export function qualityScore(columns: CleaningColumn[]): number {
  let valid = 0;
  let total = 0;
  for (const c of columns) {
    valid += c.validCount;
    total += c.validCount + c.emptyCount + c.errorCount;
  }
  return total === 0 ? 100 : Math.round((valid / total) * 100);
}

/** Share (0-100) of cells that are filled in, measured on a sample so large datasets stay cheap. */
export function datasetHealth(rows: Record<string, any>[], columnNames: string[], sample = 500): number {
  if (!rows?.length || !columnNames.length) return 100;
  const n = Math.min(rows.length, sample);
  const step = rows.length / n;
  let filled = 0;
  let total = 0;
  for (let i = 0; i < n; i++) {
    const row = rows[Math.floor(i * step)];
    for (const c of columnNames) {
      total++;
      const v = row?.[c];
      if (!(v === null || v === undefined || v === '')) filled++;
    }
  }
  return total === 0 ? 100 : Math.round((filled / total) * 100);
}

export function columnTypeMix(columns: { type?: string }[]): { text: number; number: number; date: number } {
  const mix = { text: 0, number: 0, date: 0 };
  for (const c of columns || []) {
    if (c.type === 'number') mix.number++;
    else if (c.type === 'date') mix.date++;
    else mix.text++;
  }
  return mix;
}
