import { DashboardState } from '../types/dashboard';
import { getAuthHeaders } from './authService';

/**
 * Dashboards live in PostgreSQL only. There is no localStorage cache or offline fallback:
 * if the database can't be reached these functions throw, so the UI can show the real state.
 */
const API_BASE = '/api/dashboards';

const SAMPLE_DASH_IDS = new Set(['dash_exec_overview', 'report_annual_summary']);

function isSampleDashboard(d: any): boolean {
  if (!d) return false;
  if (SAMPLE_DASH_IDS.has(d.id)) return true;
  const name = String(d.name || '').trim().toLowerCase();
  return (
    name.includes('executive revenue & performance suite') ||
    name.includes('annual business & financial report')
  );
}

async function failure(res: Response, what: string): Promise<Error> {
  const body = await res.json().catch(() => ({}));
  return new Error(body?.message || `${what} failed (HTTP ${res.status})`);
}

export async function fetchDashboardsFromDb(): Promise<DashboardState[]> {
  const res = await fetch(API_BASE, { headers: getAuthHeaders() });
  if (!res.ok) throw await failure(res, 'Loading dashboards');
  const data = await res.json();
  if (!data.success || !Array.isArray(data.dashboards)) throw new Error('Unexpected response while loading dashboards');
  return data.dashboards.filter((d: any) => !isSampleDashboard(d));
}

/**
 * A dashboard stores references to datasets, never their rows (those are stored once, in the datasets table).
 * Keeps metadata such as id, name and columns so the dashboard still knows what it points at.
 */
export function toDashboardPayload(dashboard: DashboardState): DashboardState {
  return {
    ...dashboard,
    datasets: (dashboard.datasets || []).map((d) => {
      const { cleanedData: _cleaned, ...meta } = d as any;
      return { ...meta, data: [] };
    }),
  };
}

export async function saveDashboardToDb(dashboard: DashboardState): Promise<DashboardState> {
  const res = await fetch(API_BASE, {
    method: 'POST',
    headers: getAuthHeaders(),
    body: JSON.stringify(toDashboardPayload(dashboard)),
  });
  if (!res.ok) throw await failure(res, 'Saving dashboard');
  const data = await res.json();
  if (!data.success || !data.dashboard) throw new Error('Unexpected response while saving dashboard');
  return data.dashboard;
}

export async function deleteDashboardFromDb(id: string): Promise<boolean> {
  const res = await fetch(`${API_BASE}/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw await failure(res, 'Deleting dashboard');
  const data = await res.json();
  return !!data.success;
}
