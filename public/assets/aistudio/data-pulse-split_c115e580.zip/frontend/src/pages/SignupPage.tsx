import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { registerUser, loginUser } from '../services/authService';
import { User } from '../types/auth';
import { BrandLockup } from '../components/BrandLogo';

interface Props {
  onLoginSuccess: (user: User) => void;
  onNavigate: (page: any, dashboardId?: string) => void;
}

export const SignupPage: React.FC<Props> = ({ onLoginSuccess, onNavigate }) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('analyst');
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Password strength score (0 to 4)
  const getPasswordStrength = (pass: string) => {
    let score = 0;
    if (pass.length >= 8) score++;
    if (/[A-Z]/.test(pass) && /[a-z]/.test(pass)) score++;
    if (/\d/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;
    return score;
  };

  const strengthScore = getPasswordStrength(password);
  const passwordsMatch = confirmPassword.length > 0 && password === confirmPassword;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!firstName.trim() || !lastName.trim()) {
      setErrorMsg('Please enter your full name');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address');
      return;
    }
    if (password.length < 8) {
      setErrorMsg('Password must be at least 8 characters');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match');
      return;
    }
    if (!termsAccepted) {
      setErrorMsg('Please agree to the Terms of Service and Privacy Policy');
      return;
    }

    setIsLoading(true);
    try {
      const res = await registerUser(
        firstName.trim(),
        lastName.trim(),
        email.trim(),
        password,
        role
      );

      if (res.success) {
        // Automatically log in the user upon registration
        const loginRes = await loginUser(email.trim(), password);
        if (loginRes.success && loginRes.user) {
          onLoginSuccess(loginRes.user);
        } else {
          onNavigate('login');
        }
      } else {
        setErrorMsg(res.detail || res.message || 'Registration failed');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error creating account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-50 via-slate-50 to-slate-100 flex items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Top Left Back Button */}
      <button
        onClick={() => onNavigate('home')}
        className="absolute top-6 left-6 z-20 flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur-md border border-slate-200 text-slate-600 hover:text-sky-600 font-semibold text-xs transition-all shadow-xs hover:shadow-md hover:-translate-x-0.5 cursor-pointer"
      >
        <span>Back to home</span>
      </button>

      <div className="w-full max-w-lg relative z-10 py-10">
        <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-8 md:p-10 shadow-2xl border border-white/80 transition-all">
          {/* Header Logo */}
          <div
            className="flex items-center justify-center mb-6 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <BrandLockup size={42} textSize="text-2xl" />
          </div>

          <div className="text-center mb-6">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight mb-1">Create Account</h2>
            <p className="text-slate-500 text-xs font-medium">Start your free trial today</p>
          </div>

          {errorMsg && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-xs font-semibold text-center animate-shake">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* First & Last Name */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">First Name *</label>
                <input
                  type="text"
                  required
                  placeholder="John"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
                />
              </div>
              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">Last Name *</label>
                <input
                  type="text"
                  required
                  placeholder="Doe"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
                />
              </div>
            </div>

            {/* Email */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">Email Address *</label>
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
              />
            </div>

            {/* Password */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">Password *</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
              />
              {password.length > 0 && (
                <div className="pt-1 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Strength:</span>
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4].map((step) => (
                      <div
                        key={step}
                        className={`w-6 h-1 rounded-full transition-all ${
                          strengthScore >= step
                            ? strengthScore <= 1
                              ? 'bg-rose-500'
                              : strengthScore === 2
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                            : 'bg-slate-200'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Confirm Password */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">Confirm Password *</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
              />
              {confirmPassword.length > 0 && (
                <div className="pt-0.5 flex items-center gap-1 text-[11px]">
                  {passwordsMatch ? (
                    <span className="text-emerald-600 font-semibold">
                      Passwords match
                    </span>
                  ) : (
                    <span className="text-rose-600 font-semibold">
                      Passwords do not match
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Role */}
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700">Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-xs font-semibold focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
              >
                <option value="analyst">Data Analyst</option>
                <option value="business_owner">Business Owner</option>
                <option value="marketing">Marketing</option>
                <option value="finance">Finance</option>
                <option value="developer">Developer</option>
                <option value="manager">Manager</option>
              </select>
            </div>

            {/* Terms Checkbox */}
            <div className="pt-1 flex items-start gap-2">
              <input
                type="checkbox"
                id="terms"
                checked={termsAccepted}
                onChange={(e) => setTermsAccepted(e.target.checked)}
                className="mt-0.5 rounded text-sky-600 focus:ring-0 cursor-pointer"
              />
              <label htmlFor="terms" className="text-xs text-slate-600 font-medium cursor-pointer">
                I agree to the <a href="#" className="text-sky-600 hover:underline font-bold">Terms of Service</a> and <a href="#" className="text-sky-600 hover:underline font-bold">Privacy Policy</a>
              </label>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-sm shadow-lg shadow-sky-600/25 transition-all hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-75 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Creating Account...</span>
                </>
              ) : (
                <span>Create Account</span>
              )}
            </button>
          </form>

          <div className="text-center mt-5 text-xs text-slate-500 font-medium">
            Already have an account?{' '}
            <button
              onClick={() => onNavigate('login')}
              className="text-sky-600 hover:text-sky-700 font-bold hover:underline cursor-pointer ml-1"
            >
              Sign In
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
