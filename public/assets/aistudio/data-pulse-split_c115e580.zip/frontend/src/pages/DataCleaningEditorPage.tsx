import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Dataset } from '../types/dashboard';
import {
  QueryModel,
  DataCleaningStep,
  ColumnDataType,
  CleaningColumn,
} from '../types/dataCleaning';
import {
  evaluatePipeline,
  generateMFormula,
  detectColumnType,
  RAW_SAMPLE_DATASET,
  isCellError,
  tracePipeline,
} from '../utils/transformationEngine';
import { DataGridPreview } from '../components/DataCleaning/DataGridPreview';
import { CommandBar } from '../components/DataLab/CommandBar';
import { CommandPalette } from '../components/DataLab/CommandPalette';
import { StepRail } from '../components/DataLab/StepRail';
import { ColumnInspector } from '../components/DataLab/ColumnInspector';
import { QueryTabs } from '../components/DataLab/QueryTabs';
import { LabStatusBar } from '../components/DataLab/LabStatusBar';
import { buildLabActions } from '../components/DataLab/labActions';
import { Suggestion, qualityScore } from '../utils/columnProfile';
import { SplitColumnModal } from '../components/DataCleaning/SplitColumnModal';
import { MergeColumnsModal } from '../components/DataCleaning/MergeColumnsModal';
import { ReplaceValuesModal } from '../components/DataCleaning/ReplaceValuesModal';
import { RemoveDuplicatesModal } from '../components/DataCleaning/RemoveDuplicatesModal';
import { ManageRowsModal, RowOperationAction } from '../components/DataCleaning/ManageRowsModal';
import { TransformParamModal, TransformModalType } from '../components/DataCleaning/TransformParamModal';
import { BrandLogo } from '../components/BrandLogo';
import Papa from 'papaparse';
import { loadXLSX } from '../utils/xlsxLazy';
import {
  Database,
  ArrowLeft,
  FileSpreadsheet,
  Plus,
  Trash2,
  Copy,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  FileText,
  Upload,
} from 'lucide-react';

interface Props {
  initialDatasets: Dataset[];
  targetDatasetId?: string;
  onApplyAndClose: (updatedDatasets: Dataset[]) => void;
  onClose: () => void;
}

export const DataCleaningEditorPage: React.FC<Props> = ({
  initialDatasets,
  targetDatasetId,
  onApplyAndClose,
  onClose,
}) => {
  // Convert initial Datasets into QueryModels with default Source & Type steps
  const [queries, setQueries] = useState<QueryModel[]>(() => {
    return initialDatasets.map((ds) => {
      const sourceStep: DataCleaningStep = {
        id: `step_source_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        name: 'Source',
        type: 'source',
        description: `Imported from ${ds.name}`,
        mFormula: `= Csv.Document(File.Contents("${ds.name}.csv"), [Delimiter=",", Columns=${ds.columnCount}])`,
        params: {},
      };

      const changedTypeStep: DataCleaningStep = {
        id: `step_type_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        name: 'Changed Type',
        type: 'changed_type',
        description: 'Auto-detected column types',
        mFormula: `= Table.TransformColumnTypes(Source, {${ds.columns.map((c) => `{"${c.name}", ${c.type === 'number' ? 'type number' : 'type text'}}`).join(', ')}})`,
        params: {
          column: ds.columns[0]?.name || '',
          newType: ds.columns[0]?.type === 'number' ? 'Whole Number' : 'Text',
        },
      };

      return {
        id: ds.id,
        name: ds.name,
        sourceType: ds.sourceType,
        originalDatasetId: ds.id,
        rawRows: ds.data && ds.data.length > 0 ? ds.data : [],
        steps: [sourceStep],
        selectedStepId: sourceStep.id,
      };
    });
  });

  // Active query selection
  const [activeQueryId, setActiveQueryId] = useState<string>(() => {
    if (targetDatasetId && queries.some((q) => q.id === targetDatasetId)) {
      return targetDatasetId;
    }
    return queries[0]?.id || '';
  });

  // Sync initialDatasets if loaded asynchronously
  useEffect(() => {
    if (initialDatasets.length > 0 && queries.length === 0) {
      const mapped = initialDatasets.map((ds) => {
        const sourceStep: DataCleaningStep = {
          id: `step_source_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          name: 'Source',
          type: 'source',
          description: `Imported from ${ds.name}`,
          mFormula: `= Csv.Document(File.Contents("${ds.name}.csv"), [Delimiter=",", Columns=${ds.columnCount}])`,
          params: {},
        };
        return {
          id: ds.id,
          name: ds.name,
          sourceType: ds.sourceType,
          originalDatasetId: ds.id,
          rawRows: ds.data && ds.data.length > 0 ? ds.data : [],
          steps: [sourceStep],
          selectedStepId: sourceStep.id,
        };
      });
      setQueries(mapped);
      if (targetDatasetId && mapped.some((q) => q.id === targetDatasetId)) {
        setActiveQueryId(targetDatasetId);
      } else if (mapped[0]) {
        setActiveQueryId(mapped[0].id);
      }
    }
  }, [initialDatasets, targetDatasetId, queries.length]);

  const activeQuery = queries.find((q) => q.id === activeQueryId) || queries[0];

  // Ribbon and View Options
  const [paletteOpen, setPaletteOpen] = useState(false);
  // the Inspector is open by default only when there is room for it next to the grid
  const [inspectorOpen, setInspectorOpen] = useState(() => (typeof window === 'undefined' ? true : window.innerWidth >= 1440));
  const [selectedColumn, setSelectedColumn] = useState<string | null>(null);

  // Modals state
  const [splitModalOpen, setSplitModalOpen] = useState(false);
  const [mergeModalOpen, setMergeModalOpen] = useState(false);
  const [replaceValuesModalOpen, setReplaceValuesModalOpen] = useState(false);
  const [removeDuplicatesModalOpen, setRemoveDuplicatesModalOpen] = useState(false);
  const [manageRowsModalState, setManageRowsModalState] = useState<{ isOpen: boolean; action: RowOperationAction }>({
    isOpen: false,
    action: 'remove_top',
  });
  const [transformParamModalState, setTransformParamModalState] = useState<{
    isOpen: boolean;
    type: TransformModalType;
    column?: string;
    initialValue?: any;
    initialValue2?: any;
    availableColumns?: string[];
  }>({
    isOpen: false,
    type: 'text_prefix',
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Compute evaluation result of current query pipeline up to activeQuery.selectedStepId
  const currentEvaluation = useMemo(() => {
    if (!activeQuery) {
      return {
        columns: [],
        rows: [],
        totalErrors: 0,
        totalEmpty: 0,
        totalRows: 0,
        totalColumns: 0,
      };
    }
    return evaluatePipeline(activeQuery.rawRows, activeQuery.steps, activeQuery.selectedStepId);
  }, [activeQuery?.rawRows, activeQuery?.steps, activeQuery?.selectedStepId]);

  // Current selected step formula
  const currentStep = activeQuery?.steps.find((s) => s.id === activeQuery.selectedStepId) || activeQuery?.steps[0];
  const activeFormula = currentStep ? currentStep.mFormula : '= Source';

  // Helper to add a new step into the active query pipeline
  const addStepToActiveQuery = (
    type: DataCleaningStep['type'],
    name: string,
    params: Record<string, any>,
    description = ''
  ) => {
    if (!activeQuery) return;

    const newStepId = `step_${type}_${Date.now()}`;
    const prevStep = activeQuery.steps[activeQuery.steps.length - 1];
    const prevName = prevStep ? prevStep.name : 'Source';

    const tempStep: DataCleaningStep = {
      id: newStepId,
      name,
      type,
      description,
      mFormula: '',
      params,
    };
    tempStep.mFormula = generateMFormula(tempStep, prevName);

    // If user is time-travelled to an earlier step, insert after that step or append
    const currentStepIndex = activeQuery.steps.findIndex((s) => s.id === activeQuery.selectedStepId);
    let updatedSteps: DataCleaningStep[];

    if (currentStepIndex >= 0 && currentStepIndex < activeQuery.steps.length - 1) {
      updatedSteps = [
        ...activeQuery.steps.slice(0, currentStepIndex + 1),
        tempStep,
        ...activeQuery.steps.slice(currentStepIndex + 1),
      ];
    } else {
      updatedSteps = [...activeQuery.steps, tempStep];
    }

    setQueries((prev) =>
      prev.map((q) =>
        q.id === activeQuery.id
          ? {
              ...q,
              steps: updatedSteps,
              selectedStepId: newStepId,
            }
          : q
      )
    );
  };

  // Step Operations in Applied Steps Sidebar
  const handleSelectStep = (stepId: string) => {
    setQueries((prev) =>
      prev.map((q) => (q.id === activeQuery.id ? { ...q, selectedStepId: stepId } : q))
    );
  };

  const handleDeleteStep = (stepId: string) => {
    if (!activeQuery || activeQuery.steps.length <= 1) return;
    const remaining = activeQuery.steps.filter((s) => s.id !== stepId);
    const nextSelectedId = remaining[remaining.length - 1]?.id || remaining[0].id;

    setQueries((prev) =>
      prev.map((q) =>
        q.id === activeQuery.id
          ? {
              ...q,
              steps: remaining,
              selectedStepId: nextSelectedId,
            }
          : q
      )
    );
  };

  const handleRenameStep = (stepId: string) => {
    const target = activeQuery?.steps.find((s) => s.id === stepId);
    if (!target) return;
    setTransformParamModalState({
      isOpen: true,
      type: 'rename_step',
      initialValue: target.name,
    });
  };

  const handleMoveStepUp = (stepId: string) => {
    if (!activeQuery) return;
    const idx = activeQuery.steps.findIndex((s) => s.id === stepId);
    if (idx <= 1) return; // Don't move before Source
    const newSteps = [...activeQuery.steps];
    const item = newSteps.splice(idx, 1)[0];
    newSteps.splice(idx - 1, 0, item);

    setQueries((prev) =>
      prev.map((q) => (q.id === activeQuery.id ? { ...q, steps: newSteps } : q))
    );
  };

  const handleMoveStepDown = (stepId: string) => {
    if (!activeQuery) return;
    const idx = activeQuery.steps.findIndex((s) => s.id === stepId);
    if (idx === -1 || idx === 0 || idx >= activeQuery.steps.length - 1) return;
    const newSteps = [...activeQuery.steps];
    const item = newSteps.splice(idx, 1)[0];
    newSteps.splice(idx + 1, 0, item);

    setQueries((prev) =>
      prev.map((q) => (q.id === activeQuery.id ? { ...q, steps: newSteps } : q))
    );
  };

  const handleEditStepSettings = (step: DataCleaningStep) => {
    switch (step.type) {
      case 'replace_values':
        setReplaceValuesModalOpen(true);
        break;
      case 'split_column':
        setSplitModalOpen(true);
        break;
      case 'merge_columns':
        setMergeModalOpen(true);
        break;
      case 'remove_duplicates':
        setRemoveDuplicatesModalOpen(true);
        break;
      case 'rename_column':
        setTransformParamModalState({
          isOpen: true,
          type: 'rename_column',
          column: step.params.oldName,
          initialValue: step.params.newName,
        });
        break;
      default:
        break;
    }
  };

  const handleQueryNameChange = (newName: string) => {
    setQueries((prev) =>
      prev.map((q) => (q.id === activeQuery.id ? { ...q, name: newName } : q))
    );
  };

  // Column Actions
  const handleChangeDataType = (column: string, newType: ColumnDataType) => {
    addStepToActiveQuery('changed_type', `Changed Type (${column})`, { column, newType });
  };

  const handleRenameColumn = (oldName: string) => {
    setTransformParamModalState({
      isOpen: true,
      type: 'rename_column',
      column: oldName,
      initialValue: oldName,
    });
  };

  const handleRemoveColumn = (column?: string) => {
    const target = column || selectedColumn;
    if (!target) return;
    addStepToActiveQuery('remove_columns', `Removed Column (${target})`, { column: target });
    setSelectedColumn(null);
  };

  const handleDuplicateColumn = (column?: string) => {
    const target = column || selectedColumn;
    if (!target) return;
    const newName = `${target} - Copy`;
    addStepToActiveQuery('duplicate_column', `Duplicated Column (${target})`, { column: target, newColumnName: newName });
  };

  const handleMoveColumn = (column: string, direction: 'left' | 'right') => {
    addStepToActiveQuery('move_column', `Reordered Column (${column})`, { column, direction });
  };

  const handleApplySort = (column: string, direction: 'asc' | 'desc') => {
    addStepToActiveQuery('sort', `Sorted Rows (${column} ${direction.toUpperCase()})`, {
      column,
      direction,
    });
  };

  const handleApplyFilter = (params: { column: string; operator: string; value?: any; value2?: any; selectedValues?: any[] }) => {
    addStepToActiveQuery('filter_rows', `Filtered Rows (${params.column})`, params);
  };

  const handleFillDown = (column?: string) => {
    const target = column || selectedColumn;
    if (!target) return;
    addStepToActiveQuery('fill_down', `Filled Down (${target})`, { column: target });
  };

  const handleFillUp = (column?: string) => {
    const target = column || selectedColumn;
    if (!target) return;
    addStepToActiveQuery('fill_up', `Filled Up (${target})`, { column: target });
  };

  // Text Transform Trigger
  const handleTextTransform = (action: string) => {
    if (!selectedColumn) return;
    if (['prefix', 'suffix', 'extract_first', 'extract_last', 'extract_range', 'extract_before_delimiter', 'extract_after_delimiter'].includes(action)) {
      setTransformParamModalState({
        isOpen: true,
        type: `text_${action}` as any,
        column: selectedColumn,
      });
    } else {
      addStepToActiveQuery('text_transform', `${action.charAt(0).toUpperCase() + action.slice(1)} Text (${selectedColumn})`, {
        column: selectedColumn,
        action,
      });
    }
  };

  // Number Transform Trigger
  const handleNumberTransform = (action: string) => {
    if (!selectedColumn) return;
    if (['math', 'round'].includes(action)) {
      setTransformParamModalState({
        isOpen: true,
        type: `number_${action}` as any,
        column: selectedColumn,
      });
    } else {
      addStepToActiveQuery('number_transform', `${action.toUpperCase()} (${selectedColumn})`, {
        column: selectedColumn,
        action,
      });
    }
  };

  // Date Transform Trigger
  const handleDateTransform = (action: string) => {
    if (!selectedColumn) return;
    addStepToActiveQuery('date_transform', `Extracted ${action} (${selectedColumn})`, {
      column: selectedColumn,
      action,
    });
  };

  // Load Dirty Sample Dataset to test out of the box
  const handleLoadDirtySample = () => {
    const newId = `ds_raw_leads_${Date.now()}`;
    const rawQuery: QueryModel = {
      id: newId,
      name: 'Customer Leads (Dirty Data)',
      sourceType: 'sample',
      rawRows: RAW_SAMPLE_DATASET,
      steps: [
        {
          id: `step_source_${Date.now()}`,
          name: 'Source',
          type: 'source',
          description: 'Loaded uncleaned sample leads data',
          mFormula: '= Csv.Document(File.Contents("raw_leads.csv"))',
          params: {},
        },
      ],
      selectedStepId: `step_source_${Date.now()}`,
    };
    setQueries((prev) => [rawQuery, ...prev]);
    setActiveQueryId(newId);
    setSelectedColumn(null);
  };

  // File Upload inside Editor
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name;
    const isCsv = fileName.endsWith('.csv');

    if (isCsv) {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        complete: (results) => {
          if (results.data && results.data.length > 0) {
            const rawRows = results.data as Record<string, any>[];
            const newId = `ds_query_${Date.now()}`;
            const newQuery: QueryModel = {
              id: newId,
              name: fileName.replace(/\.[^/.]+$/, ''),
              sourceType: 'csv',
              rawRows,
              steps: [
                {
                  id: `step_source_${Date.now()}`,
                  name: 'Source',
                  type: 'source',
                  description: `Loaded from ${fileName}`,
                  mFormula: `= Csv.Document(File.Contents("${fileName}"), [Delimiter=","])`,
                  params: {},
                },
              ],
              selectedStepId: `step_source_${Date.now()}`,
            };
            setQueries((prev) => [newQuery, ...prev]);
            setActiveQueryId(newId);
          }
        },
      });
    } else {
      const reader = new FileReader();
      reader.onload = async (evt) => {
        const bstr = evt.target?.result;
        const XLSX = await loadXLSX();
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws) as Record<string, any>[];
        if (data && data.length > 0) {
          const newId = `ds_query_${Date.now()}`;
          const newQuery: QueryModel = {
            id: newId,
            name: fileName.replace(/\.[^/.]+$/, ''),
            sourceType: 'excel',
            rawRows: data,
            steps: [
              {
                id: `step_source_${Date.now()}`,
                name: 'Source',
                type: 'source',
                description: `Loaded from ${fileName}`,
                mFormula: `= Excel.Workbook(File.Contents("${fileName}"))`,
                params: {},
              },
            ],
            selectedStepId: `step_source_${Date.now()}`,
          };
          setQueries((prev) => [newQuery, ...prev]);
          setActiveQueryId(newId);
        }
      };
      reader.readAsBinaryString(file);
    }
  };

  // CLOSE & APPLY: Convert all queries back to Dataset format and commit
  const handleCommitCloseAndApply = () => {
    const updatedDatasets: Dataset[] = queries.map((q) => {
      // Evaluate each query up to its last step
      const finalEval = evaluatePipeline(q.rawRows, q.steps, q.steps[q.steps.length - 1]?.id);

      // Sanitize rows so no CellError objects break charts
      const sanitizedRows = finalEval.rows.map((row) => {
        const cleanRow: Record<string, any> = {};
        for (const [k, v] of Object.entries(row)) {
          if (isCellError(v)) {
            cleanRow[k] = null;
          } else {
            cleanRow[k] = v;
          }
        }
        return cleanRow;
      });

      const cols = finalEval.columns.map((col) => {
        const isNum = ['Whole Number', 'Decimal Number', 'Percentage', 'Currency'].includes(col.dataType);
        const isDt = ['Date', 'Date/Time', 'Time'].includes(col.dataType);
        return {
          name: col.name,
          type: isNum ? ('number' as const) : isDt ? ('date' as const) : ('string' as const),
          sampleValue: sanitizedRows[0]?.[col.name] ?? null,
        };
      });

      return {
        id: q.originalDatasetId || q.id,
        name: q.name,
        rowCount: sanitizedRows.length,
        columnCount: cols.length,
        columns: cols,
        data: sanitizedRows,
        uploadedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
        sourceType: q.sourceType,
        // Cleaning log: earlier sessions plus the steps performed now (the data itself is stored already cleaned).
        cleaningPipeline: (() => {
          const prior = initialDatasets.find((d) => d.id === (q.originalDatasetId || q.id))?.cleaningPipeline || [];
          const session = q.steps
            .filter((st) => st.type !== 'source')
            .map(({ id, name, type, description, params }) => ({ id, name, type, description, params }));
          return session.length > 0 ? [...prior, ...session] : prior;
        })(),
      };
    });

    onApplyAndClose(updatedDatasets);
  };

  const selectedColObj = currentEvaluation.columns.find((c) => c.name === selectedColumn);

  // What each step did to the data, computed in a single pass over the pipeline.
  const trace = useMemo(
    () => (activeQuery ? tracePipeline(activeQuery.rawRows, activeQuery.steps) : []),
    [activeQuery?.rawRows, activeQuery?.steps]
  );
  const health = useMemo(() => qualityScore(currentEvaluation.columns), [currentEvaluation.columns]);
  const selectedStepIndex = Math.max(0, activeQuery?.steps.findIndex((s) => s.id === activeQuery.selectedStepId) ?? 0);

  const labActions = buildLabActions({
    newSource: () => fileInputRef.current?.click(),
    loadSample: handleLoadDirtySample,
    removeColumn: () => handleRemoveColumn(),
    duplicateColumn: () => handleDuplicateColumn(),
    renameColumn: () => selectedColumn && handleRenameColumn(selectedColumn),
    moveColumn: (dir) => selectedColumn && handleMoveColumn(selectedColumn, dir),
    openSplit: () => setSplitModalOpen(true),
    openMerge: () => setMergeModalOpen(true),
    openReplaceValues: () => setReplaceValuesModalOpen(true),
    openReplaceErrors: () => setTransformParamModalState({ isOpen: true, type: 'replace_errors', column: selectedColumn || '' }),
    openReplaceNulls: () => setTransformParamModalState({ isOpen: true, type: 'replace_nulls', column: selectedColumn || '' }),
    openRemoveDuplicates: () => setRemoveDuplicatesModalOpen(true),
    openManageRows: (action) => setManageRowsModalState({ isOpen: true, action }),
    sort: (dir) => selectedColumn && handleApplySort(selectedColumn, dir),
    fillDown: () => handleFillDown(),
    fillUp: () => handleFillUp(),
    text: handleTextTransform,
    number: handleNumberTransform,
    date: handleDateTransform,
    addCustomColumn: () =>
      setTransformParamModalState({
        isOpen: true,
        type: 'custom_column',
        column: selectedColumn || currentEvaluation.columns[0]?.name || '',
        availableColumns: currentEvaluation.columns.map((c) => c.name),
      }),
  });

  const applySuggestion = (sg: Suggestion) => addStepToActiveQuery(sg.step.type, sg.step.name, sg.step.params, sg.detail);

  // Ctrl/Cmd+K opens the action palette from anywhere in the studio.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="w-screen h-screen bg-lab-bg flex flex-col overflow-hidden text-lab-text font-sans antialiased select-none">
      {/* STUDIO HEADER */}
      <header className="h-12 px-4 flex items-center justify-between shrink-0 bg-lab-bg border-b border-lab-line z-40">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="h-8 pl-2 pr-3 rounded-lg flex items-center gap-1.5 text-[13px] font-semibold text-lab-dim hover:text-lab-text hover:bg-lab-raised transition-colors"
            title="Leave without applying"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>
          <span className="h-5 w-px bg-lab-line" />
          <div className="flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-lg grid place-items-center bg-gradient-to-br from-pulse-500 to-volt-600 shadow-glow">
              <BrandLogo size={15} />
            </span>
            <div className="leading-tight">
              <p className="text-[14px] font-extrabold tracking-tight">
                Data <span className="bg-gradient-to-r from-pulse-300 to-volt-400 bg-clip-text text-transparent">Lab</span>
              </p>
              <p className="text-[10px] text-lab-faint -mt-0.5">pipeline studio for messy data</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onClose}
            className="h-8 px-3 rounded-lg text-[13px] font-semibold text-lab-dim hover:text-lab-text hover:bg-lab-raised transition-colors"
          >
            Discard
          </button>
          <button
            type="button"
            onClick={handleCommitCloseAndApply}
            className="h-8 px-4 rounded-lg flex items-center gap-2 text-[13px] font-bold text-white bg-gradient-to-r from-pulse-500 to-volt-600 hover:brightness-110 active:brightness-95 shadow-lg shadow-pulse-500/20 transition"
          >
            <CheckCircle2 className="w-4 h-4" />
            Apply &amp; close
          </button>
        </div>
      </header>

      {/* COMMAND BAR */}
      <CommandBar
        actions={labActions}
        selectedColumn={selectedColumn}
        selectedType={selectedColObj?.dataType}
        onOpenPalette={() => setPaletteOpen(true)}
      />
      {paletteOpen && (
        <CommandPalette
          actions={labActions}
          selectedColumn={selectedColumn}
          selectedType={selectedColObj?.dataType}
          onClose={() => setPaletteOpen(false)}
        />
      )}

      {/* HIDDEN FILE INPUT */}
      <input type="file" ref={fileInputRef} accept=".csv,.xlsx,.xls" className="hidden" onChange={handleFileUpload} />

      {/* WORKSPACE: pipeline | data | inspector */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        {activeQuery && (
          <StepRail
            queryName={activeQuery.name}
            sourceType={activeQuery.sourceType}
            steps={activeQuery.steps}
            trace={trace}
            selectedStepId={activeQuery.selectedStepId}
            onSelectStep={handleSelectStep}
            onDeleteStep={handleDeleteStep}
            onRenameStep={handleRenameStep}
            onEditStepSettings={handleEditStepSettings}
            onMoveStepUp={handleMoveStepUp}
            onMoveStepDown={handleMoveStepDown}
            onQueryNameChange={handleQueryNameChange}
          />
        )}

        <main className="flex-1 min-w-0 flex flex-col overflow-hidden">
          <QueryTabs
            queries={queries}
            activeId={activeQuery?.id}
            onSelect={(id) => {
              setActiveQueryId(id);
              setSelectedColumn(null);
            }}
            onAdd={() => fileInputRef.current?.click()}
            onSample={handleLoadDirtySample}
          />

          {queries.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-lab-bg">
              <div className="w-14 h-14 rounded-2xl grid place-items-center bg-lab-raised border border-lab-line-strong mb-4">
                <Database className="w-6 h-6 text-pulse-400" />
              </div>
              <h3 className="text-lg font-bold">Bring in some data</h3>
              <p className="text-[13px] text-lab-dim max-w-sm mt-1.5 mb-5">
                Upload a CSV or Excel file, or load the messy sample to see how the Data Lab cleans it step by step.
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-9 px-4 rounded-lg flex items-center gap-2 text-[13px] font-bold text-white bg-gradient-to-r from-pulse-500 to-volt-600 hover:brightness-110"
                >
                  <Upload className="w-4 h-4" /> Upload a file
                </button>
                <button
                  type="button"
                  onClick={handleLoadDirtySample}
                  className="h-9 px-4 rounded-lg flex items-center gap-2 text-[13px] font-semibold text-amber-200 border border-amber-400/30 bg-amber-400/10 hover:bg-amber-400/15"
                >
                  <Sparkles className="w-4 h-4" /> Messy sample
                </button>
              </div>
            </div>
          ) : (
            <DataGridPreview
              columns={currentEvaluation.columns}
              rows={currentEvaluation.rows}
              selectedColumn={selectedColumn}
              showQualityBar
              onSelectColumn={(col) => setSelectedColumn(col)}
              onChangeDataType={handleChangeDataType}
              onRenameColumn={handleRenameColumn}
              onRemoveColumn={handleRemoveColumn}
              onDuplicateColumn={handleDuplicateColumn}
              onMoveColumn={handleMoveColumn}
              onApplySort={handleApplySort}
              onApplyFilter={handleApplyFilter}
              onOpenSplitColumn={() => setSplitModalOpen(true)}
              onOpenReplaceValues={() => setReplaceValuesModalOpen(true)}
              onOpenReplaceErrors={() =>
                setTransformParamModalState({ isOpen: true, type: 'replace_errors', column: selectedColumn || '' })
              }
              onFillDown={handleFillDown}
              onFillUp={handleFillUp}
            />
          )}

          {activeQuery && (
            <LabStatusBar
              rows={currentEvaluation.totalRows}
              columns={currentEvaluation.totalColumns}
              errors={currentEvaluation.totalErrors}
              stepIndex={selectedStepIndex}
              stepCount={activeQuery.steps.length}
              stepName={currentStep?.name || 'Source'}
              formula={activeFormula}
              score={health}
              inspectorOpen={inspectorOpen}
              onToggleInspector={() => setInspectorOpen((v) => !v)}
            />
          )}
        </main>

        {activeQuery && queries.length > 0 && inspectorOpen && (
          <ColumnInspector
            columns={currentEvaluation.columns}
            rows={currentEvaluation.rows}
            selectedColumn={selectedColumn}
            onApply={applySuggestion}
            onSelectColumn={setSelectedColumn}
            onClose={() => setInspectorOpen(false)}
          />
        )}
      </div>

      {/* MODALS */}
      {/* 1. Split Column Modal */}
      {splitModalOpen && (
        <SplitColumnModal
          isOpen={splitModalOpen}
          column={selectedColumn || currentEvaluation.columns[0]?.name || ''}
          sampleRows={currentEvaluation.rows}
          onClose={() => setSplitModalOpen(false)}
          onApply={(params) => {
            addStepToActiveQuery('split_column', `Split Column (${params.column})`, params);
          }}
        />
      )}

      {/* 2. Merge Columns Modal */}
      {mergeModalOpen && (
        <MergeColumnsModal
          isOpen={mergeModalOpen}
          availableColumns={currentEvaluation.columns.map((c) => c.name)}
          initialSelectedColumns={selectedColumn ? [selectedColumn] : []}
          sampleRows={currentEvaluation.rows}
          onClose={() => setMergeModalOpen(false)}
          onApply={(params) => {
            addStepToActiveQuery('merge_columns', `Merged Columns (${params.newColumnName})`, params);
          }}
        />
      )}

      {/* 3. Replace Values Modal */}
      {replaceValuesModalOpen && (
        <ReplaceValuesModal
          isOpen={replaceValuesModalOpen}
          column={selectedColumn || currentEvaluation.columns[0]?.name || ''}
          sampleRows={currentEvaluation.rows}
          onClose={() => setReplaceValuesModalOpen(false)}
          onApply={(params) => {
            addStepToActiveQuery('replace_values', `Replaced Value (${params.column})`, params);
          }}
        />
      )}

      {/* 4. Remove Duplicates Modal */}
      {removeDuplicatesModalOpen && (
        <RemoveDuplicatesModal
          isOpen={removeDuplicatesModalOpen}
          columns={currentEvaluation.columns.map((c) => c.name)}
          initialSelectedColumns={selectedColumn ? [selectedColumn] : []}
          onClose={() => setRemoveDuplicatesModalOpen(false)}
          onApply={(selectedCols) => {
            addStepToActiveQuery('remove_duplicates', 'Removed Duplicates', { columns: selectedCols });
          }}
        />
      )}

      {/* 5. Manage Rows Modal */}
      {manageRowsModalState.isOpen && (
        <ManageRowsModal
          isOpen={manageRowsModalState.isOpen}
          actionType={manageRowsModalState.action}
          totalRows={currentEvaluation.totalRows}
          onClose={() => setManageRowsModalState((prev) => ({ ...prev, isOpen: false }))}
          onApply={(params) => {
            if (params.action === 'remove_blank') {
              addStepToActiveQuery('remove_rows', 'Removed Blank Rows', { action: 'remove_blank' });
            } else if (params.action.startsWith('keep_')) {
              addStepToActiveQuery('keep_rows', `Kept Rows (${params.action})`, params);
            } else {
              addStepToActiveQuery('remove_rows', `Removed Rows (${params.action})`, params);
            }
          }}
        />
      )}

      {/* 6. Transform Parameters Modal */}
      {transformParamModalState.isOpen && (
        <TransformParamModal
          isOpen={transformParamModalState.isOpen}
          type={transformParamModalState.type}
          column={transformParamModalState.column || selectedColumn || ''}
          initialValue={transformParamModalState.initialValue}
          initialValue2={transformParamModalState.initialValue2}
          availableColumns={currentEvaluation.columns.map((c) => c.name)}
          onClose={() => setTransformParamModalState((prev) => ({ ...prev, isOpen: false }))}
          onApply={(params) => {
            if (transformParamModalState.type === 'rename_step') {
              setQueries((prev) =>
                prev.map((q) =>
                  q.id === activeQuery.id
                    ? {
                        ...q,
                        steps: q.steps.map((s) =>
                          s.id === activeQuery.selectedStepId ? { ...s, name: params.newName } : s
                        ),
                      }
                    : q
                )
              );
            } else if (transformParamModalState.type === 'rename_column') {
              addStepToActiveQuery('rename_column', `Renamed Column (${params.newName})`, params);
            } else if (transformParamModalState.type === 'replace_errors') {
              addStepToActiveQuery('replace_errors', `Replaced Errors (${params.column})`, params);
            } else if (transformParamModalState.type === 'replace_nulls') {
              addStepToActiveQuery('replace_nulls', `Replaced Nulls (${params.column})`, params);
            } else if (transformParamModalState.type.startsWith('text_')) {
              addStepToActiveQuery('text_transform', `Transformed Text (${params.column})`, params);
            } else if (transformParamModalState.type.startsWith('number_')) {
              addStepToActiveQuery('number_transform', `Number Transform (${params.column})`, params);
            } else if (transformParamModalState.type === 'custom_column') {
              addStepToActiveQuery('add_custom_column', `Added Custom Column (${params.newColumnName})`, params);
            }
          }}
        />
      )}
    </div>
  );
};
