import React, { useState } from 'react';
import { User } from '../types/auth';
import { MarketingNavbar } from '../components/Navbar/MarketingNavbar';
import { AnimatedBackground } from '../components/AnimatedBackground';
import { BrandLockup } from '../components/BrandLogo';
import {
  Database,
  Sparkles,
  Network,
  LayoutGrid,
  ShieldCheck,
  Zap,
  ArrowRight,
  Layers,
  BarChart3,
  CheckCircle2,
  Table,
  Sliders,
  Calendar,
  Code2,
  Box,
  Eye,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  onNavigate: (
    page: 'home' | 'features' | 'pricing' | 'about' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub',
    dashboardId?: string
  ) => void;
}

export const FeaturesPage: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'hub' | 'explore' | 'model' | 'widgets' | 'security'>('hub');

  const featureTabs = [
    {
      id: 'hub' as const,
      label: 'Global Data Hub',
      icon: Database,
      title: 'Centralized, Reusable Data Assets',
      desc: 'Upload CSV, Excel, or live API sources once. A dataset belongs to your Data Hub—not a single dashboard—and can be referenced across dozens of dashboards without duplication.',
      highlights: [
        'Isolated per-workspace data governance and session token security',
        'Automatic schema inference with sample value inspection',
        'Immutability through non-destructive version history',
        'Multi-format support for high-throughput business data',
      ],
      previewBadge: 'Data Hub V2',
      previewCode: `// Architecture: One dataset referenced by N dashboards
const salesHubDataset = {
  id: "ds_sales_2026",
  name: "Enterprise Revenue 2026",
  rowCount: 142000,
  referencedBy: ["Exec Suite", "Regional Sales", "Q3 Review"]
};`,
    },
    {
      id: 'explore' as const,
      label: 'Explore the Data',
      icon: Sparkles,
      title: 'Step-by-Step Data Transformation Pipeline',
      desc: 'Clean, reshape, and transform raw files in Explore the data. Every change generates an auditable Applied Step in the pipeline that can be inspected, reordered, edited, or recalculated in real time.',
      highlights: [
        'Applied Steps pipeline (Source → Changed Type → Filtered Rows → Cleaned)',
        'Automatic representative-sample column type detection',
        'Real-time Column Quality analysis (Valid %, Empty %, Error %)',
        'Rich string, numeric, date, and custom conditional operations',
      ],
      previewBadge: 'Applied Steps Engine',
      previewCode: `// Applied Transformation Steps Pipeline
pipeline.apply([
  { type: "promoted_headers" },
  { type: "changed_type", column: "Sales", newType: "currency" },
  { type: "filter_rows", operator: ">", value: 1000 },
  { type: "remove_duplicates", columns: ["Transaction_ID"] }
]);`,
    },
    {
      id: 'model' as const,
      label: 'Star Schema Modeling',
      icon: Network,
      title: 'Analytical Star Schema & Relationships',
      desc: 'Design high-performance dimensional star models directly in your browser. Designate Fact tables, Dimension tables, define 1:* relationships, and generate custom calculated measures.',
      highlights: [
        'Auto-detection of Fact & Dimension topologies with confidence scoring',
        '1-click DIM_DATE calendar dimension generation (Year, Quarter, Month, Week)',
        'Interactive diagram canvas with draggable cards & bezier connectors',
        'DAX-style calculated measures with currency, percentage & compact formats',
      ],
      previewBadge: 'Star Schema Engine',
      previewCode: `// Star Topology Definition
const starSchema = {
  fact: "FACT_SALES",
  dimensions: ["DIM_CUSTOMERS", "DIM_PRODUCTS", "DIM_DATE"],
  relationships: [
    "DIM_CUSTOMERS (ID) ── 1:* ──> FACT_SALES (Customer_ID)",
    "DIM_PRODUCTS (ID) ── 1:* ──> FACT_SALES (Product_ID)"
  ]
};`,
    },
    {
      id: 'widgets' as const,
      label: 'Visual Dashboards',
      icon: LayoutGrid,
      title: 'Drag-and-Drop Responsive Visualization Canvas',
      desc: 'Assemble rich presentation-grade analytics dashboards with over 30 specialized widgets. Combine KPIs, sparklines, interactive slicers, geographic maps, and 3D surface visualizations.',
      highlights: [
        'Over 30 customizable visualization widget types',
        'Independent or linked widget dataset selection with dependency safety',
        'Global and widget-level interactive cross-filtering',
        'Pixel-perfect print/PDF export and presentation mode',
      ],
      previewBadge: 'Canvas Engine',
      previewCode: `// Widget Configuration Binding
<WidgetRenderer
  type="kpi"
  datasetId="ds_sales_2026"
  measure="SUM(Sales_Amount)"
  format="currency"
  animation="smooth"
/>`,
    },
    {
      id: 'security' as const,
      label: 'Enterprise Isolation',
      icon: ShieldCheck,
      title: 'Strict User & Workspace Data Isolation',
      desc: 'Never worry about multi-tenant data leaks. Every dataset, dashboard, report, and model query is strictly authenticated, authorized, and scoped to the user workspace on the server.',
      highlights: [
        'No browser storage: sessions use an httpOnly cookie and all data lives in the database',
        'Server-side session validation and token verification',
        'Environment-driven secret configuration without frontend leaks',
        'Safe dataset deletion dependency checks to prevent broken widgets',
      ],
      previewBadge: 'Security Tier',
      previewCode: `// Server-Side Request Isolation
app.get('/api/datasets', requireAuth, (req, res) => {
  const userDatasets = db.getDatasetsByUserId(req.user.id);
  res.json({ success: true, datasets: userDatasets });
});`,
    },
  ];

  const currentTabObj = featureTabs.find((t) => t.id === activeTab) || featureTabs[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col relative selection:bg-sky-500 selection:text-white">
      {/* Animated Glowing Constellation Background */}
      <AnimatedBackground />

      {/* Navigation */}
      <MarketingNavbar currentUser={currentUser} activeNav="features" onNavigate={onNavigate} />

      {/* Hero Section */}
      <main className="relative z-10 pt-32 pb-24 px-4 sm:px-6 md:px-12 max-w-7xl mx-auto w-full flex-1">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200/80 text-sky-700 text-xs font-bold mb-6 shadow-2xs">
            <Zap className="w-3.5 h-3.5 text-sky-600" />
            <span>Modern Business Intelligence Architecture</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
            Engineered for <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 bg-clip-text text-transparent">
              End-to-End Analytical Power
            </span>
          </h1>

          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Data Pulse brings together data ingestion, Explore the data transformation,
            dimensional Star Schema modeling, and visual dashboarding in one unified platform.
          </p>
        </div>

        {/* Feature Tabs Selector */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {featureTabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = tab.id === activeTab;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shadow-xs ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-md shadow-slate-900/15 scale-[1.02]'
                    : 'bg-white/80 hover:bg-white text-slate-700 border border-slate-200/80 hover:border-slate-300'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-sky-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Feature Interactive Showcase Card */}
        <div className="bg-white/90 backdrop-blur-xl border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-xl shadow-slate-200/50 transition-all grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-20">
          {/* Left Column: Details & Highlights */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-sky-100/70 text-sky-800 text-[11px] font-bold font-mono">
              <span>{currentTabObj.previewBadge}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {currentTabObj.title}
            </h2>

            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              {currentTabObj.desc}
            </p>

            <div className="space-y-3 pt-2">
              {currentTabObj.highlights.map((highlight, idx) => (
                <div key={idx} className="flex items-start gap-3 text-xs sm:text-sm text-slate-700 font-medium">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <span>{highlight}</span>
                </div>
              ))}
            </div>

            <div className="pt-4 flex items-center gap-4">
              <button
                type="button"
                onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
                className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-sky-600 text-white font-bold text-xs shadow-sm shadow-slate-900/20 transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Try this feature</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Column: Code / Topology Mockup */}
          <div className="lg:col-span-5 bg-slate-950 rounded-2xl border border-slate-800 p-5 shadow-2xl text-slate-300 font-mono text-xs overflow-hidden">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/80 text-[11px] text-slate-500">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                <span className="ml-2 font-sans font-semibold text-slate-400">data-pulse-architecture</span>
              </div>
              <span className="text-slate-600">TypeScript</span>
            </div>

            <pre className="text-emerald-400/90 leading-relaxed overflow-x-auto p-1 font-mono text-[11px]">
              <code>{currentTabObj.previewCode}</code>
            </pre>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                Zero-Latency Engine
              </span>
              <span className="text-sky-400 font-semibold">Ready in production</span>
            </div>
          </div>
        </div>

        {/* 6 Grid Core Capabilities */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
              Full Stack BI Capabilities
            </h3>
            <p className="text-slate-500 text-sm">
              Everything required to transform messy raw spreadsheets into board-ready executive intelligence.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all">
              <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center mb-4">
                <Table className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Automated Ingestion</h4>
              <p className="text-slate-600 text-xs leading-relaxed">
                Parse complex CSV and multi-sheet Excel files instantly. Dynamic type inference identifies dates, currencies, and numbers automatically.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4">
                <Sparkles className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Applied Steps Pipeline</h4>
              <p className="text-slate-600 text-xs leading-relaxed">
                Step-by-step transformations with instant rollback. Split columns, merge values, fill blanks, and clean strings without formula syntax.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mb-4">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Fact & Dimension Tables</h4>
              <p className="text-slate-600 text-xs leading-relaxed">
                Separate quantitative transaction metrics from descriptive master entity tables for scalable data warehousing and star schema efficiency.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mb-4">
                <Calendar className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">DIM_DATE Calendar Generation</h4>
              <p className="text-slate-600 text-xs leading-relaxed">
                Generate complete date dimensions automatically with year, quarter, month, day name, and week of year for seamless time-intelligence analytics.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center mb-4">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Rich Visualization Library</h4>
              <p className="text-slate-600 text-xs leading-relaxed">
                Render bar charts, line trends, pie slices, area charts, KPI cards, heatmaps, and interactive 3D volumetric elevation models seamlessly.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200/80 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-slate-900 text-base mb-2">Data Dependency Safety</h4>
              <p className="text-slate-600 text-xs leading-relaxed">
                When removing a dataset from a dashboard, active dependencies on widgets, filters, and star schema relationships are audited before changes take effect.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom CTA Banner */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 rounded-3xl p-8 sm:p-12 text-center text-white relative overflow-hidden shadow-2xl">
          <div className="relative z-10 max-w-2xl mx-auto space-y-4">
            <h3 className="text-2xl sm:text-4xl font-black tracking-tight">
              Ready to experience modern business intelligence?
            </h3>
            <p className="text-slate-300 text-sm leading-relaxed">
              Start building dashboards in seconds with canonical datasets or your own business spreadsheets.
            </p>
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
                className="w-full sm:w-auto px-8 py-3.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-black rounded-xl text-sm transition-all shadow-lg shadow-sky-500/25 cursor-pointer"
              >
                Get Started Free
              </button>
              <button
                type="button"
                onClick={() => onNavigate('sample_graphs')}
                className="w-full sm:w-auto px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-sm transition-all border border-white/20 cursor-pointer"
              >
                View Visual Gallery
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 bg-slate-950 text-slate-300 py-12 px-6 md:px-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <BrandLockup size={32} textSize="text-lg" />
          <div className="flex gap-6 text-xs font-semibold text-slate-400">
            <button onClick={() => onNavigate('features')} className="hover:text-white transition-colors cursor-pointer">Features</button>
            <button onClick={() => onNavigate('pricing')} className="hover:text-white transition-colors cursor-pointer">Pricing</button>
            <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">About</button>
          </div>
          <p className="text-xs text-slate-500">
            &copy; 2026 Data Pulse. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};
