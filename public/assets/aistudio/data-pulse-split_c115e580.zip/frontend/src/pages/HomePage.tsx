import React from 'react';
import { User } from '../types/auth';
import { MarketingNavbar } from '../components/Navbar/MarketingNavbar';
import { AnimatedBackground } from '../components/AnimatedBackground';
import { BrandLockup } from '../components/BrandLogo';
import {
  Sparkles,
  Database,
  LayoutGrid,
  ShieldCheck,
  Zap,
  ArrowRight,
  BarChart3,
  CheckCircle2,
  Table,
  Sliders,
  Calendar,
  Layers,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  onNavigate: (
    page: 'home' | 'features' | 'pricing' | 'about' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub',
    dashboardId?: string
  ) => void;
}

export const HomePage: React.FC<Props> = ({ currentUser, onNavigate }) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col relative selection:bg-sky-500 selection:text-white">
      {/* Animated Glowing Background Network & Ambient Lights */}
      <AnimatedBackground />

      {/* Navigation Bar (Features, Pricing, About) */}
      <MarketingNavbar currentUser={currentUser} activeNav="home" onNavigate={onNavigate} />

      {/* Hero Section */}
      <section className="relative z-10 pt-36 pb-20 md:pt-44 md:pb-28 px-4 sm:px-6 md:px-12 flex flex-col items-center justify-center text-center overflow-hidden max-w-6xl mx-auto w-full">
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-slate-900 leading-[1.08] mb-6 max-w-4xl">
          Turn Raw Data Into <br />
          <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 bg-clip-text text-transparent">
            Executive Intelligence
          </span>
        </h1>

        <p className="text-slate-600 text-base sm:text-lg md:text-xl max-w-2xl font-normal leading-relaxed mb-10">
          Upload spreadsheets, clean records with an immutable step pipeline, model star schemas with fact and dimension tables, and design responsive board-level dashboards without writing code.
        </p>

        {/* Hero Actions */}
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-slate-900 hover:bg-sky-600 active:scale-[0.98] text-white font-extrabold text-sm shadow-xl shadow-slate-900/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Get Started Free</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => onNavigate('features')}
            className="w-full sm:w-auto px-7 py-4 rounded-xl bg-white/90 hover:bg-white text-slate-800 border border-slate-200 hover:border-slate-300 font-bold text-sm shadow-xs transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>Explore All Features</span>
          </button>
        </div>
      </section>

      {/* 3 Pillars Summary Section (Features / Pricing / About preview) */}
      <section className="relative z-10 py-20 px-4 sm:px-6 md:px-12 bg-white/70 backdrop-blur-md border-t border-slate-200/80">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
              Explore Data Pulse
            </h2>
            <p className="text-slate-600 font-medium text-base">
              Engineered with clean separation between data assets, transformations, modeling, and presentation.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Card 1: Features */}
            <div
              onClick={() => onNavigate('features')}
              className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-xl hover:border-sky-300 hover:-translate-y-1.5 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-3 group-hover:text-sky-600 transition-colors">
                  Product Features
                </h3>
                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                  Discover Global Data Hub ingestion, Explore the data Applied Steps, automatic type inference, column quality indicators, and Star Schema dimensional modeling.
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-bold text-sky-600">
                <span>View All Features</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Card 2: Pricing */}
            <div
              onClick={() => onNavigate('pricing')}
              className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-xl hover:border-sky-300 hover:-translate-y-1.5 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <BarChart3 className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-3 group-hover:text-indigo-600 transition-colors">
                  Plans &amp; Pricing
                </h3>
                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                  Transparent, value-driven plans. Get started free forever with core cleaning and dashboards, or upgrade to Professional for advanced star schema modeling and cloud sync.
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-bold text-indigo-600">
                <span>Compare Pricing Tiers</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Card 3: About */}
            <div
              onClick={() => onNavigate('about')}
              className="p-8 rounded-3xl bg-white border border-slate-200/90 shadow-sm hover:shadow-xl hover:border-sky-300 hover:-translate-y-1.5 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-black text-slate-900 mb-3 group-hover:text-emerald-600 transition-colors">
                  About Data Pulse
                </h3>
                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                  Learn about our mission to bring lightning-fast, zero-lockin visual analytics to the browser. Read our architecture blueprint and engineering values.
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-bold text-emerald-600">
                <span>Read Our Story</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 bg-slate-950 text-slate-300 py-16 px-6 md:px-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 items-center">
          <div className="space-y-3">
            <BrandLockup size={36} textSize="text-xl" />
            <p className="text-slate-400 text-sm max-w-sm">
              Visual analytics platform built for modern scaling teams. Ingest, transform, model, and visualize data without friction.
            </p>
          </div>

          <div className="flex flex-wrap gap-8 text-sm font-semibold text-slate-300">
            <button
              onClick={() => onNavigate('features')}
              className="hover:text-sky-400 transition-colors cursor-pointer"
            >
              Features
            </button>
            <button
              onClick={() => onNavigate('pricing')}
              className="hover:text-sky-400 transition-colors cursor-pointer"
            >
              Pricing
            </button>
            <button
              onClick={() => onNavigate('about')}
              className="hover:text-sky-400 transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              onClick={() => onNavigate('sample_graphs')}
              className="hover:text-sky-400 transition-colors cursor-pointer"
            >
              Visual Gallery
            </button>
          </div>

          <div className="text-left md:text-right text-xs text-slate-500 space-y-1">
            <p>&copy; 2026 Data Pulse. All Rights Reserved.</p>
            <p className="italic text-slate-400">Intelligence in motion.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};
