import React, { useState, useEffect } from 'react';
import { User } from '../types/auth';
import { DashboardState, ProjectType, Dataset } from '../types/dashboard';
import { DEFAULT_CANVAS, DEFAULT_REPORT_CANVAS } from '../data/sampleDashboards';
import { BrandLockup } from '../components/BrandLogo';
import { fetchDashboardsFromDb, saveDashboardToDb, deleteDashboardFromDb } from '../services/dbService';
import { syncModelWithUsedDatasets } from '../utils/dataModelingEngine';
import { AppNavbar } from '../components/Navbar/AppNavbar';
import { Badge, Button, Card, EmptyState, PageHeader, Segmented, StatCard, cx } from '../ui';
import { hasActiveDataModel } from '../utils/semanticQueryEngine';
import {
  Plus,
  LayoutGrid,
  Search,
  Calendar,
  ArrowUpDown,
  Trash2,
  Edit2,
  Clock,
  User as UserIcon,
  Settings,
  LogOut,
  ChevronDown,
  X,
  AlertTriangle,
  Tag,
  FileText,
  BarChart3,
  Filter,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  onLogout: () => void;
  onOpenDashboard: (dashboardId: string) => void;
  onNavigate: (page: 'home' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub', dashboardId?: string) => void;
  globalDatasets?: Dataset[];
}

export const DashboardHubPage: React.FC<Props> = ({
  currentUser,
  onLogout,
  onOpenDashboard,
  onNavigate,
  globalDatasets = [],
}) => {
  const [dashboards, setDashboards] = useState<DashboardState[]>([]);
  const [dbError, setDbError] = useState<string | null>(null);

  // Load from backend database on mount
  useEffect(() => {
    fetchDashboardsFromDb()
      .then((items) => {
        setDashboards(items);
        setDbError(null);
      })
      .catch((e) => setDbError(e?.message || 'Could not load dashboards from the database'));
  }, []);

  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month' | 'year'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'dashboard' | 'report'>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest' | 'name'>('newest');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [dashboardToDelete, setDashboardToDelete] = useState<DashboardState | null>(null);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

  // New Dashboard / Report Form State: starts with 0 datasets selected
  const [newProjectType, setNewProjectType] = useState<ProjectType>('dashboard');
  const [canvasPreset, setCanvasPreset] = useState<'1920x1080' | '1366x768' | 'a4_portrait' | 'a4_landscape' | 'us_letter'>('1920x1080');
  const [newName, setNewName] = useState('');
  const [newUsedFor, setNewUsedFor] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('📊');
  const [selectedDsIds, setSelectedDsIds] = useState<string[]>([]);

  // Handle Create Dashboard or Report
  const handleCreateDashboard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newUsedFor.trim()) return;

    let canvasSettings = { ...DEFAULT_CANVAS };
    if (newProjectType === 'report') {
      if (canvasPreset === 'a4_landscape') {
        canvasSettings = {
          presetName: 'A4 Report Landscape (1056×816)',
          width: 1056,
          height: 816,
          zoom: 0.85,
          backgroundType: 'color',
          backgroundColor: '#FFFFFF',
          gradientValue: 'linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)',
          imageUrl: '',
          imageFit: 'cover',
          showGrid: false,
          snapToGrid: true,
          gridGap: 10,
        };
      } else if (canvasPreset === 'us_letter') {
        canvasSettings = {
          presetName: 'US Letter Report (850×1100)',
          width: 850,
          height: 1100,
          zoom: 0.9,
          backgroundType: 'color',
          backgroundColor: '#FFFFFF',
          gradientValue: 'linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)',
          imageUrl: '',
          imageFit: 'cover',
          showGrid: false,
          snapToGrid: true,
          gridGap: 10,
        };
      } else {
        canvasSettings = { ...DEFAULT_REPORT_CANVAS };
      }
    } else {
      if (canvasPreset === '1366x768') {
        canvasSettings = {
          ...DEFAULT_CANVAS,
          presetName: '1366×768 Laptop (Dashboard)',
          width: 1366,
          height: 768,
        };
      } else {
        canvasSettings = {
          ...DEFAULT_CANVAS,
          presetName: '1920×1080 Full HD (Dashboard)',
          width: 1920,
          height: 1080,
        };
      }
    }

    const chosenDatasets = globalDatasets.filter((d) => selectedDsIds.includes(d.id));
    const initialModel = syncModelWithUsedDatasets(undefined, chosenDatasets, newName.trim());

    const newDash: DashboardState = {
      id: `${newProjectType}_${Date.now()}`,
      name: newName.trim(),
      description: newDescription.trim(),
      type: newProjectType,
      usedFor: newUsedFor.trim(),
      thumbnail: selectedIcon || (newProjectType === 'report' ? '📄' : '📊'),
      widgets: [],
      datasets: chosenDatasets,
      selectedDatasetIds: selectedDsIds,
      dataModel: initialModel,
      canvas: canvasSettings,
      pages: newProjectType === 'report' ? [{ id: 'p_1', name: 'Page 1' }] : undefined,
      activePageId: newProjectType === 'report' ? 'p_1' : undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastAccessed: new Date().toISOString(),
    };

    setIsCreateModalOpen(false);

    // Save to the database first; only show it once it's really stored.
    try {
      await saveDashboardToDb(newDash);
      setDashboards((prev) => [newDash, ...prev]);
      setDbError(null);
    } catch (e: any) {
      setDbError(e?.message || 'Could not save the dashboard to the database');
      return;
    }

    // Reset Form
    setNewName('');
    setNewUsedFor('');
    setNewDescription('');
    setNewProjectType('dashboard');
    setCanvasPreset('1920x1080');
    setSelectedIcon('📊');

    // Open immediately in editor
    onOpenDashboard(newDash.id);
  };

  // Handle Delete Dashboard
  const confirmDelete = async () => {
    if (!dashboardToDelete) return;
    const targetId = dashboardToDelete.id;
    setDashboardToDelete(null);
    try {
      await deleteDashboardFromDb(targetId);
      setDashboards((prev) => prev.filter((d) => d.id !== targetId));
      setDbError(null);
    } catch (e: any) {
      setDbError(e?.message || 'Could not delete the dashboard from the database');
    }
  };

  // Filtering Logic
  const filteredDashboards = dashboards
    .filter((d) => {
      const matchSearch =
        d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (d.usedFor && d.usedFor.toLowerCase().includes(searchTerm.toLowerCase()));

      if (!matchSearch) return false;

      const isReportItem =
        d.type === 'report' ||
        d.canvas.presetName.toLowerCase().includes('report') ||
        d.canvas.presetName.toLowerCase().includes('a4') ||
        d.canvas.presetName.toLowerCase().includes('letter');

      if (typeFilter === 'dashboard' && isReportItem) return false;
      if (typeFilter === 'report' && !isReportItem) return false;

      if (dateFilter !== 'all') {
        const createdDate = new Date(d.createdAt || Date.now());
        const now = new Date();
        const diffDays = (now.getTime() - createdDate.getTime()) / (1000 * 3600 * 24);

        if (dateFilter === 'today' && diffDays > 1) return false;
        if (dateFilter === 'week' && diffDays > 7) return false;
        if (dateFilter === 'month' && diffDays > 30) return false;
        if (dateFilter === 'year' && diffDays > 365) return false;
      }

      return true;
    })
    .sort((a, b) => {
      if (sortOrder === 'newest') {
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
      }
      if (sortOrder === 'oldest') {
        return new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();
      }
      if (sortOrder === 'name') {
        return a.name.localeCompare(b.name);
      }
      return 0;
    });

  const formatDate = (isoStr?: string) => {
    if (!isoStr) return 'Recently';
    try {
      const date = new Date(isoStr);
      return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
    } catch {
      return 'Recently';
    }
  };

  const userFirstName = currentUser?.first_name || 'User';
  const userFullName = currentUser ? `${currentUser.first_name} ${currentUser.last_name}` : 'User';
  const userInitial = userFirstName.charAt(0).toUpperCase();

  const totalDashboardsCount = dashboards.filter(
    (d) =>
      d.type !== 'report' &&
      !d.canvas.presetName.toLowerCase().includes('report') &&
      !d.canvas.presetName.toLowerCase().includes('a4')
  ).length;

  const totalReportsCount = dashboards.filter(
    (d) =>
      d.type === 'report' ||
      d.canvas.presetName.toLowerCase().includes('report') ||
      d.canvas.presetName.toLowerCase().includes('a4') ||
      d.canvas.presetName.toLowerCase().includes('letter')
  ).length;

  return (
    <div className="min-h-screen bg-[#f4f6fb] text-slate-900 font-sans flex flex-col">
      {/* Navigation Header */}
      <AppNavbar
        active="dashboard_hub"
        currentUser={currentUser}
        onNavigate={onNavigate}
        onLogout={() => setIsLogoutModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto w-full px-6 md:px-10 py-10 flex-1 flex flex-col gap-8">
        <PageHeader
          eyebrow="Workspace"
          title={<>Welcome back, <span className="bg-gradient-to-r from-pulse-500 to-volt-600 bg-clip-text text-transparent">{userFirstName}</span></>}
          description="Build interactive dashboards and print-ready reports on top of your cleaned, modelled data."
          actions={
            <Button variant="primary" size="lg" icon={<Plus className="w-4 h-4" />} onClick={() => setIsCreateModalOpen(true)}>
              New dashboard / report
            </Button>
          }
        />

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <StatCard tone="sky" icon={<LayoutGrid className="w-6 h-6" />} value={dashboards.length} label="Workspaces" />
          <StatCard tone="violet" icon={<BarChart3 className="w-6 h-6" />} value={totalDashboardsCount} label="Interactive dashboards" />
          <StatCard tone="amber" icon={<FileText className="w-6 h-6" />} value={totalReportsCount} label="Printable reports" />
        </div>

        {/* Workspace History Section */}
        <div className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-sky-600" />
              <h2 className="text-lg font-black text-slate-900 tracking-tight">Workspace History</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-sky-600 text-white font-black text-xs">
                {filteredDashboards.length}
              </span>
            </div>

            {/* Toolbar Controls */}
            <div className="flex flex-wrap items-center gap-3">
              <Segmented<'all' | 'dashboard' | 'report'>
                value={typeFilter}
                onChange={setTypeFilter}
                options={[
                  { value: 'all', label: 'All' },
                  { value: 'dashboard', label: <><BarChart3 className="w-3.5 h-3.5" /> Dashboards</> },
                  { value: 'report', label: <><FileText className="w-3.5 h-3.5" /> Reports</> },
                ]}
              />

              {/* Search */}
              <div className="relative min-w-[200px] flex-1 sm:flex-initial">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-white border border-slate-200 text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:border-sky-500"
                />
                {searchTerm && (
                  <button
                    onClick={() => setSearchTerm('')}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Date Filter */}
              <div className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-700">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value as any)}
                  className="bg-transparent focus:outline-none cursor-pointer"
                >
                  <option value="all">All Time</option>
                  <option value="today">Today</option>
                  <option value="week">This Week</option>
                  <option value="month">This Month</option>
                  <option value="year">This Year</option>
                </select>
              </div>

              {/* Sort Order */}
              <button
                onClick={() =>
                  setSortOrder((prev) => (prev === 'newest' ? 'oldest' : prev === 'oldest' ? 'name' : 'newest'))
                }
                className="flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                <span className="capitalize">Sort: {sortOrder}</span>
              </button>
            </div>
          </div>

          {dbError && (
            <div role="alert" className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
              Database error: {dbError}
            </div>
          )}

          {/* Dashboards / Reports Cards Grid */}
          {filteredDashboards.length === 0 ? (
            <EmptyState
              icon={<LayoutGrid className="w-7 h-7" />}
              title={dashboards.length === 0 ? 'Nothing here yet' : 'No matches'}
              description={
                searchTerm || dateFilter !== 'all' || typeFilter !== 'all'
                  ? 'Clear the search or filters to see all of your workspaces.'
                  : 'Create your first interactive dashboard or printable report. It will be saved to your database automatically.'
              }
              action={
                <Button variant="primary" size="lg" icon={<Plus className="w-4 h-4" />} onClick={() => setIsCreateModalOpen(true)}>
                  Create a canvas
                </Button>
              }
            />
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filteredDashboards.map((dash) => {
                const isReportItem =
                  dash.type === 'report' ||
                  dash.canvas.presetName.toLowerCase().includes('report') ||
                  dash.canvas.presetName.toLowerCase().includes('a4') ||
                  dash.canvas.presetName.toLowerCase().includes('letter');
                const widgetCount = dash.widgets?.length || 0;
                const datasetCount = new Set([...(dash.selectedDatasetIds || []), ...(dash.datasets || []).map((d) => d.id)]).size;
                const modelTables = hasActiveDataModel(dash.dataModel)
                  ? (dash.dataModel!.factTables.length + dash.dataModel!.dimensionTables.length)
                  : 0;

                return (
                  <Card
                    key={dash.id}
                    interactive
                    padded={false}
                    onClick={() => onOpenDashboard(dash.id)}
                    className="group cursor-pointer flex flex-col justify-between relative overflow-hidden"
                  >
                    <div className={cx('h-1.5', isReportItem ? 'bg-gradient-to-r from-violet-400 to-fuchsia-400' : 'bg-gradient-to-r from-pulse-400 to-volt-500')} />
                    <div className="p-5 space-y-3 flex-1">
                      <div className="flex items-start justify-between">
                        <span className="w-12 h-12 rounded-xl grid place-items-center text-2xl bg-slate-50 border border-slate-100">
                          {dash.thumbnail || (isReportItem ? '📄' : '📊')}
                        </span>
                        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); onOpenDashboard(dash.id); }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-pulse-600 hover:bg-pulse-50 transition-colors cursor-pointer"
                            title="Open"
                            aria-label={`Open ${dash.name}`}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setDashboardToDelete(dash); }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Delete"
                            aria-label={`Delete ${dash.name}`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 mb-1.5">
                          <Badge tone={isReportItem ? 'violet' : 'sky'}>{isReportItem ? 'Report' : 'Dashboard'}</Badge>
                          <span className="text-[10px] font-mono text-slate-400">{dash.canvas.width}×{dash.canvas.height}</span>
                        </div>
                        <h3 className="font-bold text-slate-900 text-[15px] group-hover:text-pulse-600 transition-colors line-clamp-1">{dash.name}</h3>
                        {dash.usedFor && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 mt-1">
                            <Tag className="w-3 h-3 text-pulse-500" />
                            <span className="line-clamp-1">{dash.usedFor}</span>
                          </span>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-1.5 pt-1">
                        <span className="text-[11px] font-semibold text-slate-500 px-2 py-0.5 rounded-md bg-slate-100">{widgetCount} widget{widgetCount === 1 ? '' : 's'}</span>
                        <span className="text-[11px] font-semibold text-slate-500 px-2 py-0.5 rounded-md bg-slate-100">{datasetCount} dataset{datasetCount === 1 ? '' : 's'}</span>
                        {modelTables > 0 && <span className="text-[11px] font-semibold text-violet-600 px-2 py-0.5 rounded-md bg-violet-50">Model · {modelTables} tables</span>}
                      </div>
                    </div>

                    <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-medium text-slate-400 bg-slate-50/60">
                      <span>Created {formatDate(dash.createdAt)}</span>
                      <span className="font-bold text-pulse-600 group-hover:translate-x-0.5 transition-transform">Open →</span>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>

      {/* CREATE DASHBOARD OR REPORT MODAL */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 md:p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <Plus className="w-5 h-5 text-sky-600" />
                <span>Create New Workspace Canvas</span>
              </h2>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDashboard} className="space-y-5">
              {/* Type Selection: Dashboard vs Report */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">Choose Workspace Type *</label>
                <div className="grid grid-cols-2 gap-3">
                  <div
                    onClick={() => {
                      setNewProjectType('dashboard');
                      setCanvasPreset('1920x1080');
                      setSelectedIcon('📊');
                    }}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col items-start gap-2 ${
                      newProjectType === 'dashboard'
                        ? 'border-sky-600 bg-sky-50/70 shadow-sm ring-1 ring-sky-600'
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-xs">
                      <BarChart3 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-black text-xs text-slate-900">Interactive Dashboard</h4>
                      <p className="text-[11px] text-slate-500 font-medium leading-tight mt-1">
                        Widescreen canvas (1920×1080) for real-time telemetry, TV walls, and live metrics grids.
                      </p>
                    </div>
                  </div>

                  <div
                    onClick={() => {
                      setNewProjectType('report');
                      setCanvasPreset('a4_portrait');
                      setSelectedIcon('📄');
                    }}
                    className={`p-4 rounded-2xl border-2 transition-all cursor-pointer flex flex-col items-start gap-2 ${
                      newProjectType === 'report'
                        ? 'border-purple-600 bg-purple-50/70 shadow-sm ring-1 ring-purple-600'
                        : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-black text-xs text-slate-900">Printable Executive Report</h4>
                      <p className="text-[11px] text-slate-500 font-medium leading-tight mt-1">
                        Document page layout (816×1056 A4) for executive summaries, audits, & PDF exports.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Preset Dimensions Selector */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-slate-700">Canvas Dimensions Preset</label>
                {newProjectType === 'dashboard' ? (
                  <select
                    value={canvasPreset}
                    onChange={(e) => setCanvasPreset(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:border-sky-600 focus:bg-white"
                  >
                    <option value="1920x1080">1920×1080 Widescreen Full HD (Recommended for TV / Desktop)</option>
                    <option value="1366x768">1366×768 Laptop Display Canvas</option>
                  </select>
                ) : (
                  <select
                    value={canvasPreset}
                    onChange={(e) => setCanvasPreset(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:border-purple-600 focus:bg-white"
                  >
                    <option value="a4_portrait">A4 Portrait Document (816 × 1056 px) - Standard Print</option>
                    <option value="a4_landscape">A4 Landscape Document (1056 × 816 px) - Wide Report</option>
                    <option value="us_letter">US Letter Executive Report (850 × 1100 px)</option>
                  </select>
                )}
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">
                  {newProjectType === 'report' ? 'Report Name *' : 'Dashboard Name *'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    newProjectType === 'report'
                      ? 'e.g., FY2024 Executive Annual Performance Audit'
                      : 'e.g., Global Sales & Revenue Telemetry'
                  }
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:border-sky-600 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">Used For *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Board of Directors Quarterly Review"
                  value={newUsedFor}
                  onChange={(e) => setNewUsedFor(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold focus:outline-none focus:border-sky-600 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700">Description (optional)</label>
                  <span className="text-[10px] text-slate-400">{newDescription.length} / 500</span>
                </div>
                <textarea
                  maxLength={500}
                  rows={2}
                  placeholder={`Describe what this ${newProjectType} is created for...`}
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium focus:outline-none focus:border-sky-600 focus:bg-white resize-none"
                />
              </div>

              {/* Select Global Datasets Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700">
                    Select Global Datasets Context ({selectedDsIds.length} of {globalDatasets.length})
                  </label>
                  <div className="flex gap-2 text-[11px]">
                    <button
                      type="button"
                      onClick={() => setSelectedDsIds(globalDatasets.map((d) => d.id))}
                      className="text-sky-600 font-bold hover:underline cursor-pointer"
                    >
                      Select All
                    </button>
                    <span>•</span>
                    <button
                      type="button"
                      onClick={() => setSelectedDsIds([])}
                      className="text-slate-500 font-bold hover:underline cursor-pointer"
                    >
                      Clear All
                    </button>
                  </div>
                </div>

                <div className="max-h-36 overflow-y-auto space-y-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                  {globalDatasets.length === 0 ? (
                    <p className="text-[11px] text-slate-400 italic p-1">No global datasets loaded.</p>
                  ) : (
                    globalDatasets.map((ds) => {
                      const isChecked = selectedDsIds.includes(ds.id);
                      return (
                        <div
                          key={ds.id}
                          onClick={() => {
                            if (isChecked) {
                              setSelectedDsIds(selectedDsIds.filter((id) => id !== ds.id));
                            } else {
                              setSelectedDsIds([...selectedDsIds, ds.id]);
                            }
                          }}
                          className={`p-2 rounded-lg border text-xs flex items-center justify-between cursor-pointer transition-all ${
                            isChecked
                              ? 'bg-sky-50/80 border-sky-300 text-sky-950 font-bold'
                              : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300 font-medium'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => {}}
                              className="rounded text-sky-600 focus:ring-sky-500 h-3.5 w-3.5"
                            />
                            <span>{ds.name}</span>
                            <span className="text-[10px] text-slate-400 font-normal">
                              ({(Number(ds?.rowCount ?? (ds as any)?.row_count ?? (ds?.data?.length || 0)) || 0).toLocaleString()} rows • {Number(ds?.columnCount ?? (ds as any)?.column_count ?? (ds?.columns?.length || 0)) || 0} cols)
                            </span>
                          </div>
                          {ds.tags && ds.tags[0] && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-200/60 text-slate-600 font-semibold">
                              {ds.tags[0]}
                            </span>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-bold text-slate-700">Thumbnail Icon</label>
                <div className="flex flex-wrap gap-2">
                  {(newProjectType === 'report'
                    ? ['📄', '📑', '📋', '📁', '📝', '📈', '💼', '🏆']
                    : ['📊', '📈', '📉', '📋', '📁', '🎯', '💼', '🏆']
                  ).map((icon) => (
                    <button
                      key={icon}
                      type="button"
                      onClick={() => setSelectedIcon(icon)}
                      className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center border transition-all ${
                        selectedIcon === icon
                          ? 'border-sky-600 bg-sky-50 shadow-xs scale-105'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2.5 rounded-xl text-white font-bold text-xs shadow-md ${
                    newProjectType === 'report'
                      ? 'bg-purple-600 hover:bg-purple-700 shadow-purple-600/20'
                      : 'bg-sky-600 hover:bg-sky-700 shadow-sky-600/20'
                  }`}
                >
                  Create {newProjectType === 'report' ? 'Report Canvas' : 'Dashboard Canvas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE MODAL */}
      {dashboardToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <AlertTriangle className="w-6 h-6" />
              <h3 className="text-base font-black">Confirm Delete</h3>
            </div>
            <p className="text-xs font-medium text-slate-600 mb-6 leading-relaxed">
              Are you sure you want to delete <strong className="text-slate-900">"{dashboardToDelete.name}"</strong>? This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setDashboardToDelete(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md shadow-rose-600/20"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LOGOUT CONFIRMATION MODAL */}
      {isLogoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 text-slate-900 mb-3">
              <LogOut className="w-6 h-6 text-sky-600" />
              <h3 className="text-base font-black">Logout</h3>
            </div>
            <p className="text-xs font-medium text-slate-600 mb-6 leading-relaxed">
              Are you sure you want to log out of your account?
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setIsLogoutModalOpen(false)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setIsLogoutModalOpen(false);
                  onLogout();
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md shadow-rose-600/20"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
