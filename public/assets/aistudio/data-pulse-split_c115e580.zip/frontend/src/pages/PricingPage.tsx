import React, { useState } from 'react';
import { User } from '../types/auth';
import { MarketingNavbar } from '../components/Navbar/MarketingNavbar';
import { AnimatedBackground } from '../components/AnimatedBackground';
import { BrandLockup } from '../components/BrandLogo';
import {
  Check,
  Zap,
  HelpCircle,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  ChevronDown,
  Building2,
  Users,
  Flame,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  onNavigate: (
    page: 'home' | 'features' | 'pricing' | 'about' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub',
    dashboardId?: string
  ) => void;
}

export const PricingPage: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const isYearly = billingCycle === 'yearly';

  const plans = [
    {
      id: 'free',
      name: 'Starter',
      badge: 'Free Forever',
      price: '$0',
      period: 'per month',
      description: 'Perfect for solo developers, students, and exploring analytical workflows.',
      features: [
        'Up to 5 Global Datasets',
        'Unlimited Dashboards & Reports',
        'Explore the data (Full Cleaning Pipeline)',
        'Basic Star Schema Topology',
        'Standard Chart Widgets & KPIs',
        'Client-side Local Persistence',
        'Community Support',
      ],
      ctaText: 'Get Started Free',
      popular: false,
    },
    {
      id: 'pro',
      name: 'Professional',
      badge: 'Most Popular',
      price: isYearly ? '$24' : '$29',
      period: 'per month',
      originalPrice: isYearly ? '$29' : null,
      description: 'For data analysts, consultants, and fast-moving teams demanding deep modeling power.',
      features: [
        'Unlimited Global Datasets',
        'Full Star Schema Modeling (Facts & Dims)',
        '1-Click DIM_DATE Calendar Dimension Generator',
        'Calculated DAX-Style Measures Engine',
        '3D Surface Charts & Volumetric Widgets',
        'Export to High-Resolution PDF & Reports',
        'Server-Side Workspace Isolation & Cloud Sync',
        'Priority Product Support',
      ],
      ctaText: 'Start 14-Day Free Trial',
      popular: true,
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      badge: 'Scale & Governance',
      price: isYearly ? '$79' : '$99',
      period: 'per month',
      originalPrice: isYearly ? '$99' : null,
      description: 'For companies requiring multi-workspace governance, dedicated database isolation, and SLA.',
      features: [
        'Everything in Professional',
        'Multi-Workspace & Role-Based Access Control',
        'Custom Relational Database Connectors',
        'Unlimited Rows & High-Throughput Processing',
        'Dedicated Cloud Project Isolation',
        'Audit Logging & Security Hardening',
        'Custom Widget Development SDK',
        'Dedicated Support Engineer (99.99% SLA)',
      ],
      ctaText: 'Contact Enterprise',
      popular: false,
    },
  ];

  const faqs = [
    {
      q: 'Can I reuse one dataset across multiple dashboards?',
      a: 'Yes! That is the core architecture of Data Pulse. Datasets live in your Global Data Hub and dashboards only store references (selectedDatasetIds), avoiding redundant data duplication.',
    },
    {
      q: 'Do you offer non-destructive data cleaning?',
      a: 'Yes. Every operation in "Explore the data" generates an Applied Step in an immutable pipeline. You can inspect earlier steps, reorder transformations, or discard steps without altering your original source dataset.',
    },
    {
      q: 'How does Star Schema modeling work in Data Pulse?',
      a: 'You can designate tables as Facts (metrics & foreign keys) and Dimensions (attributes & primary keys). Data Pulse will auto-detect relationships with confidence scores and allow you to define DAX-style calculated measures.',
    },
    {
      q: 'Is my data isolated from other users?',
      a: 'Absolutely. We enforce backend authentication session tokens and isolate dataset storage and queries by authenticated user workspace.',
    },
    {
      q: 'Can I cancel or switch billing plans anytime?',
      a: 'Yes, you can upgrade, downgrade, or cancel your subscription at any time with zero penalty or hidden fees.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col relative selection:bg-sky-500 selection:text-white">
      {/* Animated Glowing Constellation Background */}
      <AnimatedBackground />

      {/* Navigation */}
      <MarketingNavbar currentUser={currentUser} activeNav="pricing" onNavigate={onNavigate} />

      {/* Main Container */}
      <main className="relative z-10 pt-32 pb-24 px-4 sm:px-6 md:px-12 max-w-7xl mx-auto w-full flex-1">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200/80 text-sky-700 text-xs font-bold mb-6 shadow-2xs">
            <Flame className="w-3.5 h-3.5 text-sky-600" />
            <span>Transparent, Value-Driven Pricing</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
            Simple Plans for <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 bg-clip-text text-transparent">
              Every Analytical Scale
            </span>
          </h1>

          <p className="text-slate-600 text-base sm:text-lg leading-relaxed mb-8">
            Start completely free with our full dataset cleaning and dashboard builder.
            Upgrade whenever your team needs dimensional star modeling and cloud sync.
          </p>

          {/* Billing Cycle Switcher */}
          <div className="inline-flex items-center gap-3 p-1.5 bg-slate-200/70 rounded-2xl border border-slate-300/60 shadow-inner">
            <button
              type="button"
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                billingCycle === 'monthly'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                billingCycle === 'yearly'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Annual Billing</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-extrabold uppercase">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20 items-stretch">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`rounded-3xl p-8 flex flex-col justify-between transition-all relative ${
                plan.popular
                  ? 'bg-white border-2 border-sky-500 shadow-2xl shadow-sky-600/15 md:-translate-y-2'
                  : 'bg-white/85 backdrop-blur-xl border border-slate-200/90 shadow-lg hover:shadow-xl'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-sky-600 to-indigo-600 text-white font-extrabold text-[11px] uppercase tracking-wider shadow-sm">
                  {plan.badge}
                </div>
              )}

              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-black text-slate-900">{plan.name}</h3>
                    {!plan.popular && (
                      <span className="text-[11px] font-semibold text-slate-400 font-mono">
                        {plan.badge}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-baseline gap-1.5 mb-4">
                  <span className="text-4xl sm:text-5xl font-black text-slate-900">{plan.price}</span>
                  <span className="text-xs font-semibold text-slate-500">{plan.period}</span>
                  {plan.originalPrice && (
                    <span className="text-xs line-through text-slate-400 font-mono ml-1">
                      {plan.originalPrice}
                    </span>
                  )}
                </div>

                <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                  {plan.description}
                </p>

                <div className="h-px bg-slate-100 mb-6" />

                <div className="space-y-3 mb-8">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Included Capabilities:
                  </span>
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 font-medium">
                      <div className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
                className={`w-full py-3.5 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${
                  plan.popular
                    ? 'bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white shadow-sky-600/25'
                    : 'bg-slate-900 hover:bg-sky-600 text-white'
                }`}
              >
                <span>{plan.ctaText}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        {/* Feature Comparison Highlights Table */}
        <div className="bg-white/90 backdrop-blur-xl border border-slate-200 rounded-3xl p-6 sm:p-10 shadow-lg mb-20 overflow-x-auto">
          <h3 className="text-2xl font-black text-slate-900 mb-6 text-center sm:text-left">
            Compare Plan Capabilities
          </h3>

          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                <th className="py-3 px-4">Feature</th>
                <th className="py-3 px-4">Starter</th>
                <th className="py-3 px-4 text-sky-700">Professional</th>
                <th className="py-3 px-4">Enterprise</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
              <tr>
                <td className="py-3 px-4 font-bold text-slate-900">Reusable Global Datasets</td>
                <td className="py-3 px-4">Up to 5</td>
                <td className="py-3 px-4 text-sky-700 font-bold">Unlimited</td>
                <td className="py-3 px-4">Unlimited + Custom API</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-bold text-slate-900">Explore the Data (Applied Steps)</td>
                <td className="py-3 px-4">Yes</td>
                <td className="py-3 px-4 text-sky-700 font-bold">Yes + Version History</td>
                <td className="py-3 px-4">Yes + Shared Custom Steps</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-bold text-slate-900">Star Schema Modeling</td>
                <td className="py-3 px-4">Basic</td>
                <td className="py-3 px-4 text-sky-700 font-bold">Full Star Topology + Measures</td>
                <td className="py-3 px-4">Full + Multi-Fact Constellation</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-bold text-slate-900">DIM_DATE Calendar Generation</td>
                <td className="py-3 px-4">Manual</td>
                <td className="py-3 px-4 text-sky-700 font-bold">1-Click Auto Generate</td>
                <td className="py-3 px-4">1-Click + Custom Fiscal Calendars</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-bold text-slate-900">User Data Isolation</td>
                <td className="py-3 px-4">Local Workspace</td>
                <td className="py-3 px-4 text-sky-700 font-bold">Server Session Isolation</td>
                <td className="py-3 px-4">Dedicated Multi-Tenant RBAC</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* FAQs Section */}
        <div className="max-w-3xl mx-auto mb-16">
          <div className="text-center mb-10">
            <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mb-2">
              Frequently Asked Questions
            </h3>
            <p className="text-slate-500 text-xs sm:text-sm">
              Clear answers to common questions about our platform and billing.
            </p>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden transition-all shadow-xs"
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    className="w-full p-4.5 text-left font-bold text-slate-900 text-xs sm:text-sm flex items-center justify-between cursor-pointer hover:bg-slate-50 transition-colors"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <div className="px-4.5 pb-4.5 text-slate-600 text-xs leading-relaxed border-t border-slate-100 pt-3">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Callout */}
        <div className="text-center bg-sky-50 border border-sky-200/80 rounded-3xl p-8 max-w-2xl mx-auto">
          <h4 className="font-bold text-slate-900 text-base mb-2">Need a custom enterprise setup?</h4>
          <p className="text-slate-600 text-xs mb-4">
            We work directly with engineering, finance, and enterprise business intelligence teams to migrate legacy Power BI or Tableau instances.
          </p>
          <button
            type="button"
            onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
            className="px-6 py-2.5 rounded-xl bg-slate-900 hover:bg-sky-600 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Speak with an Engineer
          </button>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 bg-slate-950 text-slate-300 py-12 px-6 md:px-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <BrandLockup size={32} textSize="text-lg" />
          <div className="flex gap-6 text-xs font-semibold text-slate-400">
            <button onClick={() => onNavigate('features')} className="hover:text-white transition-colors cursor-pointer">Features</button>
            <button onClick={() => onNavigate('pricing')} className="hover:text-white transition-colors cursor-pointer">Pricing</button>
            <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">About</button>
          </div>
          <p className="text-xs text-slate-500">
            &copy; 2026 Data Pulse. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};
