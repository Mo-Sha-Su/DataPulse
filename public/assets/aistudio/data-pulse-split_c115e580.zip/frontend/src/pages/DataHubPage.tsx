import React, { useMemo, useState } from 'react';
import { User } from '../types/auth';
import { Dataset } from '../types/dashboard';
import Papa from 'papaparse';
import { loadXLSX } from '../utils/xlsxLazy';
import { looksLikeDate } from '../utils/transformationEngine';
import { columnTypeMix, datasetHealth } from '../utils/columnProfile';
import { AppNavbar } from '../components/Navbar/AppNavbar';
import { Badge, Button, Card, EmptyState, PageHeader, StatCard, cx } from '../ui';
import {
  Database, Plus, Search, Sparkles, Table, UploadCloud, Trash2, LayoutGrid, Clock, BarChart3, Wand2, FlaskConical,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  globalDatasets: Dataset[];
  onLogout: () => void;
  onNavigate: (page: 'home' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub', dashboardId?: string) => void;
  onOpenDataCleaning: (datasetId: string) => void;
  onInspectDataset: (dataset: Dataset) => void;
  onAddGlobalDataset: (newDataset: Dataset) => void;
  onDeleteGlobalDataset: (datasetId: string) => void;
  onCreateDashboardWithDataset: (datasetId: string) => void;
}

export const DataHubPage: React.FC<Props> = ({
  currentUser,
  globalDatasets,
  onLogout,
  onNavigate,
  onOpenDataCleaning,
  onInspectDataset,
  onAddGlobalDataset,
  onDeleteGlobalDataset,
  onCreateDashboardWithDataset,
}) => {
  const [search, setSearch] = useState('');
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [isUploading, setIsUploading] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);

  // Extract all unique tags
  const allTags = Array.from(
    new Set(globalDatasets.flatMap((d) => d.tags || []))
  );

  const filteredDatasets = globalDatasets.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(search.toLowerCase()) ||
      (d.description && d.description.toLowerCase().includes(search.toLowerCase()));

    const matchesTag =
      selectedTag === 'all' || (d.tags && d.tags.includes(selectedTag));

    return matchesSearch && matchesTag;
  });

  // File Upload Handler (CSV & XLSX)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const fileName = file.name;
    const isCsv = fileName.endsWith('.csv');

    if (isCsv) {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: (results) => {
          const parsedData = results.data as Record<string, any>[];
          if (parsedData.length > 0) {
            const firstRow = parsedData[0];
            const columns = Object.keys(firstRow).map((key) => {
              const val = firstRow[key];
              let colType: 'number' | 'string' | 'date' = 'string';
              if (typeof val === 'number') colType = 'number';
              else if (typeof val === 'string' && looksLikeDate(val)) colType = 'date';
              return { name: key, type: colType, sampleValue: val };
            });

            const newDataset: Dataset = {
              id: `ds_${Date.now()}`,
              name: fileName.replace(/\.[^/.]+$/, ''),
              description: `Uploaded from ${fileName}`,
              rowCount: parsedData.length,
              columnCount: columns.length,
              uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
              sourceType: 'csv',
              tags: ['Custom Upload', 'CSV'],
              columns,
              data: parsedData,
            };
            onAddGlobalDataset(newDataset);
          }
          setIsUploading(false);
        },
        error: () => setIsUploading(false),
      });
    } else {
      const reader = new FileReader();
      reader.onload = async (evt) => {
        try {
          const bstr = evt.target?.result;
          const XLSX = await loadXLSX();
          const wb = XLSX.read(bstr, { type: 'binary' });
          const wsname = wb.SheetNames[0];
          const ws = wb.Sheets[wsname];
          const parsedData = XLSX.utils.sheet_to_json(ws) as Record<string, any>[];

          if (parsedData.length > 0) {
            const firstRow = parsedData[0];
            const columns = Object.keys(firstRow).map((key) => {
              const val = firstRow[key];
              let colType: 'number' | 'string' | 'date' = 'string';
              if (typeof val === 'number') colType = 'number';
              return { name: key, type: colType, sampleValue: val };
            });

            const newDataset: Dataset = {
              id: `ds_${Date.now()}`,
              name: fileName.replace(/\.[^/.]+$/, ''),
              description: `Imported from Excel sheet: ${wsname}`,
              rowCount: parsedData.length,
              columnCount: columns.length,
              uploadedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
              sourceType: 'excel',
              tags: ['Custom Upload', 'Excel'],
              columns,
              data: parsedData,
            };
            onAddGlobalDataset(newDataset);
          }
        } catch (err) {
          console.error('Error parsing Excel', err);
        } finally {
          setIsUploading(false);
        }
      };
      reader.readAsBinaryString(file);
    }
  };

  const totalRecords = (globalDatasets || []).reduce((acc, d) => {
    const rows = d?.rowCount ?? (d as any)?.row_count ?? (Array.isArray(d?.data) ? d.data.length : 0);
    return acc + (Number(rows) || 0);
  }, 0);
  const totalCleaned = (globalDatasets || []).filter((d) => Boolean(d && d.cleaningPipeline && d.cleaningPipeline.length > 0)).length;

  const uploadInput = (
    <input type="file" accept=".csv,.xlsx,.xls" onChange={handleFileUpload} className="hidden" disabled={isUploading} />
  );

  return (
    <div className="min-h-screen bg-[#f4f6fb] text-slate-900 flex flex-col">
      <AppNavbar
        active="data_hub"
        currentUser={currentUser}
        onNavigate={onNavigate}
        onLogout={onLogout}
        action={
          <Button asLabel variant="primary" icon={<UploadCloud className="w-4 h-4" />}>
            {isUploading ? 'Importing…' : 'Upload dataset'}
            {uploadInput}
          </Button>
        }
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 md:px-10 py-10 space-y-8">
        <PageHeader
          eyebrow="Data Hub"
          title="Your datasets, one source of truth"
          description="Upload once, then profile, clean in the Data Lab, and reuse the same data in any dashboard or report. Every change is saved to your database."
        />

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <StatCard tone="sky" icon={<Database className="w-6 h-6" />} value={globalDatasets.length} label="Datasets" />
          <StatCard tone="violet" icon={<BarChart3 className="w-6 h-6" />} value={(Number(totalRecords) || 0).toLocaleString()} label="Records under management" />
          <StatCard tone="emerald" icon={<Wand2 className="w-6 h-6" />} value={totalCleaned} label="Cleaned in the Data Lab" hint={`${globalDatasets.length - totalCleaned} still raw`} />
        </div>

        <section className="space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search datasets by name or tag…"
                aria-label="Search datasets"
                className="w-full h-10 pl-10 pr-4 bg-white border border-slate-200 rounded-xl text-[13px] font-medium text-slate-900 placeholder-slate-400 focus:outline-2 focus:outline-pulse-500 shadow-2xs"
              />
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0" role="tablist" aria-label="Filter by tag">
              {['all', ...allTags].map((tag) => (
                <button
                  key={tag}
                  type="button"
                  role="tab"
                  aria-selected={selectedTag === tag}
                  onClick={() => setSelectedTag(tag)}
                  className={cx(
                    'h-8 px-3 rounded-lg text-xs font-bold whitespace-nowrap transition-colors cursor-pointer',
                    selectedTag === tag ? 'bg-slate-900 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                  )}
                >
                  {tag === 'all' ? `All · ${globalDatasets.length}` : tag}
                </button>
              ))}
            </div>
          </div>

          {filteredDatasets.length === 0 ? (
            <EmptyState
              icon={<Database className="w-7 h-7" />}
              title={globalDatasets.length === 0 ? 'No datasets yet' : 'Nothing matches your search'}
              description={
                globalDatasets.length === 0
                  ? 'Upload a CSV or Excel file to start. Then open it in the Data Lab to fix messy values step by step.'
                  : 'Try a different name or clear the tag filter.'
              }
              action={
                globalDatasets.length === 0 ? (
                  <Button asLabel variant="primary" size="lg" icon={<UploadCloud className="w-4 h-4" />}>
                    Upload your first dataset
                    {uploadInput}
                  </Button>
                ) : undefined
              }
            />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
              {filteredDatasets.map((ds) => (
                <DatasetCard
                  key={ds.id}
                  ds={ds}
                  onOpenDataCleaning={onOpenDataCleaning}
                  onInspectDataset={onInspectDataset}
                  onCreateDashboardWithDataset={onCreateDashboardWithDataset}
                  onDelete={() => {
                    if (confirm(`Delete dataset '${ds.name}'? This cannot be undone.`)) onDeleteGlobalDataset(ds.id);
                  }}
                />
              ))}
            </div>
          )}
        </section>
      </main>
    </div>
  );
};

const healthTone = (h: number) => (h >= 95 ? 'bg-emerald-500' : h >= 80 ? 'bg-amber-400' : 'bg-rose-500');

interface CardProps {
  ds: Dataset;
  onOpenDataCleaning: (id: string) => void;
  onInspectDataset: (d: Dataset) => void;
  onCreateDashboardWithDataset: (id: string) => void;
  onDelete: () => void;
}

const DatasetCard: React.FC<CardProps> = ({ ds, onOpenDataCleaning, onInspectDataset, onCreateDashboardWithDataset, onDelete }) => {
  const rows = Number(ds?.rowCount ?? (ds as any)?.row_count ?? (Array.isArray(ds?.data) ? ds.data.length : 0)) || 0;
  const cols = Number(ds?.columnCount ?? (ds as any)?.column_count ?? (Array.isArray(ds?.columns) ? ds.columns.length : 0)) || 0;
  const health = useMemo(() => datasetHealth(ds.data || [], (ds.columns || []).map((c) => c.name)), [ds.data, ds.columns]);
  const mix = useMemo(() => columnTypeMix(ds.columns || []), [ds.columns]);
  const steps = ds.cleaningPipeline?.length || 0;
  const totalCols = Math.max(1, mix.text + mix.number + mix.date);

  return (
    <Card interactive padded={false} className="flex flex-col">
      <div className="p-5 space-y-4 flex-1">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-10 h-10 rounded-xl grid place-items-center bg-gradient-to-br from-pulse-50 to-violet-50 text-pulse-600 border border-pulse-100 shrink-0">
              <Table className="w-[18px] h-[18px]" />
            </span>
            <div className="min-w-0">
              <h3 className="font-bold text-[15px] text-slate-900 leading-snug truncate" title={ds.name}>{ds.name}</h3>
              <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                <Clock className="w-3 h-3" /> {ds.uploadedAt}
              </p>
            </div>
          </div>
          <Badge tone="slate">{ds.sourceType || (ds as any)?.source_type || 'csv'}</Badge>
        </div>

        {ds.description && <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">{ds.description}</p>}

        <div className="flex items-baseline gap-4">
          <p className="text-slate-500 text-xs"><b className="text-lg font-extrabold text-slate-900 tabular">{rows.toLocaleString()}</b> rows</p>
          <p className="text-slate-500 text-xs"><b className="text-lg font-extrabold text-slate-900 tabular">{cols}</b> columns</p>
        </div>

        <div>
          <div className="flex h-1.5 rounded-full overflow-hidden bg-slate-100" role="img" aria-label={`${mix.text} text, ${mix.number} number, ${mix.date} date columns`}>
            <span className="bg-slate-400" style={{ width: `${(mix.text / totalCols) * 100}%` }} />
            <span className="bg-pulse-500" style={{ width: `${(mix.number / totalCols) * 100}%` }} />
            <span className="bg-amber-400" style={{ width: `${(mix.date / totalCols) * 100}%` }} />
          </div>
          <p className="mt-1.5 text-[11px] text-slate-400">
            {mix.text} text · {mix.number} number{mix.date ? ` · ${mix.date} date` : ''}
          </p>
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="flex-1">
            <div className="flex justify-between text-[11px] font-semibold text-slate-500 mb-1">
              <span>Data health</span>
              <span className="tabular text-slate-800">{health}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
              <div className={cx('h-full rounded-full', healthTone(health))} style={{ width: `${health}%` }} />
            </div>
          </div>
          {steps > 0 ? <Badge tone="emerald"><Sparkles className="w-3 h-3" /> {steps} step{steps === 1 ? '' : 's'}</Badge> : <Badge tone="amber">Raw</Badge>}
        </div>

        {ds.tags && ds.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {ds.tags.map((t) => (
              <span key={t} className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 font-semibold">{t}</span>
            ))}
          </div>
        )}
      </div>

      <div className="px-4 py-3 border-t border-slate-100 flex items-center gap-2 bg-slate-50/60 rounded-b-2xl">
        <Button variant="primary" size="sm" className="flex-1" onClick={() => onOpenDataCleaning(ds.id)} title="Open in the Data Lab" icon={<FlaskConical className="w-3.5 h-3.5" />}>
          Open in Data Lab
        </Button>
        <Button variant="secondary" size="sm" className="!px-2.5" onClick={() => onInspectDataset(ds)} title="Quick inspect" aria-label="Quick inspect">
          <Table className="w-3.5 h-3.5" />
        </Button>
        <Button variant="lab" size="sm" className="!px-2.5" onClick={() => onCreateDashboardWithDataset(ds.id)} title="Build a dashboard with this dataset" aria-label="Build a dashboard">
          <LayoutGrid className="w-3.5 h-3.5" />
        </Button>
        <Button variant="ghost" size="sm" className="!px-2.5 hover:!text-rose-600 hover:!bg-rose-50" onClick={onDelete} title="Delete dataset" aria-label="Delete dataset">
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </Card>
  );
};
