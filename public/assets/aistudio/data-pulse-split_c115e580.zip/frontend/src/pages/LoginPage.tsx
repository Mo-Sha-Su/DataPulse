import React, { useState } from 'react';
import { Loader2 } from 'lucide-react';
import { loginUser } from '../services/authService';
import { User } from '../types/auth';
import { BrandLockup } from '../components/BrandLogo';

interface Props {
  onLoginSuccess: (user: User) => void;
  onNavigate: (page: any, dashboardId?: string) => void;
}

export const LoginPage: React.FC<Props> = ({ onLoginSuccess, onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!email.trim()) {
      setErrorMsg('Please enter your email address');
      return;
    }
    if (!password) {
      setErrorMsg('Please enter your password');
      return;
    }

    setIsLoading(true);
    try {
      const res = await loginUser(email.trim(), password);
      if (res.success && res.user) {
        onLoginSuccess(res.user);
      } else {
        setErrorMsg(res.detail || res.message || 'Invalid email or password');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Connection error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-50 via-slate-50 to-slate-100 flex items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Top Left Back Button */}
      <button
        onClick={() => onNavigate('home')}
        className="absolute top-6 left-6 z-20 flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur-md border border-slate-200 text-slate-600 hover:text-sky-600 font-semibold text-xs transition-all shadow-xs hover:shadow-md hover:-translate-x-0.5 cursor-pointer"
      >
        <span>Back to home</span>
      </button>

      <div className="w-full max-w-md relative z-10">
        <div className="bg-white/95 backdrop-blur-xl rounded-3xl p-8 md:p-10 shadow-2xl border border-white/80 transition-all">
          {/* Header Logo */}
          <div
            className="flex items-center justify-center mb-8 cursor-pointer"
            onClick={() => onNavigate('home')}
          >
            <BrandLockup size={42} textSize="text-2xl" />
          </div>

          <div className="text-center mb-8">
            <h2 className="text-2xl font-black text-slate-900 tracking-tight mb-1.5">Welcome Back</h2>
            <p className="text-slate-500 text-xs font-medium">
              Enter your credentials to access your dashboard
            </p>
          </div>

          {errorMsg && (
            <div className="mb-6 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-xs font-semibold text-center animate-shake">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">Email Address</label>
              <input
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-sm font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-slate-700">Password</label>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 text-sm font-medium focus:outline-none focus:border-sky-600 focus:bg-white transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white font-bold text-sm shadow-lg shadow-sky-600/25 transition-all hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-75 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Signing in...</span>
                </>
              ) : (
                <span>Sign In</span>
              )}
            </button>
          </form>

          <div className="text-center mt-6 text-xs text-slate-500 font-medium">
            Don't have an account?{' '}
            <button
              onClick={() => onNavigate('signup')}
              className="text-sky-600 hover:text-sky-700 font-bold hover:underline cursor-pointer ml-1"
            >
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
