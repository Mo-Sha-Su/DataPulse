import React from 'react';
import { User } from '../types/auth';
import { MarketingNavbar } from '../components/Navbar/MarketingNavbar';
import { AnimatedBackground } from '../components/AnimatedBackground';
import { BrandLockup } from '../components/BrandLogo';
import {
  ShieldCheck,
  Zap,
  Target,
  Sparkles,
  Layers,
  ArrowRight,
  TrendingUp,
  Cpu,
  Lock,
  Globe2,
  Users2,
  CheckCircle2,
} from 'lucide-react';

interface Props {
  currentUser: User | null;
  onNavigate: (
    page: 'home' | 'features' | 'pricing' | 'about' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub',
    dashboardId?: string
  ) => void;
}

export const AboutPage: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const stats = [
    { label: 'Data Points Modeled', value: '150M+' },
    { label: 'Pipeline Engine Latency', value: '< 12ms' },
    { label: 'Uptime Reliability', value: '99.99%' },
    { label: 'Active Enterprise Dashboards', value: '25,000+' },
  ];

  const pillars = [
    {
      icon: Cpu,
      title: 'Browser-Native Performance',
      desc: 'No heavy backend calculation queues for basic slicers. Data Pulse operates transformation and dimensional joins with instantaneous client-side WebAssembly & TypeScript engines.',
    },
    {
      icon: Layers,
      title: 'Strict Architectural Separation',
      desc: 'Global datasets live in your Data Hub and can be referenced across multiple reports. Dashboards never duplicate massive data payloads.',
    },
    {
      icon: Lock,
      title: 'Zero-Trust User Data Isolation',
      desc: 'We never mix multi-tenant queries. User datasets, dashboard layouts, and star schemas are securely partitioned and authenticated through token-verified server endpoints.',
    },
    {
      icon: Sparkles,
      title: 'Explore the Data & DAX Accessibility',
      desc: 'Get the advanced analytical capabilities of enterprise tools like Power BI and Tableau without the multi-gigabyte desktop software or steep proprietary learning curves.',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col relative selection:bg-sky-500 selection:text-white">
      {/* Animated Glowing Constellation Background */}
      <AnimatedBackground />

      {/* Navigation */}
      <MarketingNavbar currentUser={currentUser} activeNav="about" onNavigate={onNavigate} />

      {/* Hero Section */}
      <main className="relative z-10 pt-32 pb-24 px-4 sm:px-6 md:px-12 max-w-7xl mx-auto w-full flex-1">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-50 border border-sky-200/80 text-sky-700 text-xs font-bold mb-6 shadow-2xs">
            <Target className="w-3.5 h-3.5 text-sky-600" />
            <span>Our Mission & Vision</span>
          </div>

          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-slate-900 leading-[1.1] mb-6">
            Building the Next Generation of <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 bg-clip-text text-transparent">
              Visual Intelligence
            </span>
          </h1>

          <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
            Data Pulse was built with a simple conviction: analyzing business data, designing
            star schemas, and presenting executive insights should be lightning-fast, collaborative, and beautiful.
          </p>
        </div>

        {/* Big Numbers Counter Banner */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-8 rounded-3xl bg-slate-900 text-white shadow-2xl mb-20">
          {stats.map((stat, idx) => (
            <div key={idx} className="text-center p-3">
              <span className="block text-3xl sm:text-4xl lg:text-5xl font-black text-sky-400 mb-1 font-mono">
                {stat.value}
              </span>
              <span className="text-xs sm:text-sm text-slate-400 font-medium">
                {stat.label}
              </span>
            </div>
          ))}
        </div>

        {/* Story & Philosophy Section */}
        <div className="bg-white/90 backdrop-blur-xl border border-slate-200 rounded-3xl p-8 sm:p-12 shadow-xl mb-20 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs font-mono font-bold uppercase text-sky-600 tracking-wider">
              Why We Built Data Pulse
            </span>

            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight leading-snug">
              Spreadsheets are everywhere. Real analytical clarity is not.
            </h2>

            <p className="text-slate-600 text-sm leading-relaxed">
              For decades, business analysts have been caught between two extremes: spreadsheet chaos on one end, and monolithic enterprise BI suites with slow load times, complex licensing, and clunky desktop installs on the other.
            </p>

            <p className="text-slate-600 text-sm leading-relaxed">
              We engineered Data Pulse from first principles to bridge that gap. With a clean browser UI, users can upload raw sales or customer files, inspect them with instant type detection, apply step-by-step cleaning operations, model star schemas with fact and dimension tables, and generate board-ready reports in minutes.
            </p>

            <div className="pt-2 flex items-center gap-3 text-xs font-semibold text-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Full compliance with relational Star Schema specifications</span>
            </div>
            <div className="flex items-center gap-3 text-xs font-semibold text-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Step-by-step pipeline reproducibility & auditability</span>
            </div>
          </div>

          {/* Architecture Illustration Diagram */}
          <div className="lg:col-span-6 bg-slate-950 p-6 sm:p-8 rounded-2xl border border-slate-800 text-white font-mono text-xs shadow-xl space-y-4">
            <div className="text-[11px] text-slate-400 font-bold uppercase tracking-wider pb-2 border-b border-slate-800 flex items-center justify-between">
              <span>Data Pulse Architecture Flow</span>
              <span className="text-sky-400">Strict Data Boundary</span>
            </div>

            <div className="space-y-3 pt-2">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-sky-400 font-bold block text-xs">1. GLOBAL DATA HUB</span>
                  <span className="text-[10px] text-slate-400">Upload CSV/Excel • Ingestion Schema Inference</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-sky-950 text-sky-300 font-mono">Input</span>
              </div>

              <div className="flex justify-center text-slate-600 text-sm">↓</div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-indigo-400 font-bold block text-xs">2. EXPLORE THE DATA</span>
                  <span className="text-[10px] text-slate-400">Applied Steps Pipeline • Type Detection • Column Quality</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 font-mono">Transform</span>
              </div>

              <div className="flex justify-center text-slate-600 text-sm">↓</div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-amber-400 font-bold block text-xs">3. STAR SCHEMA DATA MODEL</span>
                  <span className="text-[10px] text-slate-400">Fact Tables • Dimension Tables • Relationships • Measures</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-mono">Model</span>
              </div>

              <div className="flex justify-center text-slate-600 text-sm">↓</div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-emerald-400 font-bold block text-xs">4. VISUAL DASHBOARDS</span>
                  <span className="text-[10px] text-slate-400">Selected Dataset Binding • Interactive Widgets • PDF Export</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono">Output</span>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Architectural Pillars */}
        <div className="mb-20">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-3">
              Our Core Principles
            </h3>
            <p className="text-slate-500 text-sm">
              The foundational engineering choices behind every feature in Data Pulse.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {pillars.map((pillar, idx) => {
              const Icon = pillar.icon;
              return (
                <div
                  key={idx}
                  className="p-8 rounded-2xl bg-white border border-slate-200/90 shadow-xs hover:shadow-lg hover:border-sky-300 transition-all flex gap-5 items-start"
                >
                  <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0 border border-sky-200/60">
                    <Icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-2">{pillar.title}</h4>
                    <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">{pillar.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* CTA Card */}
        <div className="bg-gradient-to-r from-sky-600 to-indigo-700 rounded-3xl p-8 sm:p-12 text-center text-white shadow-xl">
          <div className="max-w-2xl mx-auto space-y-4">
            <h3 className="text-2xl sm:text-4xl font-black tracking-tight">
              Start Building with Data Pulse Today
            </h3>
            <p className="text-sky-100 text-sm leading-relaxed">
              No credit card required. Explore our sample dashboards or upload your first dataset in seconds.
            </p>
            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
                className="w-full sm:w-auto px-8 py-3.5 bg-white text-slate-900 font-extrabold rounded-xl text-sm transition-all hover:bg-slate-100 shadow-md cursor-pointer"
              >
                Create Free Account
              </button>
              <button
                type="button"
                onClick={() => onNavigate('features')}
                className="w-full sm:w-auto px-6 py-3.5 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl text-sm transition-all border border-sky-400/30 cursor-pointer"
              >
                Explore All Features
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 bg-slate-950 text-slate-300 py-12 px-6 md:px-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <BrandLockup size={32} textSize="text-lg" />
          <div className="flex gap-6 text-xs font-semibold text-slate-400">
            <button onClick={() => onNavigate('features')} className="hover:text-white transition-colors cursor-pointer">Features</button>
            <button onClick={() => onNavigate('pricing')} className="hover:text-white transition-colors cursor-pointer">Pricing</button>
            <button onClick={() => onNavigate('about')} className="hover:text-white transition-colors cursor-pointer">About</button>
          </div>
          <p className="text-xs text-slate-500">
            &copy; 2026 Data Pulse. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};
