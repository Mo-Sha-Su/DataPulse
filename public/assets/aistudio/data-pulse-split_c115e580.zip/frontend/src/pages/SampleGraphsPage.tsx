import React, { useState } from 'react';
import { User } from '../types/auth';
import { BrandLockup } from '../components/BrandLogo';
import {
  BarChart3,
  TrendingUp,
  PieChart as PieChartIcon,
  Activity,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Info,
  Layers,
  CheckCircle2,
  Sliders,
} from 'lucide-react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Bar, Line, Pie, Scatter } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface Props {
  currentUser: User | null;
  onNavigate: (page: 'home' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs', dashboardId?: string) => void;
}

type CategoryFilter = 'all' | 'comparison' | 'trends' | 'composition' | 'kpi';

interface SampleGraphItem {
  id: string;
  title: string;
  category: CategoryFilter;
  categoryLabel: string;
  badgeColor: string;
  renderChart: () => React.ReactNode;
  summary: string;
  bestUseCases: string[];
  keyInsight: string;
}

export const SampleGraphsPage: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryFilter>('all');
  const [activeTab, setActiveTab] = useState<'preview' | 'details'>('preview');

  const sampleGraphs: SampleGraphItem[] = [
    {
      id: 'bar_chart',
      title: 'Bar Chart: Regional Sales & Revenue',
      category: 'comparison',
      categoryLabel: 'Comparison',
      badgeColor: 'bg-sky-100 text-sky-700 border-sky-200',
      renderChart: () => (
        <div className="w-full h-64 sm:h-72">
          <Bar
            data={{
              labels: ['North America', 'Europe', 'Asia Pacific', 'Latin America', 'Middle East'],
              datasets: [
                {
                  label: 'Q1 Revenue ($K)',
                  data: [120, 95, 140, 60, 45],
                  backgroundColor: '#3B82F6',
                  borderRadius: 6,
                },
                {
                  label: 'Q2 Target ($K)',
                  data: [140, 110, 160, 75, 55],
                  backgroundColor: '#93C5FD',
                  borderRadius: 6,
                },
              ],
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } } },
                tooltip: { backgroundColor: '#0F172A', padding: 10, cornerRadius: 8 },
              },
              scales: {
                x: { grid: { display: false }, ticks: { font: { size: 11 } } },
                y: { grid: { color: '#E2E8F0' }, ticks: { font: { size: 11 } } },
              },
            }}
          />
        </div>
      ),
      summary:
        'Bar charts excel at comparing discrete categorical metrics across groups. Using vertical rectangular bars, stakeholders can quickly spot top-performing segments and regional discrepancies at a single glance.',
      bestUseCases: [
        'Comparing revenue across regional markets or store locations',
        'Benchmarking quarterly department targets vs actual performance',
        'Displaying discrete survey results or product category counts',
      ],
      keyInsight:
        'Use bar charts when category labels are distinct and comparison precision is paramount. Avoid over-cluttering with more than 8-10 bars.',
    },
    {
      id: 'line_chart',
      title: 'Line Chart: Monthly Active User Growth',
      category: 'trends',
      categoryLabel: 'Trends & Series',
      badgeColor: 'bg-indigo-100 text-indigo-700 border-indigo-200',
      renderChart: () => (
        <div className="w-full h-64 sm:h-72">
          <Line
            data={{
              labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
              datasets: [
                {
                  label: 'Active Users (k)',
                  data: [12.4, 14.2, 18.5, 22.1, 28.0, 35.4, 42.1, 51.0, 58.6, 64.2],
                  borderColor: '#6366F1',
                  backgroundColor: 'rgba(99, 102, 241, 0.1)',
                  fill: true,
                  tension: 0.35,
                  pointRadius: 4,
                  pointHoverRadius: 6,
                },
              ],
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } } },
                tooltip: { backgroundColor: '#0F172A', padding: 10, cornerRadius: 8 },
              },
              scales: {
                x: { grid: { display: false }, ticks: { font: { size: 11 } } },
                y: { grid: { color: '#E2E8F0' }, ticks: { font: { size: 11 } } },
              },
            }}
          />
        </div>
      ),
      summary:
        'Line charts visualize continuous data over consecutive time intervals, illustrating growth momentum, seasonal velocity, and directional trends cleanly without distracting visual noise.',
      bestUseCases: [
        'Tracking product adoption and daily/monthly active user growth',
        'Monitoring operational uptime, website traffic, or sensor telemetry',
        'Evaluating financial market trajectories and stock performance',
      ],
      keyInsight:
        'Line charts reveal acceleration and deceleration. Connecting data points with smooth splines emphasizes continuity over discrete jumps.',
    },
    {
      id: 'area_chart',
      title: 'Area Chart: Financial Revenue vs Expenses',
      category: 'trends',
      categoryLabel: 'Trends & Series',
      badgeColor: 'bg-blue-100 text-blue-700 border-blue-200',
      renderChart: () => (
        <div className="w-full h-64 sm:h-72">
          <Line
            data={{
              labels: ['Q1 2024', 'Q2 2024', 'Q3 2024', 'Q4 2024', 'Q1 2025', 'Q2 2025'],
              datasets: [
                {
                  label: 'Gross Revenue ($K)',
                  data: [450, 580, 720, 890, 1100, 1350],
                  borderColor: '#10B981',
                  backgroundColor: 'rgba(16, 185, 129, 0.25)',
                  fill: true,
                  tension: 0.3,
                },
                {
                  label: 'Operating Expenses ($K)',
                  data: [320, 390, 480, 540, 620, 710],
                  borderColor: '#F43F5E',
                  backgroundColor: 'rgba(244, 63, 94, 0.15)',
                  fill: true,
                  tension: 0.3,
                },
              ],
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } } },
                tooltip: { backgroundColor: '#0F172A', padding: 10, cornerRadius: 8 },
              },
              scales: {
                x: { grid: { display: false }, ticks: { font: { size: 11 } } },
                y: { grid: { color: '#E2E8F0' }, ticks: { font: { size: 11 } } },
              },
            }}
          />
        </div>
      ),
      summary:
        'Area charts highlight the volumetric gap between multiple data streams. By shading the space beneath trendlines, they clearly show cumulative growth and margin expansions.',
      bestUseCases: [
        'Demonstrating net profit margins by comparing revenue vs expense areas',
        'Visualizing cumulative bandwidth consumption or cloud storage usage',
        'Analyzing stacked market share evolution across multiple products',
      ],
      keyInsight:
        'The filled area conveys total volume, making it easy for viewers to visualize profit buffers between revenue and cost ceilings.',
    },
    {
      id: 'donut_chart',
      title: 'Donut Chart: Customer Tier Distribution',
      category: 'composition',
      categoryLabel: 'Composition',
      badgeColor: 'bg-emerald-100 text-emerald-700 border-emerald-200',
      renderChart: () => (
        <div className="w-full h-64 sm:h-72 flex items-center justify-center">
          <Pie
            data={{
              labels: ['Enterprise Tier', 'Mid-Market', 'Small Business', 'Free Self-Serve'],
              datasets: [
                {
                  data: [42, 28, 18, 12],
                  backgroundColor: ['#2563EB', '#38BDF8', '#34D399', '#F59E0B'],
                  borderWidth: 2,
                  borderColor: '#FFFFFF',
                },
              ],
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { position: 'right', labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } } },
                tooltip: { backgroundColor: '#0F172A', padding: 10, cornerRadius: 8 },
              },
              cutout: '65%',
            }}
          />
        </div>
      ),
      summary:
        'Donut charts display proportional component breakdowns of a whole (100%). The hollow center provides clean negative space for highlighting overall totals or key summaries.',
      bestUseCases: [
        'Breaking down customer account distribution or subscriber tiers',
        'Displaying budget allocation percentages across departments',
        'Showing device OS market share or referral traffic sources',
      ],
      keyInsight:
        'Best constrained to 3-6 distinct segments. Order categories from largest to smallest slice for maximum readability.',
    },
    {
      id: 'scatter_plot',
      title: 'Scatter Plot: Customer Satisfaction vs LTV',
      category: 'comparison',
      categoryLabel: 'Comparison',
      badgeColor: 'bg-amber-100 text-amber-700 border-amber-200',
      renderChart: () => (
        <div className="w-full h-64 sm:h-72">
          <Scatter
            data={{
              datasets: [
                {
                  label: 'Accounts (CSAT vs LTV)',
                  data: [
                    { x: 4.2, y: 15 },
                    { x: 5.8, y: 28 },
                    { x: 6.5, y: 34 },
                    { x: 7.1, y: 52 },
                    { x: 7.8, y: 68 },
                    { x: 8.4, y: 85 },
                    { x: 8.9, y: 110 },
                    { x: 9.2, y: 135 },
                    { x: 9.6, y: 160 },
                    { x: 6.0, y: 22 },
                    { x: 7.5, y: 48 },
                    { x: 8.1, y: 76 },
                  ],
                  backgroundColor: '#EC4899',
                  pointRadius: 6,
                  pointHoverRadius: 9,
                },
              ],
            }}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              plugins: {
                legend: { position: 'top', labels: { boxWidth: 12, font: { size: 11, weight: 'bold' } } },
                tooltip: { backgroundColor: '#0F172A', padding: 10, cornerRadius: 8 },
              },
              scales: {
                x: {
                  title: { display: true, text: 'CSAT Score (1-10)', font: { size: 11, weight: 'bold' } },
                  grid: { color: '#E2E8F0' },
                },
                y: {
                  title: { display: true, text: 'Annual LTV ($K)', font: { size: 11, weight: 'bold' } },
                  grid: { color: '#E2E8F0' },
                },
              },
            }}
          />
        </div>
      ),
      summary:
        'Scatter plots display individual data points mapped across two numeric axes, uncovering mathematical correlations, clusters, anomalies, and statistical distributions.',
      bestUseCases: [
        'Analyzing the correlation between satisfaction scores and contract size',
        'Mapping marketing spend vs conversion volume per campaign',
        'Identifying performance outliers in operational efficiency metrics',
      ],
      keyInsight:
        'Perfect for detecting positive or negative relationships between independent metrics before running formal regressions.',
    },
    {
      id: 'kpi_card',
      title: 'KPI Executive Card & Directional Metrics',
      category: 'kpi',
      categoryLabel: 'Executive KPI',
      badgeColor: 'bg-purple-100 text-purple-700 border-purple-200',
      renderChart: () => (
        <div className="w-full h-64 sm:h-72 flex flex-col justify-center gap-3">
          <div className="p-4 rounded-xl bg-slate-900 text-white shadow-md border border-slate-800 flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-400 font-medium">Monthly Recurring Revenue</div>
              <div className="text-3xl font-black text-white tracking-tight mt-1">$148,920.00</div>
              <div className="text-xs font-bold text-emerald-400 mt-1 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" /> +18.4% vs previous month
              </div>
            </div>
            <div className="w-24 h-12">
              <Line
                data={{
                  labels: ['1', '2', '3', '4', '5', '6'],
                  datasets: [
                    {
                      data: [110, 118, 125, 132, 140, 148],
                      borderColor: '#10B981',
                      borderWidth: 2.5,
                      pointRadius: 0,
                      fill: false,
                    },
                  ],
                }}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false }, tooltip: { enabled: false } },
                  scales: { x: { display: false }, y: { display: false } },
                }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">Net Churn Rate</div>
              <div className="text-xl font-extrabold text-slate-900 mt-0.5">0.84%</div>
              <div className="text-[11px] font-semibold text-sky-600 mt-0.5">-0.12% improvement</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
              <div className="text-xs text-slate-500 font-medium">CAC Payback</div>
              <div className="text-xl font-extrabold text-slate-900 mt-0.5">5.2 Months</div>
              <div className="text-[11px] font-semibold text-emerald-600">Top decile efficiency</div>
            </div>
          </div>
        </div>
      ),
      summary:
        'Executive KPI cards present top-line metrics with zero visual clutter. Combining oversized numerical indicators with sparklines offers immediate clarity for leadership updates.',
      bestUseCases: [
        'Executive dashboards requiring immediate status checks',
        'Mobile summary views for founders, investors, and product leads',
        'Highlighting single-number targets against quarterly benchmarks',
      ],
      keyInsight:
        'Pair big bold numbers with directional delta indicators (+%) and mini sparklines for immediate context without context switching.',
    },
  ];

  const filteredGraphs =
    selectedCategory === 'all'
      ? sampleGraphs
      : sampleGraphs.filter((g) => g.category === selectedCategory);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col selection:bg-sky-500 selection:text-white">
      {/* Top Navigation Header */}
      <nav className="fixed top-0 left-0 right-0 h-18 bg-white/95 backdrop-blur-md border-b border-slate-200/80 z-50 flex items-center justify-between px-4 sm:px-6 md:px-12 transition-all shadow-xs">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="flex items-center text-left focus-visible:outline-2 focus-visible:outline-indigo-500 rounded-lg cursor-pointer"
          title="Data Pulse Home"
          aria-label="Data Pulse Home"
        >
          <BrandLockup size={36} textSize="text-xl" />
        </button>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => onNavigate('home')}
            className="h-9 px-3.5 rounded-xl text-slate-700 hover:text-sky-600 border border-slate-200 hover:border-slate-300 font-bold text-xs transition-all flex items-center gap-2 focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
            title="Back to Home"
            aria-label="Back to Home"
          >
            <ArrowLeft className="w-4 h-4 shrink-0" />
            <span>Back to Home</span>
          </button>
          <button
            type="button"
            onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
            className="h-9 px-4 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 active:scale-[0.98] text-white font-bold text-xs shadow-sm shadow-sky-600/20 transition-all flex items-center gap-2 focus-visible:outline-2 focus-visible:outline-indigo-500 cursor-pointer"
            title="Launch Canvas"
            aria-label="Launch Canvas"
          >
            <span>Launch Canvas</span>
            <ArrowRight className="w-4 h-4 shrink-0" />
          </button>
        </div>
      </nav>

      {/* Main Container */}
      <main className="pt-28 pb-20 px-4 sm:px-6 md:px-12 max-w-7xl mx-auto w-full flex-1">
        {/* Header Banner */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 border border-sky-200 text-sky-700 font-bold text-xs mb-4">
            <Sparkles className="w-3.5 h-3.5 text-sky-600" />
            <span>Interactive Chart Gallery & Usage Guide</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 tracking-tight leading-tight mb-4">
            Sample Visualizations & <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 bg-clip-text text-transparent">
              When to Use Each Graph
            </span>
          </h1>
          <p className="text-slate-600 text-base sm:text-lg font-normal">
            Explore our curated catalog of analytical charts. Every sample features an interactive rendered preview accompanied by detailed explanations on practical use cases and best practices.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center justify-center gap-2 flex-wrap mb-12">
          {[
            { id: 'all', label: 'All Graphs' },
            { id: 'comparison', label: 'Comparison' },
            { id: 'trends', label: 'Trends & Series' },
            { id: 'composition', label: 'Composition' },
            { id: 'kpi', label: 'Executive KPIs' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as CategoryFilter)}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Graph Cards Grid (Interactive chart on left/top, detailed paragraph beside it) */}
        <div className="space-y-8">
          {filteredGraphs.map((graph) => (
            <div
              key={graph.id}
              className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-xl transition-all overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-0"
            >
              {/* Left Column: Interactive Graph Preview */}
              <div className="lg:col-span-6 p-6 sm:p-8 bg-slate-50/70 border-b lg:border-b-0 lg:border-r border-slate-200/80 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span
                      className={`inline-block px-3 py-1 rounded-md border font-bold text-xs uppercase tracking-wider ${graph.badgeColor}`}
                    >
                      {graph.categoryLabel}
                    </span>
                    <span className="text-xs text-slate-400 font-semibold flex items-center gap-1">
                      <Sliders className="w-3.5 h-3.5" /> Interactive Demo
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-6">{graph.title}</h3>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                  {graph.renderChart()}
                </div>
              </div>

              {/* Right Column: Explanatory Paragraph & Best Use Cases */}
              <div className="lg:col-span-6 p-6 sm:p-8 flex flex-col justify-between bg-white">
                <div>
                  <div className="flex items-center gap-2 text-sky-600 font-bold text-xs uppercase tracking-wider mb-2">
                    <Info className="w-4 h-4" /> Usage & Analytical Purpose
                  </div>
                  <h4 className="text-lg font-extrabold text-slate-900 mb-3">
                    Overview & Definition
                  </h4>
                  <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-6 font-normal">
                    {graph.summary}
                  </p>

                  <h5 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide mb-3 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Best Use Cases
                  </h5>
                  <ul className="space-y-2 mb-6 text-sm text-slate-700">
                    {graph.bestUseCases.map((useCase, idx) => (
                      <li key={idx} className="flex items-start gap-2.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-sky-500 mt-2 shrink-0" />
                        <span className="font-medium">{useCase}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Key Insight Box */}
                <div className="p-4 rounded-xl bg-sky-50 border border-sky-100 text-sky-900 text-xs sm:text-sm leading-relaxed">
                  <span className="font-bold text-sky-800 block mb-0.5">💡 Pro Tip:</span>
                  {graph.keyInsight}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Call to Action */}
        <div className="mt-16 p-8 sm:p-12 rounded-3xl bg-slate-900 text-white text-center flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-2xl sm:text-3xl font-black mb-4">
              Ready to create your own customized charts?
            </h3>
            <p className="text-slate-300 text-sm sm:text-base mb-8">
              Build drag-and-drop metrics, import custom spreadsheets, and generate interactive executive dashboards in seconds.
            </p>
            <button
              onClick={() => onNavigate(currentUser ? 'dashboard_hub' : 'signup')}
              className="px-8 py-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-600 hover:to-indigo-600 text-white font-extrabold text-base shadow-lg shadow-sky-500/25 transition-all hover:scale-105 flex items-center gap-2 mx-auto"
            >
              <span>Build Your Dashboard Now</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-8 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <BrandLockup size={28} textSize="text-base" />
          <p>© {new Date().getFullYear()} Data Pulse Inc. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};
