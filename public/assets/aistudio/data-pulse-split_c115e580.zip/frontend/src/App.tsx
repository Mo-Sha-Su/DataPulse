import React, { useState, useEffect, useCallback, useMemo, useRef, lazy, Suspense, ComponentType } from 'react';
import { DashboardState, Widget, WidgetType, WidgetCategory, WidgetConfig, Dataset, CanvasSettings, DataFilter } from './types/dashboard';
import { User } from './types/auth';
import { fetchSessionUser, logoutUser, SESSION_EXPIRED_EVENT } from './services/authService';
import { createEmptyDashboard, DEFAULT_CANVAS, DEFAULT_REPORT_CANVAS } from './data/sampleDashboards';
import { WIDGET_DEFINITIONS } from './data/widgetDefinitions';
import { useHistory } from './hooks/useHistory';
import { saveDashboardToDb, fetchDashboardsFromDb, deleteDashboardFromDb } from './services/dbService';


import { LeftSidebar } from './components/Sidebar/LeftSidebar';
import { TopToolbar } from './components/Toolbar/TopToolbar';
import { GlobalFilterBar } from './components/Toolbar/GlobalFilterBar';
import { CanvasWorkspace } from './components/Canvas/CanvasWorkspace';
import { RightConfigPanel } from './components/Sidebar/RightConfigPanel';
import { DatasetPreviewModal } from './components/Modals/DatasetPreviewModal';
import { ManageDashboardsModal } from './components/Modals/ManageDashboardsModal';
import { SelectDatasetsModal } from './components/Modals/SelectDatasetsModal';
import { fetchGlobalDatasets, saveGlobalDataset, deleteGlobalDataset, invalidateDatasetsCache } from './services/globalDatasetService';
import { DataModelState } from './types/dataModel';
import { syncModelWithUsedDatasets } from './utils/dataModelingEngine';
import { EyeOff } from 'lucide-react';


/** Route-level code splitting for named exports. */
function lazyNamed<T extends Record<string, any>, K extends keyof T>(load: () => Promise<T>, name: K) {
  return lazy(async () => ({ default: (await load())[name] as ComponentType<any> }));
}

const HomePage = lazyNamed(() => import('./pages/HomePage'), 'HomePage');
const FeaturesPage = lazyNamed(() => import('./pages/FeaturesPage'), 'FeaturesPage');
const PricingPage = lazyNamed(() => import('./pages/PricingPage'), 'PricingPage');
const AboutPage = lazyNamed(() => import('./pages/AboutPage'), 'AboutPage');
const LoginPage = lazyNamed(() => import('./pages/LoginPage'), 'LoginPage');
const SignupPage = lazyNamed(() => import('./pages/SignupPage'), 'SignupPage');
const DashboardHubPage = lazyNamed(() => import('./pages/DashboardHubPage'), 'DashboardHubPage');
const SampleGraphsPage = lazyNamed(() => import('./pages/SampleGraphsPage'), 'SampleGraphsPage');
const DataCleaningEditorPage = lazyNamed(() => import('./pages/DataCleaningEditorPage'), 'DataCleaningEditorPage');
const DataHubPage = lazyNamed(() => import('./pages/DataHubPage'), 'DataHubPage');
const DataModelWorkspace = lazyNamed(() => import('./components/DataModel/DataModelWorkspace'), 'DataModelWorkspace');
const ExportPdfModal = lazyNamed(() => import('./components/Modals/ExportPdfModal'), 'ExportPdfModal');

type PageView = 'home' | 'features' | 'pricing' | 'about' | 'login' | 'signup' | 'dashboard_hub' | 'bench' | 'sample_graphs' | 'data_hub';

function AppInner() {
  const [activePage, setActivePage] = useState<PageView>('home');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [activeDashboardId, setActiveDashboardId] = useState<string | null>(null);

  // The bench starts empty; saved work is loaded from the database when a dashboard is opened from the hub.
  const loadInitialState = (): DashboardState => createEmptyDashboard();

  const {
    currentState: dashboard,
    pushState,
    undo,
    redo,
    canUndo,
    canRedo,
  } = useHistory(loadInitialState());

  const [selectedWidgetId, setSelectedWidgetId] = useState<string | null>(null);
  const [configuringWidgetId, setConfiguringWidgetId] = useState<string | null>(null);
  const [inspectedDataset, setInspectedDataset] = useState<Dataset | null>(null);
  const [isDataCleaningOpen, setIsDataCleaningOpen] = useState(false);
  const [targetCleaningDatasetId, setTargetCleaningDatasetId] = useState<string | undefined>(undefined);
  const [isDashboardManagerOpen, setIsDashboardManagerOpen] = useState(false);
  const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
  const [isExportPdfModalOpen, setIsExportPdfModalOpen] = useState(false);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  const [savedDashboards, setSavedDashboards] = useState<DashboardState[]>([]);
  const [globalDatasets, setGlobalDatasets] = useState<Dataset[]>([]);
  const [activeWorkspaceView, setActiveWorkspaceView] = useState<'canvas' | 'data_model'>('canvas');
  const [isSelectDatasetsOpen, setIsSelectDatasetsOpen] = useState(false);

  // Restore the session from the server (httpOnly cookie -> /api/auth/me), then load this user's data from the database.
  useEffect(() => {
    let cancelled = false;
    fetchSessionUser().then((user) => {
      if (cancelled) return;
      setCurrentUser(user);
      setAuthChecked(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!currentUser) return;
    fetchGlobalDatasets()
      .then((ds) => setGlobalDatasets(ds))
      .catch((e) => console.warn('Failed to load datasets from database', e));
    fetchDashboardsFromDb()
      .then((items) => setSavedDashboards(items))
      .catch((e) => console.warn('Failed to load dashboards from database', e));
  }, [currentUser]);

  const autoSaveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Debounced Auto-Save to backend database
  const triggerAutoSave = useCallback((stateToSave: DashboardState) => {
    setAutoSaveStatus('saving');
    if (autoSaveTimeoutRef.current) {
      clearTimeout(autoSaveTimeoutRef.current);
    }
    autoSaveTimeoutRef.current = setTimeout(async () => {
      try {
        await saveDashboardToDb(stateToSave);
        setAutoSaveStatus('saved');
      } catch (err) {
        console.error('Failed to auto-save to database', err);
        setAutoSaveStatus('unsaved');
      }
    }, 1200);
  }, []);

  // Immediate save to the database (Ctrl+S / Save button): cancels the pending debounce.
  const saveNow = useCallback(async (state: DashboardState) => {
    if (autoSaveTimeoutRef.current) clearTimeout(autoSaveTimeoutRef.current);
    setAutoSaveStatus('saving');
    try {
      await saveDashboardToDb(state);
      setAutoSaveStatus('saved');
    } catch (err) {
      console.error('Failed to save to database', err);
      setAutoSaveStatus('unsaved');
    }
  }, []);

  const updateDashboardState = (updater: (prev: DashboardState) => DashboardState) => {
    const newState = updater(dashboard);
    const updatedWithTime = { ...newState, updatedAt: new Date().toISOString() };
    pushState(updatedWithTime);
    triggerAutoSave(updatedWithTime);
  };

  // Open specific dashboard from Hub
  // Dashboards saved by older versions (or other clients) can miss canvas fields such as zoom; fill the gaps.
  const withCanvasDefaults = (d: DashboardState): DashboardState => ({ ...d, canvas: { ...DEFAULT_CANVAS, ...(d.canvas || {}) } });

  const handleOpenDashboardFromHub = async (dashboardId: string) => {
    setActiveDashboardId(dashboardId);

    try {
      const dbItems = await fetchDashboardsFromDb();
      const target = dbItems.find((d) => d.id === dashboardId);
      if (target) {
        pushState(withCanvasDefaults(target));
        setActivePage('bench');
        return;
      }
    } catch (e) {
      console.warn('Error reading dashboard from database', e);
    }

    const fromState = savedDashboards.find((d) => d.id === dashboardId);
    if (fromState) {
      pushState(withCanvasDefaults(fromState));
      setActivePage('bench');
      return;
    }

    // Not in the database yet (e.g. just created): start it empty; auto-save will persist it.
    pushState(createEmptyDashboard(dashboardId, 'New Dashboard'));
    setActivePage('bench');
  };

  const handleNavigate = (page: PageView, dashboardId?: string) => {
    if (dashboardId) {
      handleOpenDashboardFromHub(dashboardId);
    } else {
      setActivePage(page);
    }
  };

  const handleLoginSuccess = (user: User) => {
    invalidateDatasetsCache();
    setGlobalDatasets([]);
    setCurrentUser(user); // triggers the database load of this user's datasets and dashboards
    setActivePage('dashboard_hub');
  };

  const handleLogout = async () => {
    await logoutUser(); // clears the session cookie on the server
    invalidateDatasetsCache();
    setCurrentUser(null);
    setActivePage('home');
    // Hard reload so no in-memory data (datasets, dashboards, undo history) survives into the next session.
    window.location.assign('/');
  };

  // Session expired / rejected by the API: send the user back to sign in (everything is already saved in the database).
  useEffect(() => {
    const onExpired = () => {
      invalidateDatasetsCache();
      setCurrentUser(null);
      setActivePage('login');
    };
    window.addEventListener(SESSION_EXPIRED_EVENT, onExpired);
    return () => window.removeEventListener(SESSION_EXPIRED_EVENT, onExpired);
  }, []);

  // Keyboard Shortcuts
  useEffect(() => {
    if (activePage !== 'bench') return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isPreviewMode) setIsPreviewMode(false);
        setSelectedWidgetId(null);
        setConfiguringWidgetId(null);
        setInspectedDataset(null);
        setIsDashboardManagerOpen(false);
        return;
      }

      if (e.ctrlKey || e.metaKey) {
        if (e.key.toLowerCase() === 'z') {
          e.preventDefault();
          if (canUndo) undo();
        } else if (e.key.toLowerCase() === 'y') {
          e.preventDefault();
          if (canRedo) redo();
        } else if (e.key.toLowerCase() === 's') {
          e.preventDefault();
          saveNow(dashboard);
        } else if (e.shiftKey && e.key.toLowerCase() === 'f') {
          e.preventDefault();
          setIsPreviewMode((prev) => !prev);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [canUndo, canRedo, undo, redo, dashboard, isPreviewMode, activePage]);

  // Widget addition
  const handleAddWidget = (type: WidgetType, categoryArg?: WidgetCategory) => {
    const def = WIDGET_DEFINITIONS.find((w) => w.type === type);
    const category = (categoryArg ?? def?.category) as WidgetCategory;
    if (!def && !categoryArg) return; // unknown widget type: never create a blank widget
    const activeDataset = resolvedDashboardDatasets[0] || dashboard.datasets[0];

    const currentPages = dashboard.pages && dashboard.pages.length > 0
      ? dashboard.pages
      : [{ id: 'p_1', name: 'Page 1' }];
    const activePageId = dashboard.activePageId || currentPages[0].id;

    const newWidget: Widget = {
      id: `w_${type}_${Date.now()}`,
      type,
      category,
      title: def?.name || 'New Widget',
      pageId: activePageId,
      position: {
        x: 60 + (dashboard.widgets.length % 5) * 40,
        y: 60 + (dashboard.widgets.length % 5) * 40,
        width: def?.defaultWidth || 420,
        height: def?.defaultHeight || 300,
        zIndex: dashboard.widgets.length + 1,
      },
      config: {
        datasetId: activeDataset?.id || '',
        xAxisField: activeDataset?.columns[0]?.name || '',
        yAxisField: activeDataset?.columns[1]?.name || activeDataset?.columns[0]?.name || '',
        aggregation: 'sum',
        numberFormat: 'number',
        currencySymbol: '$',
        title: def?.name || 'New Widget',
        titleColor: '#1E293B',
        primaryColor: '#3B82F6',
        colorPalette: ['#3B82F6', '#10B981', '#F59E0B', '#EC4899'],
        backgroundColor: '#FFFFFF',
      },
    };

    updateDashboardState((prev) => ({
      ...prev,
      widgets: [...prev.widgets, newWidget],
    }));

    setSelectedWidgetId(newWidget.id);
  };

  // New Document Handlers (Empty Canvas referencing Global Datasets)
  const handleNewDashboard = () => {
    const newDash: DashboardState = {
      id: `dashboard_${Date.now()}`,
      name: 'Untitled Dashboard',
      description: 'New custom empty dashboard workspace',
      type: 'dashboard',
      usedFor: 'Dashboard',
      thumbnail: '📊',
      widgets: [],
      datasets: [],
      selectedDatasetIds: [],
      canvas: { ...DEFAULT_CANVAS },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastAccessed: new Date().toISOString(),
    };
    pushState(newDash);
    setSelectedWidgetId(null);
    setConfiguringWidgetId(null);
    setActivePage('bench');
    triggerAutoSave(newDash);
    // Prompt dataset selection context
    setIsSelectDatasetsOpen(true);
  };

  const handleNewReport = () => {
    const newReport: DashboardState = {
      id: `report_${Date.now()}`,
      name: 'Untitled Report',
      description: 'New custom empty report document',
      type: 'report',
      usedFor: 'Report',
      thumbnail: '📄',
      widgets: [],
      datasets: [],
      selectedDatasetIds: [],
      canvas: { ...DEFAULT_REPORT_CANVAS },
      pages: [{ id: 'p_1', name: 'Page 1' }],
      activePageId: 'p_1',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastAccessed: new Date().toISOString(),
    };
    pushState(newReport);
    setSelectedWidgetId(null);
    setConfiguringWidgetId(null);
    setActivePage('bench');
    triggerAutoSave(newReport);
    // Prompt dataset selection context
    setIsSelectDatasetsOpen(true);
  };

  // Report Page Handlers
  const handleAddPage = () => {
    const newPageId = `p_${Date.now()}`;
    const existingPages = dashboard.pages && dashboard.pages.length > 0
      ? dashboard.pages
      : [{ id: 'p_1', name: 'Page 1' }];
    const newPageName = `Page ${existingPages.length + 1}`;
    const newPages = [...existingPages, { id: newPageId, name: newPageName }];

    updateDashboardState((prev) => ({
      ...prev,
      pages: newPages,
      activePageId: newPageId,
    }));
  };

  const handleSelectPage = (pageId: string) => {
    updateDashboardState((prev) => ({
      ...prev,
      activePageId: pageId,
    }));
    setSelectedWidgetId(null);
    setConfiguringWidgetId(null);
  };

  const handleRenamePage = (pageId: string, newName: string) => {
    updateDashboardState((prev) => ({
      ...prev,
      pages: (prev.pages || []).map((p) => (p.id === pageId ? { ...p, name: newName } : p)),
    }));
  };

  const handleDeletePage = (pageId: string) => {
    const currentPages = dashboard.pages || [];
    if (currentPages.length <= 1) return;
    const remainingPages = currentPages.filter((p) => p.id !== pageId);
    const nextActivePageId = remainingPages[0].id;

    updateDashboardState((prev) => ({
      ...prev,
      pages: remainingPages,
      activePageId: nextActivePageId,
      widgets: prev.widgets.filter((w) => w.pageId !== pageId),
    }));
    setSelectedWidgetId(null);
    setConfiguringWidgetId(null);
  };

  const handleUpdateWidgetPosition = (
    widgetId: string,
    x: number,
    y: number,
    width: number,
    height: number
  ) => {
    updateDashboardState((prev) => ({
      ...prev,
      widgets: prev.widgets.map((w) =>
        w.id === widgetId ? { ...w, position: { ...w.position, x, y, width, height } } : w
      ),
    }));
  };

  const handleDuplicateWidget = (widgetId: string) => {
    const target = dashboard.widgets.find((w) => w.id === widgetId);
    if (!target) return;

    const dup: Widget = {
      ...target,
      id: `w_${target.type}_${Date.now()}`,
      title: `${target.title} (Copy)`,
      position: {
        ...target.position,
        x: target.position.x + 30,
        y: target.position.y + 30,
        zIndex: dashboard.widgets.length + 1,
      },
    };

    updateDashboardState((prev) => ({
      ...prev,
      widgets: [...prev.widgets, dup],
    }));

    setSelectedWidgetId(dup.id);
  };

  const handleDeleteWidget = (widgetId: string) => {
    updateDashboardState((prev) => ({
      ...prev,
      widgets: prev.widgets.filter((w) => w.id !== widgetId),
    }));
    if (selectedWidgetId === widgetId) {
      setSelectedWidgetId(null);
    }
    if (configuringWidgetId === widgetId) {
      setConfiguringWidgetId(null);
    }
  };

  const handleUpdateWidgetConfig = (widgetId: string, updatedConfig: WidgetConfig) => {
    updateDashboardState((prev) => ({
      ...prev,
      widgets: prev.widgets.map((w) =>
        w.id === widgetId ? { ...w, title: updatedConfig.title, config: updatedConfig } : w
      ),
    }));
  };

  const handleUpdateCanvas = (updatedCanvas: Partial<CanvasSettings>) => {
    updateDashboardState((prev) => ({
      ...prev,
      canvas: { ...prev.canvas, ...updatedCanvas },
    }));
  };

  // A dataset added from inside a dashboard (upload, generated dimension) is stored in the database first;
  // the dashboard then only references it.
  const handleAddDataset = async (newDs: Dataset) => {
    try {
      const saved = await saveGlobalDataset(newDs);
      setGlobalDatasets((prev) => [saved, ...prev.filter((d) => d.id !== saved.id)]);
      updateDashboardState((prev) => ({
        ...prev,
        datasets: [saved, ...prev.datasets.filter((d) => d.id !== saved.id)],
        selectedDatasetIds: Array.from(new Set([saved.id, ...(prev.selectedDatasetIds || [])])),
      }));
    } catch (err: any) {
      console.error('Failed to save dataset to the database', err);
      window.alert(`The dataset could not be saved to the database, so it was not added.\n\n${err?.message || ''}`);
    }
  };

  const handleDeleteDataset = (datasetId: string) => {
    updateDashboardState((prev) => ({
      ...prev,
      datasets: prev.datasets.filter((d) => d.id !== datasetId),
    }));
    if (inspectedDataset?.id === datasetId) {
      setInspectedDataset(null);
    }
  };

  const handleUpdateGlobalFilters = (globalFilters: DataFilter[]) => {
    updateDashboardState((prev) => ({
      ...prev,
      globalFilters,
    }));
  };

  // Resolved dashboard datasets (referencing user-uploaded datasets only, no sample data fallbacks)
  const resolvedDashboardDatasets = useMemo(() => {
    // 1. Build lookup pool of user-uploaded datasets
    const pool = new Map<string, Dataset>();
    (dashboard.datasets || []).forEach((d) => pool.set(d.id, d));
    globalDatasets.forEach((d) => pool.set(d.id, d));

    // 2. Identify all datasets used in this dashboard
    const usedIds = new Set<string>();

    if (dashboard.selectedDatasetIds && dashboard.selectedDatasetIds.length > 0) {
      dashboard.selectedDatasetIds.forEach((id) => usedIds.add(id));
    }
    if (dashboard.datasets && dashboard.datasets.length > 0) {
      dashboard.datasets.forEach((d) => usedIds.add(d.id));
    }
    if (dashboard.widgets && dashboard.widgets.length > 0) {
      dashboard.widgets.forEach((w) => {
        if (w.config?.datasetId) {
          usedIds.add(w.config.datasetId);
        }
      });
    }
    if (dashboard.globalFilters && dashboard.globalFilters.length > 0) {
      dashboard.globalFilters.forEach((f) => {
        if (f.datasetId) usedIds.add(f.datasetId);
      });
    }
    if (dashboard.dataModel) {
      dashboard.dataModel.factTables.forEach((f) => {
        if (f.datasetId) usedIds.add(f.datasetId);
      });
      dashboard.dataModel.dimensionTables.forEach((d) => {
        if (d.datasetId) usedIds.add(d.datasetId);
      });
    }

    // If specific datasets are selected or used by widgets/filters/model, resolve them
    if (usedIds.size > 0) {
      const matched: Dataset[] = [];
      usedIds.forEach((id) => {
        const found = pool.get(id);
        if (found) matched.push(found);
      });
      if (matched.length > 0) return matched;
    }

    if (dashboard.datasets && dashboard.datasets.length > 0) {
      return dashboard.datasets;
    }
    return [];
  }, [
    dashboard.selectedDatasetIds,
    dashboard.widgets,
    dashboard.globalFilters,
    dashboard.datasets,
    dashboard.dataModel,
    globalDatasets,
  ]);

  const handleSelectDatasetIds = (selectedIds: string[]) => {
    const selected = globalDatasets.filter((d) => selectedIds.includes(d.id));
    updateDashboardState((prev) => ({
      ...prev,
      selectedDatasetIds: selectedIds,
      datasets: selected,
      // The Data Model follows the attached datasets: new ones get fact/dimension tables and relationships.
      dataModel: syncModelWithUsedDatasets(prev.dataModel, selected, prev.name),
    }));
  };

  const handleUpdateDataModel = (model: DataModelState) => {
    updateDashboardState((prev) => ({
      ...prev,
      dataModel: model,
    }));
  };

  // Keep the Data Model in step with the data the dashboard really uses. Covers dashboards saved before the model
  // existed (or with an empty one) and datasets that arrive after the dashboard was opened. syncModelWithUsedDatasets
  // returns the same object when nothing needs to change, so this settles after one pass.
  useEffect(() => {
    if (activePage !== 'bench' || resolvedDashboardDatasets.length === 0) return;
    const synced = syncModelWithUsedDatasets(dashboard.dataModel, resolvedDashboardDatasets, dashboard.name);
    if (synced !== dashboard.dataModel) {
      updateDashboardState((prev) => ({ ...prev, dataModel: synced }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePage, resolvedDashboardDatasets, dashboard.dataModel]);

  const handleAddGlobalDataset = async (newDs: Dataset) => {
    const saved = await saveGlobalDataset(newDs);
    setGlobalDatasets((prev) => [saved, ...prev.filter((d) => d.id !== saved.id)]);
  };

  const handleDeleteGlobalDataset = async (datasetId: string) => {
    await deleteGlobalDataset(datasetId);
    setGlobalDatasets((prev) => prev.filter((d) => d.id !== datasetId));
    if (inspectedDataset?.id === datasetId) setInspectedDataset(null);
  };

  const handleCreateDashboardWithDataset = (datasetId: string) => {
    const targetDs = globalDatasets.find((d) => d.id === datasetId);
    const name = targetDs ? `${targetDs.name} Analytics` : 'New Dashboard';
    const newDash: DashboardState = {
      id: `dash_${Date.now()}`,
      name,
      description: `Analytical workspace for ${targetDs?.name || 'dataset'}`,
      type: 'dashboard',
      usedFor: 'Business Intelligence',
      thumbnail: '📊',
      widgets: [],
      datasets: targetDs ? [targetDs] : globalDatasets,
      selectedDatasetIds: targetDs ? [targetDs.id] : undefined,
      dataModel: syncModelWithUsedDatasets(undefined, targetDs ? [targetDs] : globalDatasets, name),
      canvas: DEFAULT_CANVAS,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastAccessed: new Date().toISOString(),
    };
    pushState(newDash);
    setActivePage('bench');
    setActiveWorkspaceView('canvas');
  };

  const handleOpenDataCleaning = (datasetId?: string) => {
    setTargetCleaningDatasetId(datasetId);
    setIsDataCleaningOpen(true);
  };

  // Saves to the database FIRST; the editor only closes once everything is stored, so a failed save never loses work.
  const handleApplyCleanedDatasets = async (updatedDatasets: Dataset[]) => {
    const saved: Dataset[] = [];
    try {
      for (const ds of updatedDatasets) saved.push(await saveGlobalDataset(ds));
    } catch (e: any) {
      console.error('Failed to save cleaned dataset to database', e);
      window.alert(`Your changes could not be saved to the database, so nothing was applied. The Data Lab stays open so you don't lose your work.\n\n${e?.message || ''}`);
      return;
    }
    // use the database's complete record (tags, description…), not the editor's partial copy
    setGlobalDatasets((prev) => {
      const byId = new Map(saved.map((d) => [d.id, d]));
      return prev.map((d) => byId.get(d.id) || d);
    });
    // Only touch the dashboard when one is open: from the Data Hub there is just an empty placeholder, and updating
    // it would auto-save a blank "New Dashboard" into the database.
    if (activePage === 'bench') updateDashboardState((prev) => ({ ...prev, datasets: saved }));
    setIsDataCleaningOpen(false);
    setTargetCleaningDatasetId(undefined);
  };

  // The Data Lab (pipeline studio) is a full-screen overlay that can be opened from the Data Hub and from the canvas.
  const dataCleaningOverlay = isDataCleaningOpen ? (
    <div className="fixed inset-0 z-50 flex flex-col bg-lab-bg">
      <Suspense fallback={<div className="flex-1 flex items-center justify-center text-sm text-slate-200">Opening the Data Lab…</div>}>
        <DataCleaningEditorPage
          initialDatasets={globalDatasets}
          targetDatasetId={targetCleaningDatasetId}
          onApplyAndClose={handleApplyCleanedDatasets}
          onClose={() => {
            setIsDataCleaningOpen(false);
            setTargetCleaningDatasetId(undefined);
          }}
        />
      </Suspense>
    </div>
  ) : null;

  // ROUTING VIEW RENDERERS
  if (!authChecked) {
    return <div className="min-h-screen flex items-center justify-center text-sm text-gray-500">Loading…</div>;
  }

  if (activePage === 'home') {
    return <HomePage currentUser={currentUser} onNavigate={handleNavigate} />;
  }

  if (activePage === 'features') {
    return <FeaturesPage currentUser={currentUser} onNavigate={handleNavigate} />;
  }

  if (activePage === 'pricing') {
    return <PricingPage currentUser={currentUser} onNavigate={handleNavigate} />;
  }

  if (activePage === 'about') {
    return <AboutPage currentUser={currentUser} onNavigate={handleNavigate} />;
  }

  if (activePage === 'login') {
    return <LoginPage onLoginSuccess={handleLoginSuccess} onNavigate={handleNavigate} />;
  }

  if (activePage === 'signup') {
    return <SignupPage onLoginSuccess={handleLoginSuccess} onNavigate={handleNavigate} />;
  }

  if (activePage === 'dashboard_hub') {
    return (
      <DashboardHubPage
        currentUser={currentUser}
        onLogout={handleLogout}
        onOpenDashboard={handleOpenDashboardFromHub}
        onNavigate={handleNavigate}
        globalDatasets={globalDatasets}
      />
    );
  }

  if (activePage === 'data_hub') {
    return (
      <>
      {/* the hub stays mounted under the editor (keeps scroll/filters) but must not be reachable while it is covered */}
      <div inert={isDataCleaningOpen} aria-hidden={isDataCleaningOpen}>
      <DataHubPage
        currentUser={currentUser}
        globalDatasets={globalDatasets}
        onLogout={handleLogout}
        onNavigate={handleNavigate}
        onOpenDataCleaning={(id) => handleOpenDataCleaning(id)}
        onInspectDataset={(ds) => setInspectedDataset(ds)}
        onAddGlobalDataset={handleAddGlobalDataset}
        onDeleteGlobalDataset={handleDeleteGlobalDataset}
        onCreateDashboardWithDataset={handleCreateDashboardWithDataset}
      />
      </div>
      {dataCleaningOverlay}
      </>
    );
  }

  if (activePage === 'sample_graphs') {
    return <SampleGraphsPage currentUser={currentUser} onNavigate={handleNavigate} />;
  }

  // BENCH / CANVAS WORKSPACE
  const currentPages = dashboard.pages && dashboard.pages.length > 0
    ? dashboard.pages
    : [{ id: 'p_1', name: 'Page 1: Executive Overview' }];
  const activePageId = dashboard.activePageId || currentPages[0].id;

  const selectedWidget = dashboard.widgets.find((w) => w.id === selectedWidgetId) || null;
  const configuringWidget = dashboard.widgets.find((w) => w.id === configuringWidgetId) || null;
  const activeFiltersCount = (dashboard.globalFilters || []).filter((f) => f.enabled !== false && f.column).length;

  return (
    <div className="w-screen h-screen bg-slate-100 flex flex-col overflow-hidden text-slate-900 font-sans antialiased select-none">
      {/* Top Navigation & Toolbar */}
      {!isPreviewMode && (
        <TopToolbar
          dashboardTitle={dashboard.name}
          projectType={dashboard.type}
          pages={currentPages}
          activePageId={activePageId}
          widgetCount={dashboard.widgets.length}
          autoSaveStatus={autoSaveStatus}
          canvas={dashboard.canvas}
          canUndo={canUndo}
          canRedo={canRedo}
          activeFilterCount={activeFiltersCount}
          activeWorkspaceView={activeWorkspaceView}
          onChangeWorkspaceView={(v) => setActiveWorkspaceView(v)}
          onOpenSelectDatasets={() => setIsSelectDatasetsOpen(true)}
          onBackToHub={() => setActivePage('dashboard_hub')}
          onOpenFilters={() => setIsFilterModalOpen(true)}
          onExportPdf={() => setIsExportPdfModalOpen(true)}
          onUndo={undo}
          onRedo={redo}
          onTitleChange={(newTitle) => updateDashboardState((prev) => ({ ...prev, name: newTitle }))}
          onUpdateCanvas={handleUpdateCanvas}
          onTogglePreviewMode={() => setIsPreviewMode(true)}
          onSaveDashboard={() => saveNow(dashboard)}
          onOpenDashboardManager={() => setIsDashboardManagerOpen(true)}
          onNewDashboard={handleNewDashboard}
          onNewReport={handleNewReport}
          onAddPage={handleAddPage}
          onSelectPage={handleSelectPage}
          onRenamePage={handleRenamePage}
          onDeletePage={handleDeletePage}
          onAddWidget={handleAddWidget}
          onOpenDataCleaning={() => handleOpenDataCleaning()}
        />
      )}

      {/* Global Data Filter Bar */}
      {!isPreviewMode && activeWorkspaceView === 'canvas' && (
        <GlobalFilterBar
          datasets={resolvedDashboardDatasets}
          globalFilters={dashboard.globalFilters || []}
          onUpdateGlobalFilters={handleUpdateGlobalFilters}
          isModalOpenExternal={isFilterModalOpen}
          onCloseModalExternal={() => setIsFilterModalOpen(false)}
        />
      )}

      {/* Workspace Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Sidebar */}
        {!isPreviewMode && activeWorkspaceView === 'canvas' && (
          <LeftSidebar
            datasets={resolvedDashboardDatasets}
            onAddDataset={handleAddDataset}
            onSelectDatasetToInspect={(ds) => setInspectedDataset(ds)}
            onAddWidgetToCanvas={handleAddWidget}
            onDeleteDataset={handleDeleteDataset}
            onOpenDataCleaning={handleOpenDataCleaning}
            onOpenSelectDatasets={() => setIsSelectDatasetsOpen(true)}
            onOpenDataModel={() => setActiveWorkspaceView('data_model')}
          />
        )}

        {/* Main Canvas Workspace OR Star Schema Data Model */}
        {activeWorkspaceView === 'data_model' ? (
          <DataModelWorkspace
            dataModel={dashboard.dataModel}
            datasets={resolvedDashboardDatasets}
            dashboardName={dashboard.name}
            onUpdateModel={handleUpdateDataModel}
            onAddDatasetToContext={handleAddGlobalDataset}
            onBackToCanvas={() => setActiveWorkspaceView('canvas')}
            onOpenDataCleaning={handleOpenDataCleaning}
          />
        ) : (
          <CanvasWorkspace
            widgets={dashboard.widgets}
            datasets={resolvedDashboardDatasets}
            canvas={dashboard.canvas}
            pages={currentPages}
            activePageId={activePageId}
            globalFilters={dashboard.globalFilters || []}
            dataModel={dashboard.dataModel}
            selectedWidgetId={selectedWidgetId}
            configuringWidgetId={configuringWidgetId}
            isPreviewMode={isPreviewMode}
            onSelectWidget={(id) => {
              setSelectedWidgetId(id);
              if (id === null) {
                setConfiguringWidgetId(null);
              }
            }}
            onUpdateWidgetPosition={handleUpdateWidgetPosition}
            onDuplicateWidget={handleDuplicateWidget}
            onDeleteWidget={handleDeleteWidget}
            onOpenWidgetConfig={(id) => {
              setSelectedWidgetId(id);
              setConfiguringWidgetId((prev) => (prev === id ? null : id));
            }}
            onUpdateCanvas={handleUpdateCanvas}
          />
        )}

        {/* Right Configuration Drawer - only opens when user clicks the gear icon */}
        {!isPreviewMode && configuringWidget && (
          <RightConfigPanel
            widget={configuringWidget}
            datasets={resolvedDashboardDatasets}
            dataModel={dashboard.dataModel}
            onUpdateWidgetConfig={handleUpdateWidgetConfig}
            onClose={() => setConfiguringWidgetId(null)}
          />
        )}

        {/* Distraction-Free Preview Floating Controls */}
        {isPreviewMode && (
          <div className="fixed top-4 right-4 z-50 flex items-center gap-2">
            <button
              onClick={() => setIsPreviewMode(false)}
              className="py-2 px-4 bg-white/95 border border-slate-300 hover:border-sky-500 text-slate-800 font-bold text-xs rounded-xl shadow-2xl backdrop-blur flex items-center gap-2 transition-all hover:scale-105 cursor-pointer"
            >
              <EyeOff className="w-4 h-4 text-rose-500" />
              <span>Exit Preview (ESC)</span>
            </button>
          </div>
        )}
      </div>

      {/* Dataset Inspection Modal */}
      {inspectedDataset && (
        <DatasetPreviewModal
          dataset={inspectedDataset}
          onClose={() => setInspectedDataset(null)}
          onOpenDataCleaning={handleOpenDataCleaning}
        />
      )}

      {dataCleaningOverlay}

      {/* Select Datasets Modal */}
      <SelectDatasetsModal
        isOpen={isSelectDatasetsOpen}
        globalDatasets={globalDatasets}
        selectedDatasetIds={dashboard.selectedDatasetIds || resolvedDashboardDatasets.map((d) => d.id)}
        currentDashboard={dashboard}
        onClose={() => setIsSelectDatasetsOpen(false)}
        onApplySelection={handleSelectDatasetIds}
      />

      {/* Dashboard Manager Modal */}
      {isDashboardManagerOpen && (
        <ManageDashboardsModal
          currentDashboard={dashboard}
          savedDashboards={savedDashboards}
          onLoadDashboard={(loaded) => pushState(loaded)}
          onDeleteDashboard={(id) => {
            deleteDashboardFromDb(id)
              .then(() => setSavedDashboards((prev) => prev.filter((s) => s.id !== id)))
              .catch((e) => console.error('Failed to delete dashboard from database', e));
          }}
          onImportDashboardJson={(imported) => pushState(imported)}
          onClose={() => setIsDashboardManagerOpen(false)}
        />
      )}

      {/* PDF Export Options Modal */}
      <ExportPdfModal
        isOpen={isExportPdfModalOpen}
        dashboard={dashboard}
        activePageId={activePageId}
        onClose={() => setIsExportPdfModalOpen(false)}
        onUpdateCanvasSettings={handleUpdateCanvas}
      />
    </div>
  );
}

export default function App() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-slate-50 text-sm text-slate-400">Loading…</div>
      }
    >
      <AppInner />
    </Suspense>
  );
}
