import { z } from 'zod';

export const idSchema = z.string().min(1).max(128);

export const registerSchema = z.object({
  email: z.string().trim().toLowerCase().max(254).pipe(z.email('Enter a valid email address')),
  password: z.string().min(8, 'Password must be at least 8 characters').max(128),
  first_name: z.string().trim().max(100).optional(),
  last_name: z.string().trim().max(100).optional(),
  role: z.string().trim().max(50).optional(),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().min(1).max(254),
  password: z.string().min(1).max(128),
});

export const datasetSchema = z.looseObject({
  id: idSchema,
  name: z.string().trim().min(1).max(255),
  description: z.string().max(5000).optional(),
  columns: z.array(z.any()).optional(),
  data: z.array(z.any()).optional(),
  cleanedData: z.array(z.any()).nullable().optional(),
  cleaningPipeline: z.array(z.any()).optional(),
  tags: z.array(z.string().max(100)).max(100).optional(),
});

export const datasetUpdateSchema = datasetSchema.partial().extend({ name: datasetSchema.shape.name.optional() });

export const versionSchema = z.object({
  transformation_steps: z.array(z.any()).optional(),
  row_count: z.number().int().nonnegative().optional(),
  column_count: z.number().int().nonnegative().optional(),
});

export const dashboardSchema = z.looseObject({
  id: idSchema,
  name: z.string().max(255).optional(),
});

export const modelSchema = z.looseObject({
  id: idSchema,
  name: z.string().max(255).optional(),
});

export const settingsSchema = z.object({
  preferences: z.record(z.string(), z.any()).optional(),
  theme: z.string().max(20).optional(),
});
