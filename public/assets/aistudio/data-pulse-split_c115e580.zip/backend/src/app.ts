import compression from 'compression';
import cors from 'cors';
import express, { Express } from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { config } from './config';
import apiRouter from './routes/index';
import { errorHandler, requestContext } from './middleware/errors';
import { crossSiteGuard, noStore } from './middleware/security';

const limiterBase = {
  standardHeaders: 'draft-7' as const,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests. Please slow down and try again shortly.', code: 'rate_limited' },
};

export function createApp(): Express {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);

  app.use(requestContext);

  if (config.cspMode !== 'off') {
    app.use(
      helmet({
        contentSecurityPolicy: {
          reportOnly: config.cspMode === 'report-only',
          useDefaults: false,
          directives: {
            defaultSrc: ["'self'"],
            scriptSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
            fontSrc: ["'self'", 'data:'],
            connectSrc: ["'self'"],
            workerSrc: ["'self'", 'blob:'],
            objectSrc: ["'none'"],
            baseUri: ["'self'"],
            formAction: ["'self'"],
            frameAncestors: ["'none'"],
          },
        },
        crossOriginEmbedderPolicy: false,
      })
    );
  } else {
    app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
  }

  app.use(compression());

  if (config.allowedOrigins.length > 0) {
    app.use('/api', cors({ origin: config.allowedOrigins, credentials: false, maxAge: 600 }));
  }

  app.use('/api', noStore);
  app.use('/api', crossSiteGuard);
  app.use('/api', express.json({ limit: config.maxBodyBytes }));

  if (!config.isTest) {
    app.use('/api', rateLimit({ ...limiterBase, windowMs: 15 * 60_000, limit: 3000 }));
    app.use('/api/auth/login', rateLimit({ ...limiterBase, windowMs: 15 * 60_000, limit: 10, skipSuccessfulRequests: true }));
    app.use('/api/auth/register', rateLimit({ ...limiterBase, windowMs: 60 * 60_000, limit: 10 }));
  }

  app.use('/api', apiRouter);
  app.use(errorHandler);
  return app;
}

export default createApp;
