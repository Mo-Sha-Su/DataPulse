# Data Pulse – Dashboard Builder

No-code analytics studio: import CSV/Excel, clean data with a step-based editor, model relationships/measures,
and build dashboards and reports (2D, 3D, KPI widgets, PDF export).

**Stack:** React 19 + Vite + Tailwind 4 (frontend) · Express 4 (API + static hosting) · PostgreSQL (any provider, incl. Neon).

## Repository layout
```
frontend/   React 19 + Vite + Tailwind 4 app (own package.json)
backend/    Express API + PostgreSQL (own package.json)
Dockerfile  builds both and ships one image (API also hosts the built frontend)
```

## Quick start (development)
Run the two apps in separate terminals:

```bash
# 1) API  -> http://localhost:3000   (migrations run automatically)
cd backend
cp .env.example .env        # set DATABASE_URL (and JWT_SECRET)
npm install
npm run dev

# 2) UI   -> http://localhost:5173   (proxies /api to the API)
cd frontend
npm install
npm run dev
```
Set `VITE_API_PROXY` if the API is not on `http://localhost:3000`.

| Where | Command | What it does |
|---|---|---|
| backend | `npm run dev` | API with auto-restart |
| backend | `npm run build` / `npm start` | Bundle to `dist/server.cjs` / run it (`NODE_ENV=production`) |
| backend | `npm test` | Vitest. Needs Postgres: `TEST_DATABASE_URL=postgresql://user:pass@localhost:5432/dp_test npm test` |
| backend | `npx tsx scripts/set-password.ts <email> '<new password>'` | Admin password reset (no self-service flow yet) |
| frontend | `npm run dev` / `npm run build` | Vite dev server / production bundle in `frontend/dist` |
| both | `npm run lint` | TypeScript check |

## Connecting Neon
1. In the Neon console open **Connect**, copy the connection string (pooled or direct both work).
2. `cd backend && cp .env.example .env`, then set `DATABASE_URL=<that string>` and `JWT_SECRET=$(openssl rand -hex 48)`.
3. `npm run dev` - the log shows `Migrations applied` (first run) and `/api/ready` returns `{"status":"ready"}` when the database is reachable.

The app is pooler-safe: migrations use a transaction-scoped advisory lock and no unsupported startup parameters are sent, so
Neon's `-pooler` endpoint (PgBouncer, transaction mode) works. The first request after Neon suspends an idle compute can take a few seconds.
If the database already contains tables from an older version of the app, migration `003_legacy_schema_repair` adds missing columns/defaults and relaxes unknown required columns on startup (covered by `legacy-schema.test.ts`).
Never commit `.env`; rotate the Neon password if it was ever shared.

## Data Lab (data preparation) and UI system
- **Data Lab** replaces the old Power Query-style editor. It is a pipeline studio: a **pipeline rail** on the left shows every step with what it did to the data (`−2 rows`, `30 empty filled`) and lets you jump back to any step; the **command bar** groups every transformation (Clean / Rows / Columns / Compute) and **Ctrl/⌘ K** opens a searchable palette of all of them; the **Inspector** profiles the selected column and offers **Smart fixes** found from the real values (stray spaces, mixed capitalisation, empty cells, numbers or dates stored as text, duplicate rows). Every fix is a normal, visible, reversible step. Opening it from the Data Hub or the canvas works the same way.
- **What Apply stores:** the cleaned rows, the column order and a cleaning log (the steps performed, accumulated across sessions) in PostgreSQL. The editor only closes after the database confirms the save.
- **Shared UI:** design tokens live in `frontend/src/index.css` (`@theme`), reusable components in `frontend/src/ui/` (`Button`, `Card`, `StatCard`, `Badge`, `EmptyState`, `PageHeader`, `Segmented`), and one `AppNavbar` serves every signed-in page. Fonts are self-hosted (Plus Jakarta Sans, JetBrains Mono) so the strict CSP needs no external hosts.

## Storage & security checklist
- **Where data lives:** accounts, datasets (and their cleaning versions), dashboards, data models and settings are in PostgreSQL. Datasets are stored once; dashboards hold only references to them. Counts are computed from stored rows.
- **Nothing in the browser:** no `localStorage`/`sessionStorage`/IndexedDB/cookies written by scripts/service workers (enforced by `frontend/src/test/noBrowserStorage.test.ts`). The session is an `httpOnly`, `SameSite=Lax` cookie (`Secure` in production) that page scripts cannot read; every `/api` response is `Cache-Control: no-store`.
- **Access control:** every query is scoped to the signed-in user's workspace; other users' ids return 404. Passwords are PBKDF2-SHA512 (210k iterations); logins are rate-limited; request bodies are validated and size-limited; cross-site state-changing requests are refused (`Sec-Fetch-Site` + SameSite).
- **In transit:** use a TLS database URL (`sslmode=require`; the server warns in production if it is missing) and serve the app over HTTPS.
- **Production must-haves:** `JWT_SECRET` (the server refuses to start without it), `NODE_ENV=production`, HTTPS in front of the app.
- **Upgrading from older versions:** on startup, datasets that only existed inside old dashboards are copied into the datasets table and stripped from the dashboard (idempotent).
- **Known limitation:** the Excel reader `xlsx@0.18.5` (browser-side, parses only files the user picks) has two published advisories (prototype pollution, ReDoS) and npm has no patched release. Upgrade from the vendor: `cd frontend && npm i https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz`.
- **Concurrent edits:** saves are last-write-wins; editing the same dashboard in two tabs can overwrite changes.

## Configuration
See `backend/.env.example`. **Required:** `DATABASE_URL`, and in production `JWT_SECRET` (≥32 chars, `openssl rand -hex 48`).
The server refuses to start if they are missing – there are no built-in fallbacks.

## Deploy
```bash
docker build -t data-pulse .
docker run -p 8080:8080 -e DATABASE_URL=... -e JWT_SECRET=... data-pulse
```
The image hosts the API and the built frontend together. To deploy them separately instead, publish `frontend/dist` to any static host and set `ALLOWED_ORIGINS` on the API (and route `/api` to it). Works on Cloud Run, Render, Fly, Railway, any container host. Put it behind HTTPS (HSTS is sent).
Health endpoints: `/api/health` (liveness), `/api/ready` (checks the database – use for readiness probes).
Migrations run on boot under an advisory lock, so multiple instances starting together are safe; set `AUTO_MIGRATE=false`
to run them as a separate release step.

## Architecture
```
backend/src/
  config.ts          validated env (zod), fails fast
  db.ts              pg Pool + transaction helper
  migrations/        append-only, idempotent SQL migrations (schema_migrations table)
  middleware/        auth (signed JWT → user + workspace), validation, error handling
  repositories/      ALL SQL lives here; every query is scoped by workspace_id
  routes/            thin HTTP layer: auth, datasets, dashboards, models, settings
  __tests__/         integration tests (isolation, auth, versioning, legacy-schema upgrade)
frontend/src/        React app (pages are lazy-loaded; Plotly, xlsx, PDF libs load on demand)
```
**Security model:** passwords are PBKDF2-SHA512 (210k iterations, auto-upgraded on login); sessions are HS256 JWTs delivered in an `httpOnly`, `SameSite=Lax` cookie (`Secure` in production) – the browser stores no token, user object or app data;
every row belongs to a workspace and every query filters on it; rows owned by another workspace are never read, updated or
deleted (returns 404). Rate limits on all API calls, strict limits on login/register. CSP, HSTS and other headers via helmet.

**Data Model:** the model (fact/dimension tables, relationships, measures) drives every widget on the canvas: fields are resolved and joined through it, filters on dimension attributes reach the facts, and measures use the model's definitions. It is created automatically when datasets are attached to a dashboard and kept in sync afterwards. It is saved with the dashboard and mirrored in the `data_models` table (one row per dashboard, removed with it). `src/components/Widget/modelWiring.test.tsx` guards that widgets really receive it.

**Storage:** all user data (accounts, datasets and their cleaning versions, dashboards, data models, settings) lives in PostgreSQL. The frontend uses no `localStorage`/`sessionStorage`/IndexedDB; on load it asks `/api/auth/me` who you are and fetches everything else from the API. If the database is unreachable, loads and saves fail visibly instead of falling back to a local copy.

**IDs:** the client generates ids like `ds_1699…`. The server maps each one to a deterministic per-workspace UUID and keeps
the original in `client_id`, so ids stay stable across reloads and two users can never collide.

## Known limitations / next steps
- Sessions are stateless JWTs in an httpOnly cookie: logout clears the cookie but can't revoke a token that was copied elsewhere before it expires (7 days). For stricter needs add a revocation table.
- Because the session is a `SameSite=Lax` cookie, serve the UI and `/api` from the same origin (the Docker image, the Vite dev proxy, or a reverse proxy). A frontend on a different site would need `SameSite=None; Secure` plus credentialed CORS.
- No password reset / email verification / billing yet (pricing page is marketing only).
- Datasets are stored as JSONB and computed in the browser – fine up to roughly 100k rows; beyond that move to server-side aggregation.
- `xlsx` (npm) has an unpatched advisory (prototype pollution/ReDoS when opening a crafted file). It only runs in the user's own browser; to remove the warning install SheetJS's patched build from https://cdn.sheetjs.com or switch to `exceljs`.
- Large components (`TopToolbar`, `RightConfigPanel`, `transformationEngine`) would benefit from splitting and unit tests.
